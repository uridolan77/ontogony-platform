# Evidence and Route Decision Plan

## Required evidence graph

For direct Conexus chat:

```text
Trace
Correlation
Conexus execution run
Conexus model call
Conexus route decision
Conexus provider attempt
```

For governed Allagma run:

```text
Allagma run
Kanon planning decision
Kanon action decision, if applicable
Conexus model call
Conexus route decision
Conexus provider attempt
Trace
Correlation
```

## Route decision contract

A route decision is a first-class evidence object when:

```text
Conexus receives a chat request
Authenticates project
Resolves alias
Selects provider/model/fallback chain
Records decision
Executes provider attempt(s)
Records model-call telemetry
```

## Missing route decision behavior

If routeDecisionId is missing:

```text
reasonCode: route_decision_not_recorded
```

If routeDecisionId exists but endpoint returns 404:

```text
reasonCode: route_decision_not_found
```

If endpoint throws:

```text
reasonCode: route_decision_lookup_failed
```

If route decision is not applicable:

```text
reasonCode: not_applicable
```

## Evidence links response extension

Where safe, evidence-links should include:

```json
{
  "modelCallId": "chatcmpl-...",
  "requestId": "...",
  "executionRunId": "chat-...",
  "traceId": "...",
  "correlationId": "...",
  "routeDecisionId": "rd-...",
  "providerAttempts": [
    {
      "attemptNumber": 1,
      "providerKey": "fake",
      "providerModel": "fake.chat",
      "status": "completed"
    }
  ]
}
```

## Structured source failure

Evidence Spine source attempt should render:

```json
{
  "system": "conexus",
  "endpoint": "/admin/v0/route-decisions/{routeDecisionId}",
  "status": "error",
  "httpStatus": 404,
  "errorCode": "route_decision_not_found",
  "message": "Route decision id was present in model-call evidence but no detail record exists.",
  "identifier": {
    "routeDecisionId": "rd-..."
  },
  "traceId": "...",
  "correlationId": "..."
}
```

## ID normalization

Display in every Conexus evidence detail:

```text
Model call ID: chatcmpl-...
Request ID: 0HN...
Execution run ID: chat-0HN...
Route decision ID: rd-...
Trace ID: ...
Correlation ID: ...
```

Do not display the raw request suffix as `conexusModelCallId`.
