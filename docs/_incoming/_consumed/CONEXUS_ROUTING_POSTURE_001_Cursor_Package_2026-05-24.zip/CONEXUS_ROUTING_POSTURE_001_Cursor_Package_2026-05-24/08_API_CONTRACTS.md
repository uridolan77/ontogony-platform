# API Contracts and DTO Targets

## ProviderPostureContract v1

```json
{
  "providerKey": "fake",
  "displayName": "Fake provider",
  "adapterKind": "fake",
  "runtimeRegistered": true,
  "configPresent": true,
  "configEnabled": true,
  "secretState": "not_required",
  "secretFingerprintPresent": false,
  "baseUriHost": null,
  "readiness": "ready",
  "readinessReasons": [],
  "productionAllowed": false,
  "localOnly": true,
  "capabilities": {
    "chat": true,
    "streaming": true,
    "tools": false,
    "jsonMode": false
  },
  "lastProbe": {
    "status": "not_run",
    "checkedAtUtc": null
  }
}
```

## RoutePreviewPostureContract v1

```json
{
  "projectId": "dev-project",
  "requestedAlias": "risk-summary-v0",
  "resolvedAlias": "risk-summary-v0",
  "resolutionSource": "global_alias",
  "enabled": true,
  "primaryRoute": {
    "providerKey": "fake",
    "providerModel": "fake.chat"
  },
  "fallbackChain": [],
  "providerPosture": {
    "providerKey": "fake",
    "readiness": "ready",
    "secretState": "not_required"
  },
  "pricing": {
    "status": "not_applicable",
    "reason": "fake provider or no catalog entry"
  },
  "quota": {
    "status": "allowed"
  },
  "warnings": []
}
```

## ModelPurposePostureContract v1

```json
{
  "purpose": "summarize-player-risk",
  "conexusModelAlias": "risk-summary-v0",
  "streaming": false,
  "enabled": true,
  "source": "allagma-config",
  "warnings": []
}
```

## RouteDecisionDetailContract extension

Ensure existing route decision detail has or can derive:

```json
{
  "routeDecisionId": "rd-...",
  "requestId": "0HN...",
  "traceId": "...",
  "correlationId": "...",
  "projectId": "dev-project",
  "requestedModelAlias": "risk-summary-v0",
  "resolvedModelAlias": "risk-summary-v0",
  "resolutionSource": "global_alias",
  "providerKey": "fake",
  "providerModel": "fake.chat",
  "fallbackChain": [],
  "constraintsApplied": [],
  "selectionReason": "global alias resolved",
  "relatedModelCallIds": ["chatcmpl-..."],
  "persistence": {
    "mode": "Postgres",
    "warnings": []
  }
}
```
