# CONEXUS-ROUTING-POSTURE-001 — Cursor Master Prompt

You are working on the Ontogony local alpha system. This package is a focused deep-work sprint for **Conexus routing posture**, meaning the system must make model-purpose routing, model aliases, provider readiness, route decisions, provider attempts, fallback chains, pricing/catalog posture, and evidence links explicit and operator-trustworthy.

## Primary goal

Make the operator answer these questions without guessing:

1. What **model purpose** did Allagma request?
2. Which **Conexus model alias** did that purpose resolve to?
3. Which provider/model did Conexus select?
4. Was the selected route from a global alias or a project override?
5. What fallback chain existed?
6. Was fallback used?
7. Was the provider fake or real?
8. Was the provider configured, registered, secret-ready, and readiness-safe?
9. Which route decision id was created?
10. Does that route decision id resolve through the admin API?
11. Which model call id, request id, execution run id, trace id, and correlation id link the evidence together?
12. Is the UI showing an alias, provider model, purpose, or raw upstream model?

## Starting diagnosis

Current local Home shows model purposes such as `summarize-player-risk` and `summarize-player-risk-stream` mapped to aliases `risk-summary-v0` and `risk-summary-stream-v0`. That is the correct architectural direction. However, the console and repo reviews still show ambiguity around `gpt-4o-mini` as a possible operator default, Conexus readiness being "healthy" but not strict-ready, route-decision evidence not resolving, and route/model-call linkage being more demo-like than live-proof in some surfaces.

## Hard rules

- Do not move provider routing into Allagma or Kanon.
- Do not let Allagma hard-code concrete provider model names.
- Do not make Kanon responsible for model/provider selection.
- Conexus owns model aliases, provider keys, provider models, fallback, pricing, quota, route decisions, provider posture, and model-call evidence.
- Allagma owns model purpose selection and governed execution.
- Kanon owns semantic/policy decisions.
- The operator UI must label purpose, alias, provider, provider model, request id, model call id, execution run id, route decision id, trace id, and correlation id distinctly.

## Repos likely touched

- `conexus-dotnet`
- `allagma-dotnet`
- `ontogony-frontend`
- `ontogony-ui`
- `ontogony-platform` only if shared contracts/status taxonomy are needed

## Preferred implementation order

1. Confirm current route-preview, provider-inventory, model-call detail, evidence-links, and route-decision endpoints.
2. Fix route-decision persistence/resolution: evidence-links routeDecisionId must resolve.
3. Add or extend route-preview detail to expose alias source, project override/global route, fallback chain, pricing/catalog posture, quota implications, and provider readiness.
4. Normalize provider posture contract.
5. Ensure Allagma exposes purpose → alias mapping cleanly and never sends raw concrete provider models unless configured as a Conexus alias.
6. Tighten frontend labels and copy: purpose vs alias vs provider model.
7. Add smoke scripts and regression tests.
8. Update operator docs.

## Done means

A fake governed run and a direct Conexus fake chat both make their routing posture inspectable. The direct Conexus chat may not have a Kanon decision, but it must have a resolvable model call, provider attempt, and route decision when routing occurred. A governed Allagma run must show purpose → alias → Conexus route → provider attempt → evidence spine.
