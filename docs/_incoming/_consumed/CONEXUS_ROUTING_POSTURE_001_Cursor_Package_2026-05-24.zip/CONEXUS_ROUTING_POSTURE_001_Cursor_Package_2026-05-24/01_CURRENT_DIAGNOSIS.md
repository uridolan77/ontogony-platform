# Current Diagnosis

## 1. The architecture is right, but the operator posture is not yet explicit enough

The intended split is strong:

```text
Allagma = governed execution and model purpose
Kanon   = semantic authority, policy, facts, decisions
Conexus = model gateway, aliases, providers, fallback, price, quota, route evidence
```

The current UI already shows model purposes:

```text
summarize-player-risk
  Alias: risk-summary-v0

summarize-player-risk-stream
  Alias: risk-summary-stream-v0
```

That is good. It means the console is beginning to teach the correct boundary.

The remaining issue is that the routing pathway is not yet fully explainable from one operator view.

## 2. Concrete model names still risk leaking into the operator contract

Older review material highlighted a hard-coded Conexus model call pattern using `gpt-4o-mini`. That is a cross-repo boundary smell unless `gpt-4o-mini` is intentionally configured as a Conexus alias.

Correct operator language:

```text
Purpose: summarize-player-risk
Model alias: risk-summary-v0
Provider: fake / openai / anthropic / gemini / openai-compatible
Provider model: fake.chat / gpt-4o-mini / etc.
```

Incorrect or ambiguous language:

```text
Model: gpt-4o-mini
```

unless the label explicitly says:

```text
Conexus alias: gpt-4o-mini
```

## 3. Route-decision evidence currently fails in the fake test

Observed evidence:

```text
conexusRouteDecisionId = rd-...
/admin/v0/route-decisions/{routeDecisionId} -> error or not_found
```

This is not acceptable once Conexus emits a routeDecisionId. Either the route decision is a first-class evidence object, or the link should not be emitted as resolvable evidence.

Expected behavior:

```text
model call evidence-links returns routeDecisionId
GET /admin/v0/route-decisions/{routeDecisionId} returns route detail
Evidence Spine resolves model call -> route decision -> provider route
```

## 4. Provider posture is too thin

The operator needs to know:

```text
Provider key: fake
Runtime registered: yes
Config row exists: yes/no
Enabled: yes/no
Secret configured: yes/no/not_required
Secret fingerprint: present/not_present/redacted
Readiness contribution: ready/degraded/not_ready/not_applicable
Production allowed: yes/no
Reason: ...
```

For fake provider, it should say:

```text
Local fake provider
No external secret required
Not production-allowed
Safe for local tests
```

For OpenAI, it should say:

```text
Runtime adapter registered
Config enabled
Secret locator configured
Secret resolved or missing
```

## 5. Route preview needs to be richer

Current route preview tends to say provider/model, but not enough context. It should show:

```text
Requested alias
Project id
Resolution source: project_override | global_alias | missing
Resolved provider
Resolved provider model
Fallback chain
Price catalog version
Price availability
Provider posture summary
Quota state summary
Expected routeDecisionId generation behavior
```

## 6. The UI must not collapse purpose, alias, and provider model

Every Conexus-related view should use stable labels:

- `Model purpose`
- `Conexus alias`
- `Provider key`
- `Provider model`
- `Route decision ID`
- `Model call ID`
- `Request ID`
- `Execution run ID`
- `Trace ID`
- `Correlation ID`

## 7. This package intentionally complements previous packages

- `SYSTEM-TRUTH-001` fixes health/readiness/version/compatibility truth.
- `GOVERNED-FAKE-E2E-001` proves one live governed fake run.
- `CONEXUS-ROUTING-POSTURE-001` makes the route/provider/model layer explainable and inspectable.
