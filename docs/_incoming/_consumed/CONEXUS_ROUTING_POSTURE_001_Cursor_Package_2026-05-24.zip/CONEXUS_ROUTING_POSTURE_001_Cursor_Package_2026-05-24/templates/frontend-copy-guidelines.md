# Frontend Copy Guidelines

## Use exact labels

Use:

```text
Model purpose
Conexus alias
Provider key
Provider model
Route decision ID
Model call ID
Request ID
Execution run ID
Trace ID
Correlation ID
```

Avoid:

```text
Model
Gateway
Unknown
Healthy
```

unless qualified.

## Examples

Good:

```text
Model purpose: summarize-player-risk
Conexus alias: risk-summary-v0
Selected route: fake / fake.chat
Provider mode: local fake
```

Bad:

```text
Model: gpt-4o-mini
```

unless:

```text
Provider model: gpt-4o-mini
```

or:

```text
Conexus alias: gpt-4o-mini
```

## Fake provider language

```text
Fake provider
Local deterministic provider for tests and operator smoke runs.
No external API key required.
Not production-allowed.
```

## OpenAI provider language

```text
OpenAI provider
Runtime adapter registered.
Secret state: missing/resolved.
No raw key is displayed.
```

## Missing route decision

```text
Route decision detail unavailable.
Reason: route_decision_not_found.
The model call exposed a routeDecisionId, but the route-decision store did not return a detail row.
```

Never show only:

```text
An unexpected error occurred.
```
