# Backend Plan — Conexus

## PR-001: Route decision resolvability

### Problem

`model-call/evidence-links` can emit a `routeDecisionId`, but `/admin/v0/route-decisions/{routeDecisionId}` may not resolve it.

### Required behavior

For every successful routed chat completion:

```text
route decision is recorded
model call stores/links routeDecisionId
evidence-links exposes same routeDecisionId
admin route-decision endpoint resolves same id
```

### Tasks

1. Audit route resolution path:
   - where `RouteDecisionRecord` is created;
   - where `IRouteDecisionRecorder.RecordAsync` is called;
   - whether record is written before/after model-call telemetry;
   - whether record id equals evidence link id.

2. Add regression tests:
   - in-memory fake provider path;
   - Postgres path if existing test harness supports it;
   - direct chat with alias `risk-summary-v0` or `gpt-4o-mini` routed to fake;
   - evidence-links routeDecisionId resolves.

3. If route decision enrichers throw:
   - catch structured exceptions;
   - return clean 404 when record is missing;
   - return structured 500 only for genuine backend failure;
   - include `routeDecisionId`, not raw secrets.

4. Ensure route decision detail includes:
   - requestId;
   - traceId;
   - projectId;
   - requestedModelAlias;
   - resolvedModelAlias;
   - providerKey;
   - providerModel;
   - fallbackChain;
   - priceCatalogVersion;
   - constraintsApplied;
   - selectionReason;
   - relatedModelCallIds;
   - persistenceMode and warnings.

## PR-002: Route preview detail

### Endpoint

Prefer extending existing:

```text
POST /v1/models/{modelAlias}/route-preview
```

or add admin/project route if separation is needed:

```text
GET /admin/v0/projects/{projectId}/aliases/{alias}/route-preview
```

### Response should include

```json
{
  "projectId": "dev-project",
  "requestedAlias": "risk-summary-v0",
  "resolvedAlias": "risk-summary-v0",
  "resolutionSource": "project_override",
  "enabled": true,
  "primaryRoute": {
    "providerKey": "fake",
    "providerModel": "fake.chat"
  },
  "fallbackChain": [
    {
      "order": 1,
      "providerKey": "openai",
      "providerModel": "gpt-4o-mini"
    }
  ],
  "providerPosture": {
    "providerKey": "fake",
    "runtimeRegistered": true,
    "configEnabled": true,
    "secretState": "not_required",
    "readiness": "ready",
    "productionAllowed": false
  },
  "pricing": {
    "catalogVersion": "v1",
    "status": "found",
    "inputUsdPerMillionTokens": 0.1,
    "outputUsdPerMillionTokens": 0.4
  },
  "quota": {
    "status": "allowed",
    "remainingRequests": 994
  },
  "warnings": []
}
```

## PR-003: Provider posture normalization

Add a normalized provider posture DTO independent of raw provider config.

### Fields

```text
providerKey
displayName
adapterKind
runtimeRegistered
configPresent
configEnabled
secretState
secretFingerprintPresent
baseUriHost
readiness
readinessReasons[]
productionAllowed
localOnly
supportsStreaming
supportsTools
supportsJsonMode
lastProbeStatus
lastProbeAtUtc
```

### Secret states

```text
not_required
locator_missing
locator_present_unresolved
resolved
disabled
unknown
```

Never return raw secret ids, raw secret locators, raw API keys, or raw Authorization headers.

## PR-004: Pricing/catalog posture

Add pricing posture to route preview and/or route detail:

```text
pricing status:
  found
  missing
  not_applicable
  catalog_disabled
  version_missing
```

The operator needs to know whether cost is zero because fake provider was used, because price catalog is missing, or because pricing is disabled/not applicable.

## PR-005: Fallback attempt visibility

Ensure model-call detail includes provider attempts with:

```text
attemptNumber
providerKey
providerModel
status
startedAtUtc
completedAtUtc
latencyMs
retryableFailure
errorCode
fallbackUsed
```

Do not show raw provider error bodies unless explicitly redacted and in detail/debug mode.
