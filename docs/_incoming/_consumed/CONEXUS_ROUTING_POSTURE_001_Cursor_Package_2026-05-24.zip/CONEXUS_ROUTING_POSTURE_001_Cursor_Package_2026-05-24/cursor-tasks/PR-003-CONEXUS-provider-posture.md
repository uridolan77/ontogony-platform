# PR-003 — Conexus provider posture

## Goal
Normalize provider inventory so the operator sees runtime/config/secret/readiness posture.

## Steps
1. Add ProviderPostureContract.
2. Map fake provider as local-only/not_required secret.
3. Map OpenAI/openai-compatible/Anthropic/Gemini secret/config states.
4. Never expose raw secrets.
5. Add frontend provider posture cards.

## Acceptance
Fake and OpenAI posture are visibly different and correct.
