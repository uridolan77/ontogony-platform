# PR-009 — Routing posture smoke scripts

## Goal
Add repeatable scripts to prove local fake route posture.

## Steps
1. Add PowerShell smoke script.
2. Add bash smoke script.
3. Script prints route preview, model call, evidence links, route decision detail.
4. Script exits non-zero if route decision does not resolve.

## Acceptance
A local operator can run one command and verify Conexus routing posture.
