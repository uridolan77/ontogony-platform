# PR-008 — Fallback visibility

## Goal
Make fallback chain and fallback use obvious.

## Steps
1. Include fallback chain in route preview.
2. Include provider attempts in model-call detail.
3. Mark fallback used when attempt > 1 succeeds.
4. Test retryable fake failure scenario if available.

## Acceptance
Fallback chain and actual provider attempts are distinguishable.
