# PR-010 — Operator docs

## Goal
Document purpose → alias → provider route → evidence.

## Steps
1. Add operator guide.
2. Add fake vs OpenAI provider notes.
3. Add route-decision troubleshooting.
4. Add UI copy glossary.
5. Link from Conexus docs and platform operator docs.

## Acceptance
A new operator can understand Conexus routing without reading code.
