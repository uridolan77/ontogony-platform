# PR-002 — Conexus route-preview posture

## Goal
Route preview shows alias source, provider route, fallback, provider posture, pricing, and quota context.

## Steps
1. Extend existing route-preview endpoint or add admin route-preview detail.
2. Add DTOs and OpenAPI snapshot updates.
3. Include project override vs global alias source.
4. Include provider posture summary.
5. Include pricing/catalog status.
6. Include quota posture if safe.

## Acceptance
Operator can understand why an alias resolves to fake/openai/etc. without making a provider call.
