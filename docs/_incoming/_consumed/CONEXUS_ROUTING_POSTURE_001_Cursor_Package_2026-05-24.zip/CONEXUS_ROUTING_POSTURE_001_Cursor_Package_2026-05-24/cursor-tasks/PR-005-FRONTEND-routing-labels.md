# PR-005 — Frontend routing labels

## Goal
Eliminate purpose/alias/provider model confusion.

## Steps
1. Replace ambiguous `Model` labels.
2. Add exact ID labels in Observability and Evidence Spine.
3. Add tests for copy/labels.
4. Move raw provider output to detail view.

## Acceptance
No main operator surface leaves `gpt-4o-mini` ambiguous.
