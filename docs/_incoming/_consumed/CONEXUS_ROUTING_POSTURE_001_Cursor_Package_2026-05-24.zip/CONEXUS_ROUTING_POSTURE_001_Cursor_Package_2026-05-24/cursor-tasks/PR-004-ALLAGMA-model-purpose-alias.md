# PR-004 — Allagma model purpose → Conexus alias

## Goal
Allagma sends Conexus aliases derived from model purpose configuration, not concrete provider models.

## Steps
1. Audit current Conexus model request construction.
2. Ensure model purpose config maps purpose to ConexusModelAlias.
3. Add validation for unknown purpose.
4. Expose purpose posture to frontend.
5. Update run events/response with purpose and alias.

## Acceptance
Start Run shows purpose and alias; Conexus request uses alias.
