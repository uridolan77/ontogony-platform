# PR-001 — Conexus route-decision resolvability

## Goal
Every `routeDecisionId` emitted from model-call evidence resolves through the admin route-decision endpoint.

## Steps
1. Add test for fake chat route decision round-trip.
2. Audit route decision recorder and telemetry writer.
3. Ensure evidence-links uses persisted routeDecisionId.
4. Ensure EF and in-memory stores use same id format.
5. Degrade route-decision detail enrichment gracefully.
6. Add structured error for route decision lookup failure.

## Acceptance
- Fake chat produces routeDecisionId.
- `/admin/v0/model-calls/{id}/evidence-links` returns it.
- `/admin/v0/route-decisions/{routeDecisionId}` returns 200.
- Evidence Spine route node resolves.
