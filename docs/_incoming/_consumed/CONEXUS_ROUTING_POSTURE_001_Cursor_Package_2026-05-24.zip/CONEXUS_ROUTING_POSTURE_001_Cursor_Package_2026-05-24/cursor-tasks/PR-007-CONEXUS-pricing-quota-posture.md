# PR-007 — Pricing and quota posture

## Goal
Explain cost/zero cost and quota implications in route preview/model-call detail.

## Steps
1. Surface price catalog version/status.
2. Explain missing price vs fake/not-applicable.
3. Include quota allowed/blocked/near-limit status.
4. Add UI badges.

## Acceptance
Operator knows why cost is zero or unknown.
