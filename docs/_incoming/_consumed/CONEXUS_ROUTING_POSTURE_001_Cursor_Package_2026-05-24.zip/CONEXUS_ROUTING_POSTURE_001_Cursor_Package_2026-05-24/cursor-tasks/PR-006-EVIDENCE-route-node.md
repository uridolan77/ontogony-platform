# PR-006 — Evidence Spine route-decision node

## Goal
Evidence Spine renders route decisions as first-class Conexus evidence nodes.

## Steps
1. Add route decision node type or mapping if missing.
2. Resolve routeDecisionId from model-call evidence-links.
3. Add structured missing reasons.
4. Normalize IDs.

## Acceptance
Direct fake chat Evidence Spine contains route decision node or structured reason.
