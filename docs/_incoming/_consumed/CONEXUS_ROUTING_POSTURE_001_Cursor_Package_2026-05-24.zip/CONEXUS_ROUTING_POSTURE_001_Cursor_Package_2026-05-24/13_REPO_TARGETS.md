# Repo and File Targets

## conexus-dotnet

Likely areas:

```text
src/Conexus.Api/Endpoints/*Route*Endpoints.cs
src/Conexus.Api/Endpoints/*Provider*Endpoints.cs
src/Conexus.Api/Endpoints/*ModelCall*Endpoints.cs
src/Conexus.Application/Telemetry/*
src/Conexus.Application/Routing/*
src/Conexus.Application/Admin/*
src/Conexus.Infrastructure/Telemetry/*
src/Conexus.Persistence/*
src/Conexus.Admin.Contracts/*
src/Conexus.Contracts/*
tests/Conexus.Api.Tests/*
tests/Conexus.Infrastructure.Tests/*
docs/MODEL_ROUTING.md
docs/API.md
docs/operators/*
openapi/*
```

## allagma-dotnet

Likely areas:

```text
src/Allagma.Application/*ModelPurpose*
src/Allagma.Application/*Conexus*
src/Allagma.Domain/AgentRun*
src/Allagma.Contracts/RunContracts.cs
src/Allagma.Api/Endpoints/*
tests/Allagma.Tests/*
docs/system/*
docs/operators/*
```

## ontogony-frontend

Likely areas:

```text
src/conexus/*
src/allagma/*
src/evidence-spine/*
src/system/*
src/app/settings/*
src/shared/workbench/*
src/shared/status/*
e2e/*
```

## ontogony-ui

Likely areas:

```text
packages or src/status/*
src/semantic/*
src/execution/*
src/data/*
src/feedback/*
```

## ontogony-platform

Only touch if shared status/error/evidence contracts must live there.
