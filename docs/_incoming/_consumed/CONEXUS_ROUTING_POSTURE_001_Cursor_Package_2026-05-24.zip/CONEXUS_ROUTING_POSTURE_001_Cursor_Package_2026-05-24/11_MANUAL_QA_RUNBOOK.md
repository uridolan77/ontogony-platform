# Manual QA Runbook

## Preconditions

Start local stack:

```powershell
# Example only; use existing repo scripts if available.
# Kanon:    http://localhost:5081
# Conexus:  http://localhost:5082
# Allagma:  http://localhost:5083
# Frontend: http://localhost:5173
```

Ensure fake provider path works. Real OpenAI key is not required.

## QA 1 — Direct Conexus fake chat

1. Open Conexus Routing.
2. Select project `dev-project`.
3. Select alias `risk-summary-v0` or `gpt-4o-mini` if intentionally aliased to fake.
4. Confirm route preview says:
   - provider: fake;
   - provider model: fake.chat;
   - secret: not required;
   - local-only fake provider.
5. Send chat from Conexus Chat.
6. Open Conexus Observability.
7. Open latest model call.
8. Confirm:
   - model call id starts `chatcmpl-`;
   - request id is distinct;
   - execution run id starts `chat-`;
   - route decision id starts `rd-`;
   - provider attempt is fake/fake.chat.
9. Open route decision.
10. Confirm route detail resolves.

## QA 2 — Evidence Spine by model call id

1. Copy latest `chatcmpl-*`.
2. Open Evidence Spine.
3. Paste id and resolve.
4. Confirm:
   - model call node;
   - route decision node;
   - provider attempt node;
   - trace node;
   - correlation node.
5. Confirm no generic “unexpected error.”

## QA 3 — Allagma governed fake run

1. Open Start Run.
2. Select purpose `summarize-player-risk`.
3. Confirm alias `risk-summary-v0`.
4. Click Start and open run detail.
5. Confirm run detail shows:
   - purpose;
   - alias;
   - planning decision id;
   - Conexus model call id when complete.
6. Open Evidence Spine from run.
7. Confirm model-call route posture resolves through Conexus.

## QA 4 — Provider posture

1. Open Conexus Routing provider inventory.
2. Confirm fake:
   - runtime registered;
   - no secret required;
   - local-only;
   - ready.
3. Confirm OpenAI:
   - runtime registered if adapter loaded;
   - secret missing/resolved according to env;
   - no raw key visible.

## QA 5 — Copy review

Scan Home, Settings, Start Run, Conexus Routing, Observability, Evidence Spine.

No ambiguous `Model` label should be used where it could mean purpose/alias/provider model.

Acceptable examples:

```text
Model purpose: summarize-player-risk
Conexus alias: risk-summary-v0
Provider model: fake.chat
```
