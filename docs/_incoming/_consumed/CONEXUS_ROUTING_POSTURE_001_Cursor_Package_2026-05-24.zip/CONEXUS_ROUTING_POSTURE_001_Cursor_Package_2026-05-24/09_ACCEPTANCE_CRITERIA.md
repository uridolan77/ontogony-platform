# Acceptance Criteria

## Must pass

1. Direct Conexus fake chat produces:
   - modelCallId;
   - requestId;
   - executionRunId;
   - traceId;
   - correlationId;
   - provider attempt;
   - routeDecisionId;
   - resolvable route decision detail.

2. `GET /admin/v0/route-decisions/{routeDecisionId}` returns 200 for routeDecisionId emitted by model-call evidence-links.

3. Conexus Routing page shows:
   - requested alias;
   - resolution source;
   - provider key/model;
   - fallback chain;
   - provider posture;
   - price posture;
   - quota posture.

4. Allagma Start Run shows:
   - model purpose;
   - resolved Conexus alias;
   - no raw concrete provider model as default;
   - purpose validation.

5. Allagma run detail/list shows:
   - purpose and alias;
   - Conexus model call id once known;
   - provider route only via Conexus evidence.

6. Evidence Spine displays:
   - route decision node when available;
   - structured route missing reason when unavailable;
   - distinct model call/request/execution ids.

7. Provider inventory/posture distinguishes:
   - fake local provider;
   - OpenAI runtime registered but secret/config unknown/missing/resolved;
   - disabled providers.

8. No page labels `gpt-4o-mini` as `Model` unless it is explicitly identified as a Conexus alias or provider model.

9. Tests cover:
   - in-memory route-decision resolution;
   - Postgres route-decision resolution if harness available;
   - frontend label rendering for purpose/alias/provider model;
   - Evidence Spine missing reason rendering.

## Should pass

1. Route preview can be opened from Start Run for the selected purpose/alias.
2. Provider posture includes capability flags.
3. Price posture explains zero or missing cost.
4. Fallback-used is visible on model-call detail.
5. Raw provider output stays in detail/debug, not list cards.

## Must not regress

1. Fake provider local dev path still works without external API key.
2. Real provider keys are never exposed.
3. Production fake-provider guard remains intact.
4. Allagma does not take ownership of provider routing.
5. Kanon remains semantic authority only.
