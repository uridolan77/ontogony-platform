# Operator Routing Guide

## Golden path

```text
Allagma model purpose
  -> Conexus alias
    -> Conexus route decision
      -> provider key + provider model
        -> provider attempt
          -> model call evidence
```

## Example

```text
Purpose: summarize-player-risk
Alias: risk-summary-v0
Route: fake / fake.chat
Route decision: rd-...
Model call: chatcmpl-...
```

## Direct Conexus chat

Direct Conexus chat starts at alias level:

```text
Conexus alias -> provider route -> model call
```

It does not necessarily have:

```text
Kanon decision
Allagma run
```

Therefore Evidence Spine should not flag missing Kanon decision as a hard error for direct Conexus chat.

## Governed Allagma run

Governed run starts at purpose level:

```text
Purpose -> alias -> Kanon planning/policy -> Conexus model call -> route decision
```

It should have:

```text
Allagma run id
Kanon decision id
Conexus model call id
Route decision id
Trace id
Correlation id
```

## Fake provider

Fake provider is correct for local smoke tests.

```text
No external key
No provider cost
Local deterministic behavior
Not production allowed
```

## OpenAI provider

OpenAI provider must show:

```text
Runtime adapter registered
Config enabled/disabled
Secret locator configured
Secret resolved/missing
```

Do not display raw API keys.

## Troubleshooting

### Route decision id present but detail missing

This indicates one of:

```text
route decision not recorded
evidence-links emitted reconstructed/wrong id
admin detail reads different store
route detail enrichment failed
Postgres/in-memory mismatch
```

Run smoke script and inspect Conexus logs.

### Cost is zero

Could mean:

```text
fake provider
pricing not applicable
price catalog missing
price catalog disabled
```

The UI should state which one.

### Alias resolves to unexpected provider

Check:

```text
project override
global alias
provider enabled state
fallback chain
admin changes
```
