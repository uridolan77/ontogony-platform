# Test Plan

## Conexus backend tests

### RouteDecisionEvidenceTests

```text
Given dev project and fake alias risk-summary-v0
When POST /v1/chat/completions model=risk-summary-v0
Then model call detail has routeDecisionId
And evidence-links has same routeDecisionId
And GET /admin/v0/route-decisions/{id} returns 200
And response providerKey=fake providerModel=fake.chat
```

### RoutePreviewPostureTests

```text
Given global alias risk-summary-v0 -> fake/fake.chat
When route preview is requested
Then resolutionSource=global_alias
And providerPosture.secretState=not_required
And providerPosture.runtimeRegistered=true
```

### ProjectOverrideRoutePreviewTests

```text
Given global alias -> fake
And project override -> openai/gpt-4o-mini
When route preview for dev-project
Then resolutionSource=project_override
And primary route is openai/gpt-4o-mini
```

### ProviderPostureTests

```text
fake provider => ready, not_required, localOnly=true
openai missing env secret => degraded/not_ready, locator_present_unresolved
disabled provider => disabled
```

## Allagma backend tests

### ModelPurposeConfigTests

```text
Configured purpose summarize-player-risk resolves to risk-summary-v0.
Invalid purpose returns stable invalid_model_purpose error.
Conexus request uses alias, not concrete provider model.
```

### RunEvidenceLinkTests

```text
Started run stores modelPurpose and conexusModelAlias.
Completed run stores Conexus modelCallId.
Run events expose purpose and alias.
```

## Frontend tests

### RoutingLabelTests

Assert page renders:

```text
Model purpose
Conexus alias
Provider key
Provider model
Route decision ID
Model call ID
Request ID
Execution run ID
```

and does not show ambiguous:

```text
Model: gpt-4o-mini
```

unless context says alias/provider model.

### EvidenceSpineRouteDecisionTests

Given routeDecisionId resolves:

```text
route decision node is rendered
provider/fallback details are visible
```

Given routeDecisionId fails:

```text
structured missing reason is rendered
no generic unexpected error
```

### ProviderPostureCardTests

Fake, OpenAI missing secret, OpenAI ready, disabled provider display correct badges.

## Smoke scripts

- `scripts/smoke/conexus-routing-posture.ps1`
- `scripts/smoke/conexus-routing-posture.sh`

Smoke should:
1. call `/health` and `/ready` if available;
2. call provider inventory;
3. call route preview;
4. send fake chat;
5. fetch model-call detail;
6. fetch evidence-links;
7. fetch route decision detail;
8. print compact route posture summary.
