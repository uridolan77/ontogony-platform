# Target State

## Operator target

From Conexus Overview, Routing, Observability, Evidence Spine, and Allagma run detail, the operator can see:

```text
Model purpose:
  summarize-player-risk

Conexus alias:
  risk-summary-v0

Resolution source:
  project override for dev-project
  or global alias

Selected route:
  fake / fake.chat

Fallback chain:
  1. openai / gpt-4o-mini
  2. fake / fake.chat

Provider posture:
  fake: runtime registered, local-only, no secret required
  openai: runtime registered, config enabled, secret missing/resolved

Pricing posture:
  catalog version v1
  price found / missing / not_applicable

Quota posture:
  allowed / near_limit / blocked

Evidence:
  routeDecisionId: rd-...
  modelCallId: chatcmpl-...
  requestId: ...
  executionRunId: chat-...
  traceId: ...
  correlationId: ...
```

## Backend target

Conexus exposes and persists enough data to support:

- route preview without provider call;
- route decision detail after provider call;
- provider inventory/posture;
- alias source and fallback chain;
- model-call evidence links;
- model-call detail with provider attempts;
- route decision id round-trip;
- admin observability query paths.

## Frontend target

The UI no longer says simply `model` when the field may mean different things. It uses exact language:

| Label | Meaning |
|---|---|
| Model purpose | Allagma intent-level routing purpose |
| Conexus alias | Stable gateway-facing model key |
| Provider key | Provider adapter key, e.g. fake/openai |
| Provider model | Actual provider/upstream model id |
| Route decision | Conexus route resolution evidence |
| Provider attempt | Concrete invocation attempt |
| Fallback | Secondary route used after retryable failure |

## Evidence target

Evidence Spine for a model call should contain:

```text
Model call
  has_trace -> Trace
  has_correlation -> Correlation
  used_route_decision -> Route decision
  derived_from -> Execution run
  derived_from -> Provider attempt(s)
```

A governed run should additionally contain:

```text
Allagma run
  used_kanon_decision -> Kanon decision
  used_conexus_model_call -> Model call
```

Direct Conexus chat should not require Kanon decision.
