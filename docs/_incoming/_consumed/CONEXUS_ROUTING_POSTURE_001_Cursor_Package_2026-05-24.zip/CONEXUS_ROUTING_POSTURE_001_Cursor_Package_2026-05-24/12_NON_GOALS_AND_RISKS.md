# Non-Goals and Risks

## Non-goals

- Do not enable real external execution.
- Do not require real OpenAI key.
- Do not implement enterprise IAM.
- Do not move route ownership out of Conexus.
- Do not change Kanon semantic policies.
- Do not overbuild provider marketplace features.
- Do not make streaming mandatory.

## Risks

### Risk 1 — Scope creep into SYSTEM-TRUTH-001

Health/readiness fixes belong mostly to SYSTEM-TRUTH-001. This package may consume readiness detail, but should not refactor the whole health system unless required for provider posture.

### Risk 2 — Route preview leaks secrets

Provider posture must never include raw API keys or secret locators. Redact aggressively.

### Risk 3 — Fake provider treated as production-ready

Fake provider should be clearly local-only and production-blocked.

### Risk 4 — Allagma starts owning provider logic

Allagma may validate purposes and send aliases. It must not select providers, provider models, fallback chains, or prices.

### Risk 5 — Alias/provider model confusion persists

This is the main UX risk. Tests should lock in exact labels.

### Risk 6 — Route decision detail enrichment throws

Route decision detail should degrade gracefully. If provider config lookup fails, still return core route decision with warning rather than failing the whole endpoint when possible.

### Risk 7 — Postgres/in-memory divergence

Route-decision resolution must be tested in both modes where feasible.
