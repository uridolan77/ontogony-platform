# Frontend Plan

## Affected areas

- Home runtime summary
- Allagma Start Run
- Allagma Runs / Run Detail
- Agent Interaction
- Conexus Overview
- Conexus Routing
- Conexus Observability
- Evidence Spine
- Operator Settings where model default is shown
- Topology edge detail

## PR-011: Label cleanup

Replace ambiguous labels:

| Current ambiguous label | Replace with |
|---|---|
| Model | Conexus alias, Provider model, or Model purpose |
| Gateway health on Kanon pages | Kanon API health / Conexus gateway health |
| Fake response | Provider output preview |
| unknown | Task type unknown / Provider unknown / Source unknown |

## PR-012: Conexus Routing page sections

Structure the page:

```text
1. Project context
   project id, project key source/redacted, quota posture

2. Alias resolver
   requested alias, source, resolved provider/model, enabled state

3. Provider posture
   fake/openai/etc. runtime/config/secret/readiness

4. Fallback chain
   ordered fallback routes and availability

5. Price catalog
   catalog version, effective date, price status

6. Route preview
   raw-ish but redacted route preview JSON behind details

7. Recent route decisions
   routeDecisionId, alias, provider/model, modelCallId, trace/correlation
```

## PR-013: Conexus Observability enhancements

For each model call row/detail:

```text
Model call ID: chatcmpl-...
Request ID: 0HN...
Execution run ID: chat-0HN...
Route decision ID: rd-...
Conexus alias: risk-summary-v0
Provider: fake
Provider model: fake.chat
Purpose: summarize-player-risk, if linked from Allagma
Provider mode: fake/local
Fallback used: yes/no
Tokens: input/output
Cost: amount + pricing status
```

## PR-014: Evidence Spine Conexus node labels

Evidence Spine should display distinct nodes:

```text
Model call
Route decision
Provider attempt
Execution run
Trace
Correlation
```

If a route decision id is present but not resolvable:

```text
Missing route decision detail
Reason: route_decision_not_found
Suggested next step: open Conexus route decision explorer / inspect route store
```

not:

```text
An unexpected error occurred.
```

## PR-015: Provider posture cards

Use status badges:

```text
Runtime: registered / missing
Config: enabled / disabled / missing
Secret: resolved / missing / not required
Readiness: ready / degraded / not ready
Mode: fake local / real external
```

For fake provider:

```text
Fake provider
Local deterministic provider
No external secret required
Not allowed in Production
```

For OpenAI:

```text
OpenAI provider
Runtime adapter registered
Secret from env: CONEXUS_PROVIDER_OPENAI_API_KEY
Secret state: resolved/missing
```

Do not display raw secret values.

## PR-016: Start Run model purpose UX

Allagma Start Run should show:

```text
Model purpose
[select: summarize-player-risk]

Conexus alias
risk-summary-v0

Streaming
off/on

Provider route
Resolved by Conexus after request; preview available in Conexus Routing
```

Add actions:

```text
Preview Conexus route
Start and open run detail
Start and open Agent Interaction
```

## PR-017: Settings model field cleanup

If settings currently display a model value, decide whether it is:

- Allagma model purpose;
- Conexus alias;
- provider model.

Rename accordingly. Avoid showing `gpt-4o-mini` as a default unless it is definitely an alias.
