# Backend Plan — Allagma

## Purpose

Allagma should expose **model purpose** and **resolved Conexus alias** clearly, but it must not own provider routing.

## PR-006: Model purpose config posture

### Required config shape

Use or converge toward:

```json
{
  "Allagma": {
    "ModelPurposes": {
      "summarize-player-risk": {
        "ConexusModelAlias": "risk-summary-v0",
        "SystemPrompt": "You are a concise risk-summary assistant.",
        "Streaming": false
      },
      "summarize-player-risk-stream": {
        "ConexusModelAlias": "risk-summary-stream-v0",
        "SystemPrompt": "You are a concise risk-summary assistant.",
        "Streaming": true
      }
    }
  }
}
```

### Runtime behavior

When starting a run:

```text
run.ModelPurpose = summarize-player-risk
resolved Conexus alias = risk-summary-v0
Conexus request model = risk-summary-v0
```

Do not send concrete provider model unless the concrete name is deliberately an alias registered in Conexus.

## PR-007: Purpose validation endpoint or payload

Expose purpose configuration to the frontend, either through existing readiness/runtime summary or a new endpoint:

```text
GET /allagma/v0/model-purposes
```

Response:

```json
{
  "purposes": [
    {
      "purpose": "summarize-player-risk",
      "conexusModelAlias": "risk-summary-v0",
      "streaming": false,
      "enabled": true
    }
  ]
}
```

## PR-008: Run response and events

Ensure run detail/event stream includes:

```text
modelPurpose
conexusModelAlias
conexusModelCallId
conexusRouteDecisionId, if returned/known
traceId
correlationId
```

The run list may show purpose and alias, but provider/model should come from Conexus evidence, not Allagma assumptions.

## PR-009: Start Run validation

If the user enters a model purpose not configured:

```text
400 invalid_model_purpose
```

The response should include available purposes. The frontend should validate before submit when possible.

## PR-010: Operator wording

Allagma UI should say:

```text
Model purpose: summarize-player-risk
Conexus alias: risk-summary-v0
Provider: resolved by Conexus
```

Not:

```text
Model: gpt-4o-mini
```
