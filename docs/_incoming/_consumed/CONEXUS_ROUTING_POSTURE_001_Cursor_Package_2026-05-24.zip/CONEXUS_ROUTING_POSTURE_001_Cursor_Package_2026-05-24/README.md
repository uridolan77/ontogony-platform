# CONEXUS-ROUTING-POSTURE-001 Cursor Package

Created: 2026-05-24

## Use

Open `00_CURSOR_MASTER_PROMPT.md` in Cursor first.

## Purpose

This package deepens the Conexus routing/operator posture:

```text
Purpose -> Alias -> Route Decision -> Provider Attempt -> Model Call Evidence
```

It is designed to follow:

1. SYSTEM-TRUTH-001
2. GOVERNED-FAKE-E2E-001

## Main outcomes

- Route-decision evidence round-trip.
- Route-preview posture.
- Provider posture.
- Purpose/alias/provider-model label clarity.
- Fake vs real provider visibility.
- Pricing/quota/fallback visibility.
- Smoke scripts and docs.

## Start here

1. `00_CURSOR_MASTER_PROMPT.md`
2. `01_CURRENT_DIAGNOSIS.md`
3. `09_ACCEPTANCE_CRITERIA.md`
4. `cursor-tasks/PR-001-CONEXUS-route-decision-resolvability.md`
