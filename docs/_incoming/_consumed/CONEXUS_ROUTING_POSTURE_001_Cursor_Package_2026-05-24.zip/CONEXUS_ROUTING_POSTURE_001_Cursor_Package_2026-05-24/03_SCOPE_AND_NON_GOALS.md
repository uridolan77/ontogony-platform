# Scope and Non-Goals

## In scope

- Conexus route-decision round-trip.
- Conexus route-preview detail.
- Conexus provider posture contract.
- Conexus alias/project override/global alias clarity.
- Pricing/catalog posture summary for selected alias.
- Quota posture summary where safe and additive.
- Model purpose to alias visibility in Allagma and frontend.
- Frontend copy and labeling around purpose/alias/provider model.
- Evidence Spine display normalization for Conexus IDs.
- Smoke scripts and tests.

## Out of scope

- Adding new provider adapters.
- Making real OpenAI mandatory.
- Enabling real external tools.
- Enterprise IAM/security hardening.
- Full streaming orchestration.
- Changing Kanon semantic authority behavior.
- Replacing Evidence Spine entirely.
- Production-grade billing/accounting.
- Durable multi-node idempotency work beyond route evidence needed here.
