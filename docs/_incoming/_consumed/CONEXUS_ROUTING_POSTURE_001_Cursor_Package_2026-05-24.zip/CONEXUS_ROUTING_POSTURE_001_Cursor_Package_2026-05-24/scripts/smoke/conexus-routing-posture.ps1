param(
  [string]$BaseUrl = "http://localhost:5082",
  [string]$ProjectKey = "cx-dev-key-change-me",
  [string]$AdminKey = "cx-conexus-admin-dev",
  [string]$Alias = "risk-summary-v0"
)

$ErrorActionPreference = "Stop"

function Json($obj) { $obj | ConvertTo-Json -Depth 20 }

Write-Host "Conexus routing posture smoke"
Write-Host "BaseUrl: $BaseUrl"
Write-Host "Alias: $Alias"

$adminHeaders = @{ "X-Conexus-Admin-Key" = $AdminKey }
$projectHeaders = @{ "Authorization" = "Bearer $ProjectKey" }

Write-Host "`n[1] Provider inventory"
try {
  $inventory = Invoke-RestMethod -Method Get -Uri "$BaseUrl/admin/v0/providers/inventory" -Headers $adminHeaders
  $inventory | ConvertTo-Json -Depth 20
} catch {
  Write-Warning "Provider inventory failed: $($_.Exception.Message)"
}

Write-Host "`n[2] Route preview"
try {
  $previewBody = @{ messages = @(@{ role = "user"; content = "route preview smoke" }) } | ConvertTo-Json -Depth 10
  $preview = Invoke-RestMethod -Method Post -Uri "$BaseUrl/v1/models/$Alias/route-preview" -Headers $projectHeaders -ContentType "application/json" -Body $previewBody
  $preview | ConvertTo-Json -Depth 20
} catch {
  Write-Warning "Route preview failed: $($_.Exception.Message)"
}

Write-Host "`n[3] Chat completion"
$chatBody = @{
  model = $Alias
  messages = @(@{ role = "user"; content = "Smoke test Conexus route posture." })
} | ConvertTo-Json -Depth 10

$chat = Invoke-RestMethod -Method Post -Uri "$BaseUrl/v1/chat/completions" -Headers $projectHeaders -ContentType "application/json" -Body $chatBody
$chat | ConvertTo-Json -Depth 20

$modelCallId = $chat.id
if (-not $modelCallId) {
  throw "Chat response did not include id/modelCallId."
}

Write-Host "`n[4] Model call detail: $modelCallId"
$detail = Invoke-RestMethod -Method Get -Uri "$BaseUrl/admin/v0/model-calls/$modelCallId" -Headers $adminHeaders
$detail | ConvertTo-Json -Depth 20

Write-Host "`n[5] Evidence links"
$links = Invoke-RestMethod -Method Get -Uri "$BaseUrl/admin/v0/model-calls/$modelCallId/evidence-links" -Headers $adminHeaders
$links | ConvertTo-Json -Depth 20

$routeDecisionId = $links.routeDecisionId
if (-not $routeDecisionId -and $links.conexusRouteDecisionId) {
  $routeDecisionId = $links.conexusRouteDecisionId
}
if (-not $routeDecisionId) {
  throw "Evidence links did not include routeDecisionId."
}

Write-Host "`n[6] Route decision detail: $routeDecisionId"
$route = Invoke-RestMethod -Method Get -Uri "$BaseUrl/admin/v0/route-decisions/$routeDecisionId" -Headers $adminHeaders
$route | ConvertTo-Json -Depth 20

Write-Host "`nPASS: route decision resolved."
