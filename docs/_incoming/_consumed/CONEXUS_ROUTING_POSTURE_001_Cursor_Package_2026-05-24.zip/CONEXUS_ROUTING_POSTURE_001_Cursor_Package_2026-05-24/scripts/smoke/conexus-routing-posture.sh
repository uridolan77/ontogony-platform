#!/usr/bin/env bash
set -euo pipefail

BASE_URL="${BASE_URL:-http://localhost:5082}"
PROJECT_KEY="${PROJECT_KEY:-cx-dev-key-change-me}"
ADMIN_KEY="${ADMIN_KEY:-cx-conexus-admin-dev}"
ALIAS="${ALIAS:-risk-summary-v0}"

echo "Conexus routing posture smoke"
echo "BaseUrl: $BASE_URL"
echo "Alias: $ALIAS"

echo
echo "[1] Provider inventory"
curl -fsS "$BASE_URL/admin/v0/providers/inventory" \
  -H "X-Conexus-Admin-Key: $ADMIN_KEY" | jq .

echo
echo "[2] Route preview"
curl -fsS -X POST "$BASE_URL/v1/models/$ALIAS/route-preview" \
  -H "Authorization: Bearer $PROJECT_KEY" \
  -H "Content-Type: application/json" \
  -d '{"messages":[{"role":"user","content":"route preview smoke"}]}' | jq .

echo
echo "[3] Chat completion"
CHAT_JSON="$(curl -fsS -X POST "$BASE_URL/v1/chat/completions" \
  -H "Authorization: Bearer $PROJECT_KEY" \
  -H "Content-Type: application/json" \
  -d "{\"model\":\"$ALIAS\",\"messages\":[{\"role\":\"user\",\"content\":\"Smoke test Conexus route posture.\"}]}")"
echo "$CHAT_JSON" | jq .

MODEL_CALL_ID="$(echo "$CHAT_JSON" | jq -r '.id // empty')"
if [[ -z "$MODEL_CALL_ID" ]]; then
  echo "Chat response did not include id/modelCallId." >&2
  exit 1
fi

echo
echo "[4] Model call detail: $MODEL_CALL_ID"
curl -fsS "$BASE_URL/admin/v0/model-calls/$MODEL_CALL_ID" \
  -H "X-Conexus-Admin-Key: $ADMIN_KEY" | jq .

echo
echo "[5] Evidence links"
LINKS_JSON="$(curl -fsS "$BASE_URL/admin/v0/model-calls/$MODEL_CALL_ID/evidence-links" \
  -H "X-Conexus-Admin-Key: $ADMIN_KEY")"
echo "$LINKS_JSON" | jq .

ROUTE_DECISION_ID="$(echo "$LINKS_JSON" | jq -r '.routeDecisionId // .conexusRouteDecisionId // empty')"
if [[ -z "$ROUTE_DECISION_ID" ]]; then
  echo "Evidence links did not include routeDecisionId." >&2
  exit 1
fi

echo
echo "[6] Route decision detail: $ROUTE_DECISION_ID"
curl -fsS "$BASE_URL/admin/v0/route-decisions/$ROUTE_DECISION_ID" \
  -H "X-Conexus-Admin-Key: $ADMIN_KEY" | jq .

echo
echo "PASS: route decision resolved."
