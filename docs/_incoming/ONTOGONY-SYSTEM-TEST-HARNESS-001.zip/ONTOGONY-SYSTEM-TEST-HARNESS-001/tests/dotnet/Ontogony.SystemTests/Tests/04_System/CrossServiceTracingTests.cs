using FluentAssertions;
using Ontogony.SystemTests.Infrastructure;
using Xunit;

namespace Ontogony.SystemTests.Tests.System;

public sealed class CrossServiceTracingTests
{
    private readonly HarnessOptions _options = HarnessOptions.FromEnvironment();
    private readonly EvidenceWriter _evidence;

    public CrossServiceTracingTests() => _evidence = new EvidenceWriter(_options);

    [Fact]
    public async Task E2E_010_Correlation_Id_Should_Be_Visible_In_Run_Or_Event_Evidence()
    {
        var scenarioId = Correlation.NewScenarioId("E2E-010-correlation-chain");
        var payload = new
        {
            domain = "gaming-core",
            intent = "SummarizePlayerRisk",
            input = new { playerId = "sys-test-correlation-001", riskSignals = new[] { "trace_check" } }
        };

        using var http = new TestHttp();
        var response = await http.PostJsonAsync(_options.AllagmaBaseUrl, "/allagma/v0/runs", payload, scenarioId, bearer: _options.AllagmaServiceToken, idempotencyKey: scenarioId);
        var body = await response.Content.ReadAsStringAsync();
        await _evidence.WriteAsync(scenarioId, new { scenarioId, statusCode = (int)response.StatusCode, body, expectedCorrelationId = scenarioId });

        ((int)response.StatusCode).Should().BeInRange(200, 202);
        body.Should().ContainAny(scenarioId, "correlation", "trace", "run", "events");
    }
}
