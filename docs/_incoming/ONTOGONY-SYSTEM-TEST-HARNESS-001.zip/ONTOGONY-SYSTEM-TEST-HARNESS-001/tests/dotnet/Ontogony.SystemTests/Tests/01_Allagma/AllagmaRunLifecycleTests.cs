using FluentAssertions;
using Ontogony.SystemTests.Infrastructure;
using Xunit;

namespace Ontogony.SystemTests.Tests.Allagma;

public sealed class AllagmaRunLifecycleTests
{
    private readonly HarnessOptions _options = HarnessOptions.FromEnvironment();
    private readonly EvidenceWriter _evidence;

    public AllagmaRunLifecycleTests() => _evidence = new EvidenceWriter(_options);

    [Fact]
    public async Task E2E_001_Governed_Run_Should_Complete_Or_Reveal_Expected_Gate()
    {
        var scenarioId = Correlation.NewScenarioId("E2E-001-governed-run");
        var payload = new
        {
            domain = "gaming-core",
            intent = "SummarizePlayerRisk",
            input = new
            {
                playerId = "sys-test-player-001",
                riskSignals = new[] { "high_deposit_velocity", "recent_bonus_abuse_signal" },
                notes = "Deterministic system-test payload. No real player data."
            },
            requestedBy = "system-test-harness"
        };

        using var http = new TestHttp();
        var response = await http.PostJsonAsync(
            _options.AllagmaBaseUrl,
            "/allagma/v0/runs",
            payload,
            scenarioId,
            bearer: _options.AllagmaServiceToken,
            idempotencyKey: scenarioId);

        var body = await response.Content.ReadAsStringAsync();
        await _evidence.WriteAsync(scenarioId, new { scenarioId, statusCode = (int)response.StatusCode, body });

        ((int)response.StatusCode).Should().BeInRange(200, 202, "run should complete or be accepted/paused in the first harness calibration");
        body.Should().ContainAny("run", "Run", "id", "status", "completed", "waiting", "paused");
    }

    [Fact]
    public async Task E2E_002_Start_Run_Should_Be_Idempotent_For_Same_Key_And_Payload()
    {
        var scenarioId = Correlation.NewScenarioId("E2E-002-idempotent-run");
        var idempotencyKey = scenarioId;
        var payload = new
        {
            domain = "gaming-core",
            intent = "SummarizePlayerRisk",
            input = new { playerId = "sys-test-player-idem-001", riskSignals = new[] { "duplicate_retry_check" } }
        };

        using var http = new TestHttp();
        var first = await http.PostJsonAsync(_options.AllagmaBaseUrl, "/allagma/v0/runs", payload, scenarioId, bearer: _options.AllagmaServiceToken, idempotencyKey: idempotencyKey);
        var second = await http.PostJsonAsync(_options.AllagmaBaseUrl, "/allagma/v0/runs", payload, scenarioId, bearer: _options.AllagmaServiceToken, idempotencyKey: idempotencyKey);

        var firstBody = await first.Content.ReadAsStringAsync();
        var secondBody = await second.Content.ReadAsStringAsync();
        await _evidence.WriteAsync(scenarioId, new { scenarioId, firstStatus = (int)first.StatusCode, secondStatus = (int)second.StatusCode, firstBody, secondBody });

        ((int)first.StatusCode).Should().BeInRange(200, 202);
        ((int)second.StatusCode).Should().BeInRange(200, 202);
        secondBody.Should().NotBeNullOrWhiteSpace();
    }
}
