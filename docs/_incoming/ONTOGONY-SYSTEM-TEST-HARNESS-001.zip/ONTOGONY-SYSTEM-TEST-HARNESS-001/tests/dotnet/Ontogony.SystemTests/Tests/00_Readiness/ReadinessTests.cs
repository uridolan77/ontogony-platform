using Ontogony.SystemTests.Infrastructure;
using Xunit;

namespace Ontogony.SystemTests.Tests.Readiness;

public sealed class ReadinessTests
{
    private readonly HarnessOptions _options = HarnessOptions.FromEnvironment();
    private readonly EvidenceWriter _evidence;

    public ReadinessTests() => _evidence = new EvidenceWriter(_options);

    [Theory]
    [InlineData("platform", "ONTOGONY_PLATFORM_BASE_URL", "http://localhost:5080")]
    [InlineData("kanon", "KANON_BASE_URL", "http://localhost:5081")]
    [InlineData("conexus", "CONEXUS_BASE_URL", "http://localhost:5082")]
    [InlineData("allagma", "ALLAGMA_BASE_URL", "http://localhost:5083")]
    [InlineData("metabole", "METABOLE_BASE_URL", "http://localhost:5084")]
    [InlineData("aisthesis", "AISTHESIS_BASE_URL", "http://localhost:5085")]
    public async Task Health_Should_Return_Success(string service, string envKey, string defaultBaseUrl)
    {
        var scenarioId = Correlation.NewScenarioId($"READINESS-{service}-health");
        var baseUrl = Environment.GetEnvironmentVariable(envKey) ?? defaultBaseUrl;
        using var http = new TestHttp();
        var response = await http.GetAsync(baseUrl, "/health", scenarioId);
        await response.ShouldBeSuccessWithEvidence(service, scenarioId, _evidence);
    }

    [Theory]
    [InlineData("kanon", "KANON_BASE_URL", "http://localhost:5081")]
    [InlineData("conexus", "CONEXUS_BASE_URL", "http://localhost:5082")]
    [InlineData("allagma", "ALLAGMA_BASE_URL", "http://localhost:5083")]
    [InlineData("metabole", "METABOLE_BASE_URL", "http://localhost:5084")]
    [InlineData("aisthesis", "AISTHESIS_BASE_URL", "http://localhost:5085")]
    public async Task Ready_Should_Return_Success_For_Critical_Services(string service, string envKey, string defaultBaseUrl)
    {
        var scenarioId = Correlation.NewScenarioId($"READINESS-{service}-ready");
        var baseUrl = Environment.GetEnvironmentVariable(envKey) ?? defaultBaseUrl;
        using var http = new TestHttp();
        var response = await http.GetAsync(baseUrl, "/ready", scenarioId);
        await response.ShouldBeSuccessWithEvidence(service, scenarioId, _evidence);
    }
}
