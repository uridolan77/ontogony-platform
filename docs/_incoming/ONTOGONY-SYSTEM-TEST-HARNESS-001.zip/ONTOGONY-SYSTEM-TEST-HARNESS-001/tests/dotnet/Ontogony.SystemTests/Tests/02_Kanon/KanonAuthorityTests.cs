using FluentAssertions;
using Ontogony.SystemTests.Infrastructure;
using Xunit;

namespace Ontogony.SystemTests.Tests.Kanon;

public sealed class KanonAuthorityTests
{
    private readonly HarnessOptions _options = HarnessOptions.FromEnvironment();
    private readonly EvidenceWriter _evidence;

    public KanonAuthorityTests() => _evidence = new EvidenceWriter(_options);

    [Fact]
    public async Task Kanon_Protected_Route_Should_Reject_Missing_Token()
    {
        var scenarioId = Correlation.NewScenarioId("AUTH-kanon-missing-token");
        using var http = new TestHttp();
        var response = await http.PostJsonAsync(_options.KanonBaseUrl, "/ontology/v0/semantic-query-plans/compile", new { }, scenarioId);
        await response.ShouldBeUnauthorizedOrForbidden("kanon", scenarioId, _evidence);
    }

    [Fact]
    public async Task E2E_004_Kanon_Conexus_Assistance_Should_Stay_Advisory_When_Enabled()
    {
        var scenarioId = Correlation.NewScenarioId("E2E-004-kanon-assistance");
        var payload = new
        {
            contradictionId = "sys-test-contradiction-001",
            allowedFields = new[] { "summary", "sourceIds", "nonSensitiveNotes" },
            actorRoles = new[] { "tester", "operator" },
            context = new
            {
                summary = "Synthetic contradiction between two test-only canonical facts.",
                sourceIds = new[] { "sys-test-source-a", "sys-test-source-b" },
                nonSensitiveNotes = "No real user data."
            }
        };

        using var http = new TestHttp();
        var response = await http.PostJsonAsync(
            _options.KanonBaseUrl,
            "/ontology/v0/conexus/assistance/summarize-contradiction",
            payload,
            scenarioId,
            bearer: _options.KanonServiceToken,
            idempotencyKey: scenarioId);

        var body = await response.Content.ReadAsStringAsync();
        await _evidence.WriteAsync(scenarioId, new { scenarioId, statusCode = (int)response.StatusCode, body });

        ((int)response.StatusCode).Should().BeOneOf(200, 201, 202, 400, 404, 409, 422, 501,
            "first calibration may reveal route disabled/not seeded; final harness should require 2xx with draft_only");
        if ((int)response.StatusCode is >= 200 and < 300)
        {
            body.Should().ContainAny("draft", "draft_only", "advisory", "decision");
        }
    }
}
