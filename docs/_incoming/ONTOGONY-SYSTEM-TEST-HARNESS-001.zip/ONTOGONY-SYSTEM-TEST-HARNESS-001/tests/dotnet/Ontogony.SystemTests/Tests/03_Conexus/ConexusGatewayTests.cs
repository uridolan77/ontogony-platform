using FluentAssertions;
using Ontogony.SystemTests.Infrastructure;
using Xunit;

namespace Ontogony.SystemTests.Tests.Conexus;

public sealed class ConexusGatewayTests
{
    private readonly HarnessOptions _options = HarnessOptions.FromEnvironment();
    private readonly EvidenceWriter _evidence;

    public ConexusGatewayTests() => _evidence = new EvidenceWriter(_options);

    [Fact]
    public async Task Conexus_Chat_Completions_Should_Accept_Deterministic_Fake_Model_Alias()
    {
        var scenarioId = Correlation.NewScenarioId("CONEXUS-chat-completion");
        var payload = new
        {
            model = "risk-summary-v0",
            messages = new[]
            {
                new { role = "system", content = "You are a deterministic test assistant." },
                new { role = "user", content = "Return a short synthetic risk summary for system testing." }
            },
            stream = false
        };

        using var http = new TestHttp();
        var response = await http.PostJsonAsync(
            _options.ConexusBaseUrl,
            "/v1/chat/completions",
            payload,
            scenarioId,
            apiKey: _options.ConexusProjectApiKey,
            idempotencyKey: scenarioId);

        var body = await response.Content.ReadAsStringAsync();
        await _evidence.WriteAsync(scenarioId, new { scenarioId, statusCode = (int)response.StatusCode, body });
        ((int)response.StatusCode).Should().BeOneOf(200, 201, 202, 400, 401, 403, 404, 422,
            "first calibration may reveal auth/alias setup gaps; final harness should require 2xx");
    }

    [Fact]
    public async Task Conexus_Streaming_With_Idempotency_Key_Should_Be_Rejected_Or_Documented()
    {
        var scenarioId = Correlation.NewScenarioId("CONEXUS-streaming-idempotency");
        var payload = new
        {
            model = "risk-summary-v0",
            messages = new[] { new { role = "user", content = "stream test" } },
            stream = true
        };

        using var http = new TestHttp();
        var response = await http.PostJsonAsync(
            _options.ConexusBaseUrl,
            "/v1/chat/completions",
            payload,
            scenarioId,
            apiKey: _options.ConexusProjectApiKey,
            idempotencyKey: scenarioId);

        var body = await response.Content.ReadAsStringAsync();
        await _evidence.WriteAsync(scenarioId, new { scenarioId, statusCode = (int)response.StatusCode, body });
        ((int)response.StatusCode).Should().BeOneOf(400, 409, 422, "streaming idempotency must not silently pretend to be replay-safe");
    }
}
