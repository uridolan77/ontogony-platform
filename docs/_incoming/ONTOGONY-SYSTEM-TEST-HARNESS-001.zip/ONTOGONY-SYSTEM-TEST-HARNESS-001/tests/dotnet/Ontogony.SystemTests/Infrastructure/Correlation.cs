namespace Ontogony.SystemTests.Infrastructure;

public static class Correlation
{
    public static string NewScenarioId(string prefix) => $"{prefix}-{DateTimeOffset.UtcNow:yyyyMMddHHmmss}-{Guid.NewGuid():N}"[..Math.Min(64, $"{prefix}-{DateTimeOffset.UtcNow:yyyyMMddHHmmss}-{Guid.NewGuid():N}".Length)];

    public static void AddStandardHeaders(HttpRequestMessage request, string scenarioId, string? idempotencyKey = null)
    {
        request.Headers.TryAddWithoutValidation("X-Correlation-ID", scenarioId);
        request.Headers.TryAddWithoutValidation("X-Ontogony-Actor-Id", Environment.GetEnvironmentVariable("ONTOGONY_TEST_ACTOR_ID") ?? "system-test-harness");
        request.Headers.TryAddWithoutValidation("X-Ontogony-Actor-Type", Environment.GetEnvironmentVariable("ONTOGONY_TEST_ACTOR_TYPE") ?? "automation");
        request.Headers.TryAddWithoutValidation("X-Ontogony-Actor-Roles", Environment.GetEnvironmentVariable("ONTOGONY_TEST_ACTOR_ROLES") ?? "tester,operator,admin");
        if (!string.IsNullOrWhiteSpace(idempotencyKey))
        {
            request.Headers.TryAddWithoutValidation("Idempotency-Key", idempotencyKey);
        }
    }
}
