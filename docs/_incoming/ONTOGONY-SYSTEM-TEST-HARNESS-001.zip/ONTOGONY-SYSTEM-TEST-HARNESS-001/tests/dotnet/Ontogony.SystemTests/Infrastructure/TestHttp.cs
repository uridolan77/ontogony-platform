using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;

namespace Ontogony.SystemTests.Infrastructure;

public sealed class TestHttp : IDisposable
{
    private readonly HttpClient _client = new();
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web) { WriteIndented = true };

    public async Task<HttpResponseMessage> GetAsync(string baseUrl, string path, string scenarioId, string? bearer = null, string? apiKey = null)
    {
        using var request = new HttpRequestMessage(HttpMethod.Get, Combine(baseUrl, path));
        AddAuth(request, bearer, apiKey);
        Correlation.AddStandardHeaders(request, scenarioId);
        return await _client.SendAsync(request);
    }

    public async Task<HttpResponseMessage> PostJsonAsync(string baseUrl, string path, object payload, string scenarioId, string? bearer = null, string? apiKey = null, string? idempotencyKey = null)
    {
        using var request = new HttpRequestMessage(HttpMethod.Post, Combine(baseUrl, path));
        AddAuth(request, bearer, apiKey);
        Correlation.AddStandardHeaders(request, scenarioId, idempotencyKey);
        var json = JsonSerializer.Serialize(payload, JsonOptions);
        request.Content = new StringContent(json, Encoding.UTF8, "application/json");
        return await _client.SendAsync(request);
    }

    public static async Task<JsonDocument?> TryReadJsonAsync(HttpResponseMessage response)
    {
        var text = await response.Content.ReadAsStringAsync();
        if (string.IsNullOrWhiteSpace(text)) return null;
        try { return JsonDocument.Parse(text); }
        catch { return null; }
    }

    private static void AddAuth(HttpRequestMessage request, string? bearer, string? apiKey)
    {
        if (!string.IsNullOrWhiteSpace(bearer))
        {
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", bearer);
        }
        if (!string.IsNullOrWhiteSpace(apiKey))
        {
            request.Headers.TryAddWithoutValidation("Authorization", $"Bearer {apiKey}");
            request.Headers.TryAddWithoutValidation("X-API-Key", apiKey);
        }
    }

    private static string Combine(string baseUrl, string path) => baseUrl.TrimEnd('/') + "/" + path.TrimStart('/');
    public void Dispose() => _client.Dispose();
}
