# Prompt — ENV-CLOSEOUT-001

Use:

```text
04_PR_SPECS/ENV-CLOSEOUT-001.md
```

Before coding:

1. Verify current repo state.
2. Preserve safety boundaries.
3. Do not mix phases.
4. Add evidence docs.
5. Run listed verification commands.
6. Record exact results.
