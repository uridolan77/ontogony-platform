$ErrorActionPreference = "Stop"
$forbidden = @("canonization", "contradiction resolution", "provider ranking", "fallback strategy", "agent planning", "tool selection policy", "epistemic status", "retrieval relevance")
$files = Get-ChildItem -Recurse -Include *.cs,*.md | Where-Object { $_.FullName -notmatch "\bin\|\obj\|\.git\" }
$violations = @()
foreach ($file in $files) {
  $content = Get-Content $file.FullName -Raw
  foreach ($term in $forbidden) { if ($content -match [regex]::Escape($term)) { $violations += "$($file.FullName): $term" } }
}
if ($violations.Count -gt 0) { $violations | ForEach-Object { Write-Host $_ }; throw "Boundary validation failed" }
Write-Host "AI runtime boundary validation passed."
