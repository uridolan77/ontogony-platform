$ErrorActionPreference = "Stop"
$projects = @(
  "src/Ontogony.AI.Contracts/Ontogony.AI.Contracts.csproj",
  "src/Ontogony.Artifacts/Ontogony.Artifacts.csproj",
  "src/Ontogony.Execution/Ontogony.Execution.csproj",
  "src/Ontogony.Redaction/Ontogony.Redaction.csproj",
  "src/Ontogony.Knowledge.Contracts/Ontogony.Knowledge.Contracts.csproj",
  "src/Ontogony.Quota/Ontogony.Quota.csproj",
  "src/Ontogony.AI.Replay/Ontogony.AI.Replay.csproj",
  "src/Ontogony.Evaluation.Contracts/Ontogony.Evaluation.Contracts.csproj",
  "src/Ontogony.Policy.Contracts/Ontogony.Policy.Contracts.csproj"
)
foreach ($p in $projects) { if (Test-Path $p) { dotnet sln Ontogony.Platform.sln add $p } else { Write-Warning "Missing $p" } }
