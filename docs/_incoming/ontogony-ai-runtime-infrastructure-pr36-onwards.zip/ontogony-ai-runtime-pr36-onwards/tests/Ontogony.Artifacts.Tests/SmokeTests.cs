using Xunit;
namespace Ontogony_Artifacts_Tests;
public sealed class SmokeTests { [Fact] public void PackagePlaceholder() => Assert.True(true); }
