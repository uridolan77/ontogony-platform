using Xunit;
namespace Ontogony_Redaction_Tests;
public sealed class SmokeTests { [Fact] public void PackagePlaceholder() => Assert.True(true); }
