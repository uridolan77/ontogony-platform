using Xunit;
namespace Ontogony_Quota_Tests;
public sealed class SmokeTests { [Fact] public void PackagePlaceholder() => Assert.True(true); }
