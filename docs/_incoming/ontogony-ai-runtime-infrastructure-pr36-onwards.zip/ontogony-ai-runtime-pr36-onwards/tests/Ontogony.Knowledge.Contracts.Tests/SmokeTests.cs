using Xunit;
namespace Ontogony_Knowledge_Contracts_Tests;
public sealed class SmokeTests { [Fact] public void PackagePlaceholder() => Assert.True(true); }
