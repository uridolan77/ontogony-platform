using Xunit;
namespace Ontogony_AI_Replay_Tests;
public sealed class SmokeTests { [Fact] public void PackagePlaceholder() => Assert.True(true); }
