using Xunit;
namespace Ontogony_AI_Contracts_Tests;
public sealed class SmokeTests { [Fact] public void PackagePlaceholder() => Assert.True(true); }
