using Xunit;
namespace Ontogony_Execution_Tests;
public sealed class SmokeTests { [Fact] public void PackagePlaceholder() => Assert.True(true); }
