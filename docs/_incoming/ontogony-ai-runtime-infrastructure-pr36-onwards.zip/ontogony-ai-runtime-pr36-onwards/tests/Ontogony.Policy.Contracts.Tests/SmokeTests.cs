using Xunit;
namespace Ontogony_Policy_Contracts_Tests;
public sealed class SmokeTests { [Fact] public void PackagePlaceholder() => Assert.True(true); }
