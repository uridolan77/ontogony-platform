namespace Ontogony.Policy.Contracts;

public sealed record PolicyDecisionRecord(string DecisionId, string TraceId, string PolicyName, string Decision, string? InputHash, string? OutputHash, string? RuleRef, DateTimeOffset DecidedAt);
