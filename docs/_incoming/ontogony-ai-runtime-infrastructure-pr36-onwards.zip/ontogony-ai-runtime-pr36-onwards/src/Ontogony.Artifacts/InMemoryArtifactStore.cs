using System.Collections.Concurrent;
using System.Security.Cryptography;
namespace Ontogony.Artifacts;
public sealed class InMemoryArtifactStore : IArtifactStore
{
    private readonly ConcurrentDictionary<string, (byte[] Bytes, ArtifactDescriptor Descriptor)> _items = new();
    public async Task<ArtifactDescriptor> WriteAsync(string artifactId, Stream content, string contentType, IReadOnlyDictionary<string,string>? metadata = null, CancellationToken cancellationToken = default)
    {
        using var ms = new MemoryStream();
        await content.CopyToAsync(ms, cancellationToken);
        var bytes = ms.ToArray();
        var hash = Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant();
        var descriptor = new ArtifactDescriptor(new ArtifactRef { ArtifactId = artifactId, Uri = $"memory://{artifactId}", ContentType = contentType, Sha256 = hash, SizeBytes = bytes.Length }, DateTimeOffset.UtcNow, metadata);
        if (!_items.TryAdd(artifactId, (bytes, descriptor))) throw new InvalidOperationException($"Artifact already exists: {artifactId}");
        return descriptor;
    }
    public Task<Stream?> OpenReadAsync(string artifactId, CancellationToken cancellationToken = default) => Task.FromResult(_items.TryGetValue(artifactId, out var x) ? new MemoryStream(x.Bytes, false) : null);
    public Task<ArtifactDescriptor?> DescribeAsync(string artifactId, CancellationToken cancellationToken = default) => Task.FromResult(_items.TryGetValue(artifactId, out var x) ? x.Descriptor : null);
}
