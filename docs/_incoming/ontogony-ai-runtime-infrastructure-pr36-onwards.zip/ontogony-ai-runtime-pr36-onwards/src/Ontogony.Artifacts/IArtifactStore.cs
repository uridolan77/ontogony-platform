namespace Ontogony.Artifacts;
public interface IArtifactStore
{
    Task<ArtifactDescriptor> WriteAsync(string artifactId, Stream content, string contentType, IReadOnlyDictionary<string,string>? metadata = null, CancellationToken cancellationToken = default);
    Task<Stream?> OpenReadAsync(string artifactId, CancellationToken cancellationToken = default);
    Task<ArtifactDescriptor?> DescribeAsync(string artifactId, CancellationToken cancellationToken = default);
}
