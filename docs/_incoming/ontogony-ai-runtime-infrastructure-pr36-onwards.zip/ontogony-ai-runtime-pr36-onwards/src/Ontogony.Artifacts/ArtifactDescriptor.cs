namespace Ontogony.Artifacts;

public sealed record ArtifactDescriptor(ArtifactRef Ref, DateTimeOffset CreatedAt, IReadOnlyDictionary<string,string>? Metadata);
