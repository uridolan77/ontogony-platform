namespace Ontogony.Artifacts;
public sealed record ArtifactRef
{
    public required string ArtifactId { get; init; }
    public required string Uri { get; init; }
    public string? ContentType { get; init; }
    public string? Sha256 { get; init; }
    public long? SizeBytes { get; init; }
    public string? Kind { get; init; }
}
