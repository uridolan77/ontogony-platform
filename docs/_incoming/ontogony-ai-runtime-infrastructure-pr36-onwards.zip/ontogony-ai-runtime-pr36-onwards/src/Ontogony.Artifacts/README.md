# Ontogony.Artifacts

Artifact refs and in-memory store for large AI/runtime payloads.
