namespace Ontogony.Quota;

public sealed record QuotaScope(string ScopeType, string ScopeId, string? Metric);
public sealed record BudgetWindow(string WindowId, DateTimeOffset StartsAt, DateTimeOffset EndsAt, decimal Limit);
public sealed record QuotaDecision(bool Allowed, decimal CurrentUsage, decimal RequestedAmount, decimal Limit, string? ReasonCode);
public interface IQuotaStore { Task<QuotaDecision> TryConsumeAsync(QuotaScope scope, BudgetWindow window, decimal amount, CancellationToken cancellationToken = default); }
