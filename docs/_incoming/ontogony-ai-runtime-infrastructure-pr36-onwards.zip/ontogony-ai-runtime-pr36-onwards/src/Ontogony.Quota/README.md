# Ontogony.Quota

Generic quota and usage-window mechanics.
