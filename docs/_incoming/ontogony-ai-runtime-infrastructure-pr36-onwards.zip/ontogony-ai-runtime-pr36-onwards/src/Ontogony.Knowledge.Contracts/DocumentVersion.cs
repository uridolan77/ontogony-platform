using Ontogony.Artifacts;
namespace Ontogony.Knowledge.Contracts;

public sealed record DocumentVersion(string VersionId, string DocumentId, string? RawBytesHash, string? CanonicalTextHash, ArtifactRef? RawArtifact, DateTimeOffset RetrievedAt);
