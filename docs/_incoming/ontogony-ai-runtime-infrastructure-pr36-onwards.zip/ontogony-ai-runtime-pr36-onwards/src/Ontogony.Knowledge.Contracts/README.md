# Ontogony.Knowledge.Contracts

Mechanical source/document/chunk/embedding/corpus contracts. No epistemic meaning.
