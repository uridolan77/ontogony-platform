namespace Ontogony.Knowledge.Contracts;

public sealed record EmbeddingRef(string EmbeddingId, string ChunkId, string Provider, string Model, string? VectorHash, int? Dimensions, DateTimeOffset CreatedAt);
