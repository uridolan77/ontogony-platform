namespace Ontogony.Knowledge.Contracts;

public sealed record ChunkSpan(int? CharStart, int? CharEnd, int? TokenStart, int? TokenEnd);
