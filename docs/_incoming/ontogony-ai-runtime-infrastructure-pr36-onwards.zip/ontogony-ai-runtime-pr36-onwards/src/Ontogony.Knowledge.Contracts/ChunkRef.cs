namespace Ontogony.Knowledge.Contracts;

public sealed record ChunkRef(string ChunkId, string DocumentVersionId, int ChunkIndex, ChunkSpan? Span, string? TextHash);
