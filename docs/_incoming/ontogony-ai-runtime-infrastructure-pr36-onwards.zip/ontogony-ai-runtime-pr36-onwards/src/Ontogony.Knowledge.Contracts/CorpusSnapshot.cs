namespace Ontogony.Knowledge.Contracts;

public sealed record CorpusSnapshot(string SnapshotId, string CorpusId, IReadOnlyList<string> DocumentVersionIds, string? SnapshotHash, DateTimeOffset CreatedAt);
