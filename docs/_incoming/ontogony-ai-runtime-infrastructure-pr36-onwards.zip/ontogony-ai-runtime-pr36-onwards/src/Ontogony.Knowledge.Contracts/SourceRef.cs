namespace Ontogony.Knowledge.Contracts;

public sealed record SourceRef(string SourceId, string Uri, string? SourceType, IReadOnlyDictionary<string,string>? Metadata);
