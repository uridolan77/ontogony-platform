namespace Ontogony.Knowledge.Contracts;

public sealed record DocumentRef(string DocumentId, string SourceId, string? Uri, string? MimeType);
