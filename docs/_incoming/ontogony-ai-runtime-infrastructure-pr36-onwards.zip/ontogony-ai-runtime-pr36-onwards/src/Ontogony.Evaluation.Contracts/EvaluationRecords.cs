namespace Ontogony.Evaluation.Contracts;

public sealed record EvaluationRun(string EvaluationRunId, string TraceId, string EvaluationKind, DateTimeOffset StartedAt, DateTimeOffset? CompletedAt);
public sealed record EvaluationScore(string EvaluationRunId, string CaseId, string MetricName, decimal? NumericScore, string? Label, string? JudgeRef);
