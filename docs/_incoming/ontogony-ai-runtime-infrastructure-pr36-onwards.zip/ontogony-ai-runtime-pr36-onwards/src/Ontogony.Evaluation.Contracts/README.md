# Ontogony.Evaluation.Contracts

Evaluation result records. No evaluator logic.
