using Ontogony.Artifacts;
namespace Ontogony.AI.Replay;

public sealed record ReplayBundle(string ReplayId, string TraceId, string OperationName, ArtifactRef? RawInputArtifact, ArtifactRef? RedactedInputArtifact, ArtifactRef? RawOutputArtifact, ArtifactRef? RedactedOutputArtifact, IReadOnlyDictionary<string,string>? Environment, DateTimeOffset CreatedAt);
public sealed record ReplayDiff(string ReplayId, string BaselineReplayId, string? InputDiffHash, string? OutputDiffHash, IReadOnlyDictionary<string,string>? Metadata);
