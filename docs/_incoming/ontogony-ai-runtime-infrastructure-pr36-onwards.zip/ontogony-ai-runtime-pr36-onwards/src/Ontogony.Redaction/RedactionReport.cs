namespace Ontogony.Redaction;

public sealed record RedactionReport(int ReplacementCount, IReadOnlyList<string> RuleNames, string? OriginalHash, string? RedactedHash);
