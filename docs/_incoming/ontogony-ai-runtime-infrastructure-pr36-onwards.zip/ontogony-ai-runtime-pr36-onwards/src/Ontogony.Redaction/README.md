# Ontogony.Redaction

Structured redaction mechanics for AI runtime payloads.
