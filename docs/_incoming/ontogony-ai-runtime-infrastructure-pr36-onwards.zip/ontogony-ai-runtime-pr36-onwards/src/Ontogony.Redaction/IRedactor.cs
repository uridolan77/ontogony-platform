namespace Ontogony.Redaction;

public interface IRedactor { RedactionResult Redact(string input, IReadOnlyList<RedactionRule> rules); }
