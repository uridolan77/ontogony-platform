namespace Ontogony.Redaction;

public sealed record RedactionRule(string Name, string Pattern, string Replacement = "[REDACTED]", bool IsRegex = true);
