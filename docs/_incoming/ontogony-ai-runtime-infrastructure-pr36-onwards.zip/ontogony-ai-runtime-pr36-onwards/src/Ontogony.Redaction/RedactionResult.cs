namespace Ontogony.Redaction;

public sealed record RedactionResult(string RedactedText, RedactionReport Report);
