using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
namespace Ontogony.Redaction;
public sealed class RegexRedactor : IRedactor
{
    public RedactionResult Redact(string input, IReadOnlyList<RedactionRule> rules)
    {
        var output = input; var count = 0; var applied = new List<string>();
        foreach (var rule in rules)
        {
            var next = Regex.Replace(output, rule.Pattern, _ => { count++; return rule.Replacement; });
            if (!StringComparer.Ordinal.Equals(next, output)) applied.Add(rule.Name);
            output = next;
        }
        return new RedactionResult(output, new RedactionReport(count, applied, Sha256(input), Sha256(output)));
    }
    private static string Sha256(string text) => Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(text))).ToLowerInvariant();
}
