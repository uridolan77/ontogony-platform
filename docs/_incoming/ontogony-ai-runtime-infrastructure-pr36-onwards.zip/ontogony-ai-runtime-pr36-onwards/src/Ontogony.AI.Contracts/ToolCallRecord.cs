namespace Ontogony.AI.Contracts;

public sealed record ToolCallRecord(string ToolCallId, string ToolName, string? InputHash, string? OutputHash, string? Status, string? ErrorCode, DateTimeOffset? StartedAt, DateTimeOffset? CompletedAt);
