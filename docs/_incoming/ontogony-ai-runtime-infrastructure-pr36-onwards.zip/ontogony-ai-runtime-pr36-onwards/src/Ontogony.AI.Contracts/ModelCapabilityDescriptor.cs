namespace Ontogony.AI.Contracts;

public sealed record ModelCapabilityDescriptor(string Provider, string Model, bool SupportsStreaming, bool SupportsTools, bool SupportsJsonMode, int? MaxContextTokens, string? DescriptorVersion);
