namespace Ontogony.AI.Contracts;

public sealed record LlmUsageRecord(int? InputTokens, int? OutputTokens, int? TotalTokens, string? Tokenizer, string? ProviderUsageHash);
