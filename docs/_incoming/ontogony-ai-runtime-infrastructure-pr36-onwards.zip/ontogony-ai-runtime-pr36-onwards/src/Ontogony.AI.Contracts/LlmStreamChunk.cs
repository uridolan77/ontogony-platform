namespace Ontogony.AI.Contracts;

public sealed record LlmStreamChunk(string ChunkId, string RequestId, string TraceId, int Sequence, string? DeltaTextHash, string? ProviderChunkHash, bool IsFinal, DateTimeOffset ReceivedAt);
