# Ontogony.AI.Contracts

Provider-neutral LLM and tool-call records. No routing policy.
