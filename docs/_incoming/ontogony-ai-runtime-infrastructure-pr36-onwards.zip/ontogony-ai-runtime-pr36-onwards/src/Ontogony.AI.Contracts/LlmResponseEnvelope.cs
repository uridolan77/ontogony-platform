namespace Ontogony.AI.Contracts;

public sealed record LlmResponseEnvelope
{
    public required string ResponseId { get; init; }
    public required string RequestId { get; init; }
    public required string TraceId { get; init; }
    public required string Provider { get; init; }
    public required string Model { get; init; }
    public string? CompletionHash { get; init; }
    public string? RawProviderResponseHash { get; init; }
    public string? FinishReason { get; init; }
    public LlmUsageRecord? Usage { get; init; }
    public LlmCostRecord? Cost { get; init; }
    public IReadOnlyList<ToolCallRecord>? ToolCalls { get; init; }
    public LlmProviderError? Error { get; init; }
    public DateTimeOffset CompletedAt { get; init; }
}
