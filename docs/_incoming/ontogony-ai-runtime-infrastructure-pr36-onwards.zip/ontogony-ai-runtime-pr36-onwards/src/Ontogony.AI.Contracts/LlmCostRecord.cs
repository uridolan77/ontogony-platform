namespace Ontogony.AI.Contracts;

public sealed record LlmCostRecord(string? Currency, decimal? EstimatedCost, decimal? ActualCost, string? PriceCatalogVersion);
