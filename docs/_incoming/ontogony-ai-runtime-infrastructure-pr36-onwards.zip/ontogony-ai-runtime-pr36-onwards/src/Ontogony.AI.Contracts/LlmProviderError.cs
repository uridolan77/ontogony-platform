namespace Ontogony.AI.Contracts;

public sealed record LlmProviderError(string ErrorCode, string? ProviderErrorCode, string? SafeMessage, int? HttpStatusCode, bool IsRetryable);
