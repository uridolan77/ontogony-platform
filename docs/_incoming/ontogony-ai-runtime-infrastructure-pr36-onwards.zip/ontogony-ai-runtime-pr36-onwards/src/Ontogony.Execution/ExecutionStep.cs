namespace Ontogony.Execution;

public sealed record ExecutionStep(string StepId, string RunId, string? ParentStepId, string StepType, string Status, string? InputHash, string? OutputHash, DateTimeOffset StartedAt, DateTimeOffset? CompletedAt);
