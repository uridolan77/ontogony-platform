namespace Ontogony.Execution;
public interface IExecutionJournal
{
    Task AppendRunAsync(ExecutionRun run, CancellationToken cancellationToken = default);
    Task AppendStepAsync(ExecutionStep step, CancellationToken cancellationToken = default);
    Task AppendTransitionAsync(ExecutionTransition transition, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<ExecutionTransition>> ReadTransitionsAsync(string runId, CancellationToken cancellationToken = default);
}
