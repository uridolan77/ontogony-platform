namespace Ontogony.Execution;

public static class ExecutionStatuses { public const string Created="created"; public const string Started="started"; public const string Waiting="waiting"; public const string Completed="completed"; public const string Failed="failed"; public const string Cancelled="cancelled"; public const string TimedOut="timed_out"; }
