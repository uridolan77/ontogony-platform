# Ontogony.Execution

Generic execution journal. No agent planning semantics.
