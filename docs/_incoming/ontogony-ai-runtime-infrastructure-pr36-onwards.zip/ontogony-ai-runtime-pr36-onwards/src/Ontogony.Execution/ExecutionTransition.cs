namespace Ontogony.Execution;

public sealed record ExecutionTransition(string TransitionId, string RunId, string? StepId, string FromStatus, string ToStatus, DateTimeOffset OccurredAt, string? ReasonCode);
