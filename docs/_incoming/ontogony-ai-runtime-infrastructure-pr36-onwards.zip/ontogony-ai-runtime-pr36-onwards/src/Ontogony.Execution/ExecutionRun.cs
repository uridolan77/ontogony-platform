namespace Ontogony.Execution;

public sealed record ExecutionRun(string RunId, string TraceId, string OperationType, string Status, DateTimeOffset CreatedAt, DateTimeOffset? CompletedAt, IReadOnlyDictionary<string,string>? Metadata);
