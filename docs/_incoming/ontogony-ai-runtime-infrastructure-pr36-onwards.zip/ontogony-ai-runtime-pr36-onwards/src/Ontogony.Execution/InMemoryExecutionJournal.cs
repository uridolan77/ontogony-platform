using System.Collections.Concurrent;
namespace Ontogony.Execution;
public sealed class InMemoryExecutionJournal : IExecutionJournal
{
    private readonly ConcurrentDictionary<string, ExecutionRun> _runs = new();
    private readonly ConcurrentDictionary<string, ExecutionStep> _steps = new();
    private readonly ConcurrentDictionary<string, List<ExecutionTransition>> _transitions = new();
    public Task AppendRunAsync(ExecutionRun run, CancellationToken cancellationToken = default) { if (!_runs.TryAdd(run.RunId, run)) throw new InvalidOperationException($"Run already exists: {run.RunId}"); return Task.CompletedTask; }
    public Task AppendStepAsync(ExecutionStep step, CancellationToken cancellationToken = default) { if (!_steps.TryAdd(step.StepId, step)) throw new InvalidOperationException($"Step already exists: {step.StepId}"); return Task.CompletedTask; }
    public Task AppendTransitionAsync(ExecutionTransition transition, CancellationToken cancellationToken = default) { var list = _transitions.GetOrAdd(transition.RunId, _ => new List<ExecutionTransition>()); lock(list) list.Add(transition); return Task.CompletedTask; }
    public Task<IReadOnlyList<ExecutionTransition>> ReadTransitionsAsync(string runId, CancellationToken cancellationToken = default) { if (!_transitions.TryGetValue(runId, out var list)) return Task.FromResult<IReadOnlyList<ExecutionTransition>>(Array.Empty<ExecutionTransition>()); lock(list) return Task.FromResult<IReadOnlyList<ExecutionTransition>>(list.ToArray()); }
}
