# Ontogony AI Runtime Infrastructure — PR36 onwards

This is a comprehensive repo-overlay starter package for the next Ontogony.Platform phase: shared AI-runtime infrastructure for an LLM router, an agent runner, and a KB maintainer.

Core rule:

```text
Share mechanics. Do not share meaning.
```

The package contains:

- PR specs for PR36–PR43.
- ADRs and boundary guardrails.
- Cursor/Codex implementation prompts.
- C# package skeletons.
- Test project skeletons.
- scripts for solution insertion and boundary validation.

Recommended sequence:

| PR | Package | Purpose |
|---:|---|---|
| 36 | `Ontogony.AI.Contracts` | LLM request/response/usage/tool-call records |
| 37 | `Ontogony.Artifacts` | Durable artifact refs and in-memory artifact store |
| 38 | `Ontogony.Execution` | Generic execution journal |
| 39 | `Ontogony.Redaction` | Structured redaction mechanics |
| 40 | `Ontogony.Knowledge.Contracts` | Source/document/chunk/embedding/corpus contracts |
| 41 | `Ontogony.Quota` | Quotas, budgets, and usage counters |
| 42 | `Ontogony.AI.Replay` | Replay bundle contracts |
| 43 | `Ontogony.Evaluation.Contracts` + `Ontogony.Policy.Contracts` | Evaluation and policy-decision records |

Usage:

1. Copy selected `src/`, `tests/`, and `docs/` content into `ontogony-platform`.
2. Run `scripts/add-ai-runtime-projects.ps1`.
3. Add or adjust package references if the existing repo structure differs.
4. Update `CHANGELOG.md` and package docs.
5. Run restore/build/test/pack.

This overlay is intentionally mechanical. It does not include Conexus routing, Agentor orchestration, or Athanor canonization.
