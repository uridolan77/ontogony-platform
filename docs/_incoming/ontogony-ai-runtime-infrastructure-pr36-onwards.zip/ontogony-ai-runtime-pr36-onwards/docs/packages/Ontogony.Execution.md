# Ontogony.Execution

## Purpose

Shared AI-runtime infrastructure mechanics.

## Guarantees

- Serialization-friendly records.
- Trace/hash/artifact friendly fields where appropriate.
- No product-specific meaning.

## Non-goals

- No Conexus routing policy.
- No Agentor orchestration semantics.
- No Athanor canonization or epistemic logic.

## Status

Proposed for PR36+.
