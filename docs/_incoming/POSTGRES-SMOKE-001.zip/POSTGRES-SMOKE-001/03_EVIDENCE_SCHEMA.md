# 03 — Evidence schema

Aggregate evidence should be written by Allagma under:

```text
artifacts/postgres-smoke-001/<UTC_TIMESTAMP>/summary.json
```

Required fields:

```json
{
  "schema": "ontogony-postgres-smoke-001-summary-v1",
  "verdict": "PASS",
  "recordedAtUtc": "2026-05-26T00:00:00Z",
  "devRoot": "C:/dev",
  "repos": {
    "ontogony-platform": {
      "path": "C:/dev/ontogony-platform",
      "commit": "...",
      "verdict": "PASS",
      "connectionHint": "Host=localhost;Port=...;Database=...",
      "commands": []
    },
    "conexus-dotnet": {},
    "kanon-dotnet": {},
    "allagma-dotnet": {}
  },
  "systemSmoke": {
    "verdict": "PASS",
    "postgresBacked": true,
    "services": {
      "kanon": { "url": "http://localhost:5081", "ready": true },
      "conexus": { "url": "http://localhost:5082", "ready": true },
      "allagma": { "url": "http://localhost:5083", "ready": true }
    },
    "runId": "...",
    "evidenceFiles": []
  },
  "knownExclusions": [
    {
      "repo": "ontogony-platform",
      "surface": "product persistence",
      "reason": "Platform is mechanics-only; product persistence belongs to Conexus/Kanon/Allagma."
    }
  ]
}
```

Each command record should include:

```json
{
  "name": "kanon-postgres-semantic-smoke",
  "workingDirectory": "C:/dev/kanon-dotnet",
  "command": "pwsh ./scripts/run-postgres-semantic-smoke.ps1 -WriteCiEvidenceSummary",
  "exitCode": 0,
  "startedAtUtc": "...",
  "finishedAtUtc": "...",
  "stdoutTail": "optional",
  "stderrTail": "optional"
}
```
