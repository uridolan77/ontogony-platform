# Conexus prompt — Full gateway Postgres smoke

Repo: `conexus-dotnet`

## Goal

Extend Conexus `PersistenceSmoke` from migration reachability into full gateway persistence proof.

## Required test class

Add or extend:

```text
tests/Conexus.Persistence.Tests/ConexusPostgresFullSurfaceSmokeTests.cs
```

Trait:

```csharp
[Trait("Category", "PersistenceSmoke")]
```

## Required assertions

When `CONEXUS_POSTGRES_CONNECTION_STRING` or `ConnectionStrings__ConexusPostgres` is present:

1. Migrations apply and database can connect.
2. `provider.IsPersistenceEnabled()` is true.
3. Durable interfaces resolve to EF/Postgres implementations, not in-memory implementations.
4. Create or seed a project, API key, model alias, provider, route, and fallback route using the real application services/stores.
5. Run a fake-provider non-streaming chat completion through the API/application path using an `Idempotency-Key`.
6. Repeat the same request and assert replay behavior / no duplicate durable side effects.
7. Assert persisted rows/state exist for:
   - project/key
   - alias/routing/provider config
   - replay entry
   - `IIdempotencyLedger`
   - telemetry/model-call record
   - execution journal if registered
   - quota ledger if exercised
   - response cache if cache policy is enabled for the scenario
   - artifact store if registered
   - admin audit/maintenance history where appropriate
8. Dispose provider/host, recreate it with the same connection string, and assert the data is still readable.

## Fail-fast rule

The direct test may skip/no-op when no connection is configured to preserve default local tests. But a new script:

```text
scripts/run-postgres-smoke-001.ps1
```

must fail if no connection string is supplied.

## Evidence

Write:

```text
artifacts/postgres-smoke-001/conexus-summary.json
```

Include command, connection hint, test filter, and PASS/FAIL.

## Docs

Update:

- `docs/TESTING.md`
- `docs/CURRENT_STATE.md` if persistence coverage status changes
- `docs/KNOWN_LIMITATIONS.md` if any durable surface is intentionally not Postgres-backed
