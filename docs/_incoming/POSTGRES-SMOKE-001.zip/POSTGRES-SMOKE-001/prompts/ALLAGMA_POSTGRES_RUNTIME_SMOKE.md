# Allagma prompt — Full governed runtime Postgres smoke

Repo: `allagma-dotnet`

## Goal

Extend Allagma `Category=PersistenceSmoke` so it proves all durable governed execution state survives Postgres persistence and restart/provider recreation.

## Existing baseline to preserve

Keep this documented command valid:

```powershell
$env:ALLAGMA_TEST_POSTGRES = "Host=localhost;Port=5432;Database=allagma_persist_smoke;Username=postgres;Password=<secret>"
dotnet tool restore
./scripts/apply-allagma-postgres-migration.ps1 -ConnectionString $env:ALLAGMA_TEST_POSTGRES
dotnet test tests/Allagma.Tests/Allagma.Tests.csproj -c Release --no-build --filter "Category=PersistenceSmoke"
```

## Required additions

Add or extend tests:

```text
tests/Allagma.Tests/PostgresRuntimePersistenceSmokeTests.cs
```

Required surfaces:

1. Run creation and status transitions.
2. Run event stream persistence.
3. Human-gate paused/resumed state where represented in Allagma.
4. Replay records and cross-service replay metadata.
5. Durable execution queue item lifecycle.
6. Lease acquisition/release/expiration behavior.
7. Heartbeat updates.
8. Completion and dead-letter state.
9. Operator read APIs over persisted state.
10. Restart/recreated-provider survival.

## Required implementation checks

When `ALLAGMA_TEST_POSTGRES` is present:

- Assert configured persistence mode is Postgres.
- Assert durable services resolve to Postgres-backed implementations.
- Assert the test fails if any core durable runtime store resolves to in-memory.

## Evidence

Add script if missing:

```text
scripts/run-postgres-smoke-001.ps1
```

It should:

- Accept `-ConnectionString`.
- Apply migrations.
- Build if needed.
- Run `Category=PersistenceSmoke`.
- Write `artifacts/postgres-smoke-001/allagma-summary.json`.

## Docs

Update:

- `docs/TESTING.md`
- `docs/CURRENT_STATE.md` if coverage changes
- `docs/evidence/POSTGRES_SMOKE_001_ALLAGMA_EVIDENCE.md`
