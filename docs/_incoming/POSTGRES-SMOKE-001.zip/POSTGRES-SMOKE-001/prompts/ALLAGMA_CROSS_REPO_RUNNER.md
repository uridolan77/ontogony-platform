# Allagma prompt — Cross-repo POSTGRES-SMOKE-001 runner

Repo: `allagma-dotnet`

## Goal

Add the system-level orchestrator for POSTGRES-SMOKE-001.

## File to add

```text
scripts/system/run-postgres-smoke-001.ps1
```

## Parameters

```powershell
param(
  [string]$DevRoot = "C:\dev",
  [string]$PostgresHost = "localhost",
  [int]$PostgresPort = 55432,
  [string]$PostgresUser = "postgres",
  [string]$PostgresPassword = "postgres",
  [switch]$ResetDatabases,
  [switch]$SkipPlatform,
  [switch]$SkipSystemStack
)
```

## Databases

Use isolated DBs:

```text
ontogony_platform_postgres_smoke_001
conexus_postgres_smoke_001
kanon_postgres_smoke_001
allagma_postgres_smoke_001
```

## Required behavior

1. Validate sibling repos exist.
2. Generate connection strings.
3. Optionally reset databases using `dropdb/createdb`, `psql`, or Npgsql helper logic if available.
4. Run Platform mechanics smoke, unless skipped.
5. Run Conexus Postgres smoke.
6. Run Kanon Postgres semantic smoke.
7. Run Allagma Postgres runtime smoke.
8. Run Postgres-backed local-stack smoke:
   - Kanon uses its Postgres DB.
   - Conexus uses its Postgres DB.
   - Allagma uses its Postgres DB.
   - Allagma run completes through Kanon + Conexus fake/local provider.
   - Restart or recreate Allagma and verify run/events survive.
9. Write aggregate evidence JSON.
10. Exit non-zero if any command fails or evidence is missing.

## Do not

- Do not require real OpenAI/Anthropic/Gemini keys.
- Do not enable real tool execution.
- Do not treat Platform as product persistence owner.
- Do not silently skip a repo when the runner is invoked without an explicit skip switch.
