# Kanon prompt — Full semantic authority Postgres smoke

Repo: `kanon-dotnet`

## Goal

Extend the existing Kanon Postgres semantic smoke so it proves all semantic authority durable surfaces persist in Postgres mode.

## Existing baseline to preserve

Keep `scripts/run-postgres-semantic-smoke.ps1` working. It already builds Kanon, runs `PostgresSemanticSmoke`, runs contract gates, and can write CI evidence.

## Required additions

Add or extend tests under:

```text
tests/Kanon.Tests/PostgresSemanticSmokeTests.cs
```

or a new dedicated class:

```text
tests/Kanon.Tests/PostgresFullSemanticAuthoritySmokeTests.cs
```

Filter should still be picked up by:

```powershell
FullyQualifiedName~PostgresSemanticSmoke
```

or update the script to include the new class.

## Required persisted surfaces

Use the real Postgres repository configuration and assert write/read/recreate/read-again for:

1. Ontology versions and active ontology version state.
2. Domain pack validation/promotion/load/active lifecycle state.
3. Source bindings, review state, approval history, coverage/quality reads.
4. Semantic query plans and plan history.
5. Canonical fact resolution, selected/rejected source metadata, contradictions.
6. Per-source `confidence` in canonical fact sources.
7. Canonical fact audit entries.
8. Action policy decisions and denial reviews where durable.
9. Human gate check/resolve state.
10. Decision records, provenance, lifecycle transitions, replay bundles/export metadata.
11. Operator review queue rebuild/resolve state.
12. Semantic quality snapshots, baselines, and comparisons.
13. Conexus assistance decision records/review state with fake/stubbed Conexus assistance; no live model call required.

## Required safety assertions

- Do not call live Conexus or external provider keys.
- Do not introduce `/ontology/v1`.
- Do not add Allagma or Conexus implementation references.
- Keep Conexus assistance `draft_only`.

## Evidence

Either reuse `-WriteCiEvidenceSummary` or add:

```text
artifacts/postgres-smoke-001/kanon-summary.json
```

The summary must include the exact test filters and a non-empty Postgres connection hint.

## Docs

Update:

- `docs/TESTING.md`
- `docs/KNOWN_LIMITATIONS.md`
- `docs/evidence/POSTGRES_SMOKE_001_KANON_EVIDENCE.md`
