# Platform prompt — Postgres mechanics smoke

Repo: `ontogony-platform`

## Goal

Prove Platform-provided Postgres mechanics with product-neutral conformance tests. Do not add product semantics.

## Steps

1. Inspect `Ontogony.Persistence.Postgres`, `Ontogony.Idempotency`, `Ontogony.Artifacts`, and `Ontogony.Testing` conformance kits.
2. Verify which Postgres implementations actually exist in Platform.
3. If there is already a Postgres outbox conformance test gated by `ONTOGONY_POSTGRES_TEST_CONNECTION`, include it in the package evidence.
4. Add a small script if missing:

```text
scripts/run-postgres-mechanics-smoke.ps1
```

It should:

- Require `ONTOGONY_POSTGRES_TEST_CONNECTION` unless `-ConnectionString` is supplied.
- Build the relevant test project.
- Run only Postgres mechanics tests.
- Write `artifacts/postgres-smoke-001/platform-summary.json`.

5. Update docs/adoption/conformance-kits.md or TESTING.md with the new command.

## Acceptance

- Platform remains mechanics-only.
- Test does not require Conexus/Kanon/Allagma.
- Product persistence is explicitly out of scope.
- If only outbox has a Postgres implementation, say that plainly in the summary and do not fake coverage.
