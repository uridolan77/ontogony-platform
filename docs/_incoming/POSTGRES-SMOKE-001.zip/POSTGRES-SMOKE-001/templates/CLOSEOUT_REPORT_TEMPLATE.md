# POSTGRES-SMOKE-001 — Closeout report

**Date:** YYYY-MM-DD  
**Owner repo:** `allagma-dotnet`  
**Repos covered:** `ontogony-platform`, `conexus-dotnet`, `kanon-dotnet`, `allagma-dotnet`

## Verdict

PASS / PARTIAL / FAIL

## Summary

State what is now proven about Postgres persistence.

## Repo results

| Repo | Verdict | Command | Evidence |
|---|---|---|---|
| ontogony-platform | | | |
| conexus-dotnet | | | |
| kanon-dotnet | | | |
| allagma-dotnet | | | |

## System smoke

- Services started:
- Postgres-backed mode verified:
- Run ID:
- Restart/readback result:

## Durable surfaces proven

### Conexus

- ...

### Kanon

- ...

### Allagma

- ...

### Platform

- ...

## Known exclusions

| Repo | Surface | Reason | Future package? |
|---|---|---|---|

## Tests run

```powershell
# commands here
```

## Evidence artifacts

- `artifacts/postgres-smoke-001/<timestamp>/summary.json`

## Follow-up packages

- Optional follow-up items only; do not reopen POSTGRES-SMOKE-001 unless the proof is invalid.
