# 01 — Master Cursor prompt

Implement `POSTGRES-SMOKE-001` across all backend repos.

## Context

The Ontogony backend currently has a coherent division of responsibility:

```text
ontogony-platform = shared mechanics
conexus-dotnet    = model gateway / model-access authority
kanon-dotnet      = semantic authority
allagma-dotnet    = governed execution / runtime orchestrator
```

Each product backend supports in-memory development mode and Postgres mode. The goal here is to prove that Postgres mode covers the full durable surface in each repo and across the local three-service system.

## Scope

### In scope

- Postgres smoke tests.
- Migration application scripts.
- DI assertions that Postgres mode does not bind durable ports to in-memory stores.
- Restart/scope-recreation survival checks.
- Evidence JSON and closeout docs.
- Cross-repo Allagma-owned runner.
- Documentation updates to `TESTING.md`, `CURRENT_STATE.md`, and `KNOWN_LIMITATIONS.md` where needed.

### Out of scope

- Production hardening.
- Enterprise IAM.
- Real external LLM provider certification.
- Real tool execution.
- Replacing local in-memory development defaults.
- Introducing semantic/product concepts into `ontogony-platform`.

## Implementation order

1. **Survey current repo state**
   - Find existing Postgres tests, scripts, connection-string keys, migrations, and documentation.
   - Record findings in `docs/_incoming/_active/POSTGRES-SMOKE-001/IMPLEMENTATION_NOTES.md`.

2. **Platform mechanics smoke**
   - Verify reusable Postgres conformance harnesses.
   - Add a composite platform smoke script if missing.
   - Keep Platform product-neutral.

3. **Conexus full-surface Postgres smoke**
   - Extend existing `PersistenceSmoke` beyond migration reachability.
   - Assert EF-backed stores for projects, keys, routes, provider config, replay, response cache, idempotency ledger, telemetry, journal, quotas, artifacts, admin audit / maintenance history.
   - Prove restart/scope recreation survival.

4. **Kanon full semantic authority Postgres smoke**
   - Extend existing Postgres semantic smoke.
   - Cover ontology versions, domain packs, source bindings, semantic plans, canonical facts, fact audit, decisions, provenance, replay bundles, human gates, review queue, semantic quality, Conexus-assistance decision records.
   - Ensure per-source canonical fact `confidence` persists if the contract exposes it.

5. **Allagma full runtime Postgres smoke**
   - Extend existing `Category=PersistenceSmoke`.
   - Cover runs, run events, replay records, durable execution queue, leases, heartbeats, dead letters, operator APIs, human-gate paused/resumed state, model purpose metadata, and restart/replay evidence.

6. **Cross-repo runner in Allagma**
   - Add `scripts/system/run-postgres-smoke-001.ps1`.
   - Runner should execute repo-local smokes and then a Postgres-backed local-stack smoke.
   - Write evidence under `artifacts/postgres-smoke-001/<timestamp>/`.

7. **Docs and closeout**
   - Add closeout report in Allagma and repo-local evidence docs.
   - Update test matrices.
   - Update known limitations honestly.

## Hard acceptance

A PASS is valid only when:

- Every repo-local Postgres smoke ran with a non-empty Postgres connection string.
- Tests fail fast if connection string is missing when launched through the POSTGRES-SMOKE-001 runner.
- Service providers/hosts in Postgres mode assert expected durable implementations, not in-memory substitutes.
- Restart/scope-recreation checks prove data survival.
- Evidence JSON contains real command exit codes and test result summaries.
