# Closeout checklist

## Global

- [ ] All four repos were surveyed before code changes.
- [ ] In-memory default tests still pass.
- [ ] Repo-local Postgres smokes require a real connection when invoked by package runner.
- [ ] Repo-local tests do not silently pass as no-ops under package runner.
- [ ] Evidence JSON is written and schema-valid.
- [ ] Known limitations updated honestly.

## Platform

- [ ] Mechanics-only boundary preserved.
- [ ] Postgres conformance smoke documented and runnable.
- [ ] Product persistence explicitly out of scope.

## Conexus

- [ ] Migration reachability smoke preserved.
- [ ] Full-surface smoke added.
- [ ] EF/Postgres implementation assertions added.
- [ ] Replay/idempotency/cache/telemetry/quota/journal/artifact/audit surfaces covered or exclusions documented.
- [ ] Restart/provider recreation survival proven.

## Kanon

- [ ] Existing semantic smoke script preserved.
- [ ] Full semantic authority durable surfaces covered.
- [ ] Per-source confidence persistence covered.
- [ ] Decision/provenance/replay/human-gate/review/quality states covered.
- [ ] No `/ontology/v1` or forbidden implementation refs introduced.

## Allagma

- [ ] PersistenceSmoke covers run/event/replay/durable execution engine.
- [ ] Migration script preserved.
- [ ] Restart/recreated provider survival proven.
- [ ] Cross-repo runner added under `scripts/system/`.
- [ ] Postgres-backed local-stack/system smoke added.

## Closeout

- [ ] `docs/reviews/POSTGRES_SMOKE_001_CLOSEOUT_REPORT.md` added to Allagma.
- [ ] Repo-local evidence docs added where appropriate.
- [ ] All commands and test counts recorded.
- [ ] Any intentional non-Postgres surface is named and justified.
