# 00 — Unpack prompt

You are working in the Ontogony backend workspace.

Unpack `POSTGRES-SMOKE-001` into the active repo according to the target slice:

- For cross-repo orchestration, unpack into `allagma-dotnet/docs/_incoming/packages/POSTGRES-SMOKE-001/`.
- For repo-local implementation, copy the relevant prompt into that repo’s `docs/_incoming/_active/POSTGRES-SMOKE-001/IMPLEMENTATION_NOTES.md` and preserve the package under `docs/_incoming/packages/POSTGRES-SMOKE-001/` if the repo already follows that pattern.

Do not implement blindly. First verify current repo state against the package assumptions:

1. Current persistence mode names and connection-string keys.
2. Existing Postgres smoke tests and scripts.
3. Existing EF migrations and DbContext registration.
4. Existing in-memory fallback behavior.
5. Existing evidence/artifact conventions.

Then implement only the missing pieces.

Do not remove in-memory development mode. This package is about proving Postgres mode, not forcing all local development to use Postgres.
