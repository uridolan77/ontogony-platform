# POSTGRES-SMOKE-001 — Cross-backend Postgres persistence proof

## Purpose

Create a cross-repo persistence smoke baseline proving that Ontogony backend durable state really survives through PostgreSQL in Postgres mode, and that no service silently falls back to in-memory stores when a Postgres connection is configured.

This package covers the four backend repos:

- `ontogony-platform` — shared mechanics and reusable conformance harnesses only.
- `conexus-dotnet` — model gateway persistence.
- `kanon-dotnet` — semantic authority persistence.
- `allagma-dotnet` — governed execution/runtime persistence and system-level orchestration.

## Non-negotiable rule

When a service is configured for Postgres persistence, every durable service-owned state surface must be backed by Postgres or explicitly documented as non-durable / intentionally in-memory.

The package must not remove in-memory development mode. It must prove that Postgres mode is complete, durable, observable, and testable.

## Desired final state

One command from `allagma-dotnet` runs the full cross-backend persistence smoke:

```powershell
./scripts/system/run-postgres-smoke-001.ps1 -DevRoot C:\dev -ResetDatabases
```

It should:

1. Start or validate a local Postgres instance.
2. Prepare isolated databases for Platform mechanics, Conexus, Kanon, and Allagma smoke tests.
3. Apply migrations where required.
4. Run repo-local Postgres smoke suites.
5. Run a real three-service local-stack smoke with Conexus, Kanon, and Allagma all configured for Postgres.
6. Restart relevant service processes or recreate service providers.
7. Assert persisted data survives restart / scope recreation.
8. Write machine-readable evidence under `artifacts/postgres-smoke-001/<timestamp>/summary.json`.

## Definition of done

- Platform mechanics Postgres conformance smoke is present or explicitly declared not applicable per package.
- Conexus PersistenceSmoke covers all durable gateway stores, not just migration reachability.
- Kanon Postgres semantic smoke covers all semantic authority durable state including confidence-bearing canonical fact sources.
- Allagma PersistenceSmoke covers all run/event/replay/durable execution engine state.
- Cross-repo Allagma-owned runner executes all repo smokes and a Postgres-backed system smoke.
- No product repo reports PASS when a configured Postgres store silently resolves to an in-memory implementation.
- Evidence JSON includes repo commits, connection hints, test filters, verdicts, and known exclusions.

## Files in this package

| File | Purpose |
|---|---|
| `00_UNPACK_PROMPT.md` | Generic Cursor unpack prompt |
| `01_MASTER_CURSOR_PROMPT.md` | Full implementation prompt |
| `02_ACCEPTANCE_MATRIX.md` | Repo-by-repo requirements |
| `03_EVIDENCE_SCHEMA.md` | Required evidence JSON shape |
| `prompts/PLATFORM_POSTGRES_MECHANICS_SMOKE.md` | Platform-specific prompt |
| `prompts/CONEXUS_POSTGRES_FULL_SURFACE_SMOKE.md` | Conexus-specific prompt |
| `prompts/KANON_POSTGRES_SEMANTIC_AUTHORITY_SMOKE.md` | Kanon-specific prompt |
| `prompts/ALLAGMA_POSTGRES_RUNTIME_SMOKE.md` | Allagma-specific prompt |
| `prompts/ALLAGMA_CROSS_REPO_RUNNER.md` | System runner prompt |
| `scripts/run-postgres-smoke-001.ps1.template` | PowerShell runner skeleton |
| `contracts/postgres-smoke-001-summary.schema.json` | Summary schema starter |
| `checklists/CLOSEOUT_CHECKLIST.md` | Completion checklist |
| `templates/CLOSEOUT_REPORT_TEMPLATE.md` | Closeout report template |
