# 02 — Acceptance matrix

## Global

| Requirement | Acceptance |
|---|---|
| In-memory dev mode remains | Existing default tests still pass without Postgres |
| Postgres smoke is opt-in | Default CI filters may exclude it, but POSTGRES-SMOKE-001 runner includes it |
| No silent fallback | Postgres-mode smoke fails if durable stores resolve to in-memory implementations |
| Evidence | Each repo writes a summary JSON or contributes to the Allagma aggregate summary |
| Restart / recreated scope | At least one test per product repo proves persisted state survives process/provider recreation |
| Migrations | Smoke applies or verifies migrations before durability checks |
| Isolation | Uses disposable smoke DB names or schema cleanup; does not require production DB |

## ontogony-platform

Platform is not a product persistence owner. Acceptance is mechanical:

- Postgres conformance path exists for any Platform-provided Postgres implementation.
- At minimum, outbox Postgres conformance is runnable when `ONTOGONY_POSTGRES_TEST_CONNECTION` is set.
- If idempotency/artifact Postgres implementations do not exist in Platform, document that product repos own their EF implementations or intentionally use product persistence.
- Add `scripts/run-postgres-mechanics-smoke.ps1` only if useful; do not add product concepts.

## conexus-dotnet

Required persisted surfaces:

- Projects and project API keys.
- Model aliases/catalog.
- Provider configs, routes, overrides, fallback data.
- Chat completion replay for non-streaming `Idempotency-Key`.
- Protocol-neutral `IIdempotencyLedger`.
- Response cache policy and entries when cache is enabled.
- Telemetry/model-call rows.
- Execution journal rows.
- Quota ledger rows.
- Artifact store rows if registered through Postgres.
- Admin audit and maintenance/retention history where implemented.

Smoke must include:

- Migration apply + DB reachability.
- DI implementation assertions.
- Write/read/recreate-provider/read-again survival.
- One fake-provider chat completion with `Idempotency-Key`, repeated to prove replay.
- At least one quota/telemetry/journal assertion.

## kanon-dotnet

Required persisted surfaces:

- Ontology versions and active version state.
- Domain pack lifecycle / promotion / active load state.
- Source bindings, review state, quality/coverage reads.
- Semantic query plans and history.
- Canonical facts, selected/rejected source metadata, contradictions, audit entries.
- Per-source confidence for canonical facts when supplied.
- Action policy evaluations / denial reviews where durable.
- Human gates check/resolve state.
- Decision records, provenance, lifecycle transitions, replay bundles.
- Operator review queue state.
- Semantic quality snapshots, baselines, comparisons.
- Conexus assistance decision records/review state if enabled in tests with fake gateway.

Smoke must include:

- Existing `run-postgres-semantic-smoke.ps1` remains valid.
- Add missing durable-surface assertions.
- Fail if `KANON_TEST_POSTGRES` is absent when launched by POSTGRES-SMOKE-001 runner.
- Evidence summary written under `artifacts/postgres-smoke-001/kanon-summary.json` or equivalent.

## allagma-dotnet

Required persisted surfaces:

- Runs and run status.
- Run events / event stream.
- Human-gate paused/resumed state.
- Replay records and cross-service replay metadata.
- Durable execution engine: queue item, lease, heartbeat, completion, dead-letter.
- Eval evidence records if persisted by backend.
- System cohesion evidence references where stored.

Smoke must include:

- Migration apply.
- DI implementation assertions.
- Run creation + events + recreate provider/host + read again.
- Durable execution queue lifecycle survival.
- Replay record survival.
- Restart E2E path with Postgres.

## allagma-dotnet cross-repo runner

Allagma owns system orchestration.

The runner must:

- Accept `-DevRoot`.
- Locate sibling repos.
- Accept or create four isolated database names.
- Export expected env vars for each repo.
- Run Platform, Conexus, Kanon, Allagma local smokes.
- Run Postgres-backed local stack with all product services configured for Postgres.
- Produce aggregate `summary.json`.
- Exit non-zero on any failed repo or missing required evidence file.
