# FE-POLISH-001 — Frontend readiness/polish pass

## Repo

- `ontogony-frontend`

## Goal

Make the frontend coherent, trustworthy, and sanity-test-ready.

## Scope

- navigation cleanup
- empty/degraded states
- fixture/live banners
- loading/error/retry states
- unknown metrics/events safe display
- responsive layout
- accessibility labels
- e2e test IDs
- remove stale limitation banners
- preserve honest unsupported-feature banners

## Required checks

- run detail shows sandbox evidence
- run detail shows topology evidence
- run detail shows eval evidence
- eval dashboard loads fixture and live modes distinctly
- model-call evidence fallback is honest
- no raw prompt/completion/secret content

## Evidence

Add:

```text
docs/evidence/FE_POLISH_001_FRONTEND_READINESS_EVIDENCE.md
```
