# SYS-FULL-SANITY-001 — First full sanity test

## Goal

Run and document the first full cross-repo sanity test of the eval-governed loop.

## Scenario

Use:

```text
scenario-risk-summary-v0
```

## Flow

```text
start services
check health
run baseline Allagma run: single_workflow
run subject Allagma run: centralized_orchestrator override
confirm Kanon topology authorization
confirm Conexus model-call/route evidence
write evaluation records
create baseline comparison
open frontend run detail and eval dashboard
export evidence artifacts
```

## Required artifacts

```text
artifacts/full-sanity/full-sanity-report.json
artifacts/full-sanity/evaluation-runs.json
artifacts/full-sanity/baseline-comparison.json
artifacts/full-sanity/frontend-screenshots/
docs/evidence/SYS_FULL_SANITY_001_REPORT.md
```

## Pass criteria

- services healthy
- topology evidence present
- Kanon decision ID present
- route/model evidence present or documented non-fatal fallback
- evaluation records written
- baseline comparison written
- frontend displays evidence
- no safety boundary violated
