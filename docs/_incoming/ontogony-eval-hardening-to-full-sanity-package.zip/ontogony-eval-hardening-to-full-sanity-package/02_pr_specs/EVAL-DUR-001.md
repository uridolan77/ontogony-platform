# EVAL-DUR-001 — Durable eval/baseline persistence

## Repo

- `allagma-dotnet`

## Goal

Move evaluation runs and baseline comparisons from in-memory-only to durable persistence.

## Tables

### `allagma_evaluation_runs`

Columns:

```text
evaluation_run_id text primary key
subject_run_id text not null
trace_id text null
scenario_id text null
evaluation_profile_id text null
verdict text null
quality_score numeric null
source_kind text null
writer_version text null
contract_version text null
started_at_utc timestamptz null
completed_at_utc timestamptz null
record_json jsonb not null
created_at_utc timestamptz not null
```

Indexes:

```text
subject_run_id
scenario_id
evaluation_profile_id
source_kind
completed_at_utc
```

### `allagma_baseline_comparisons`

Columns:

```text
comparison_id text primary key
subject_run_id text not null
baseline_run_id text null
scenario_id text null
baseline_mode text null
subject_mode text null
promotion_recommendation text null
policy_equivalent boolean null
side_effect_safe boolean null
quality_delta numeric null
cost_delta_usd numeric null
latency_delta_ms bigint null
record_json jsonb not null
created_at_utc timestamptz not null
```

## Required behavior

- implement Postgres `IEvaluationRunRepository`
- implement Postgres `IBaselineComparisonRepository`
- preserve JSON contract round-trip
- deterministic list ordering
- idempotent save behavior defined and tested
- no raw prompts/secrets/marker payloads

## Tests

```text
Save_get_evaluation_run_roundtrips
List_by_subject_run_orders_latest_first
Save_get_baseline_comparison_roundtrips
Duplicate_save_behavior_is_defined
Source_metadata_preserved
No_raw_marker_content_in_record_json
```

## Evidence

Add:

```text
docs/evidence/EVAL_DUR_001_DURABLE_EVAL_PERSISTENCE.md
```
