# BE-POLISH-001 — Backend readiness/polish pass

## Repos

- `allagma-dotnet`
- `conexus-dotnet`
- `kanon-dotnet`
- optional: `ontogony-platform`

## Goal

Prepare backend contracts and behavior for first full sanity test.

## Allagma

- OpenAPI snapshot/provenance current
- duplicate-key validator covers snapshots
- eval list/query endpoints support dashboards
- durable persistence documented
- consistent error envelopes
- manual eval POST gating tested
- safety gates consolidated

## Conexus

- route/model-call evidence documented
- route-decision fields documented
- structured 404/401 behavior if aligned with conventions
- no raw prompt/completion/secret leakage
- OpenAPI current

## Kanon

- topology authorization endpoint documented
- decision/provenance linkage documented
- OpenAPI current

## Evidence

Add:

```text
docs/evidence/BE_POLISH_001_BACKEND_READINESS_EVIDENCE.md
```
