# FE-EVAL-002 — Richer eval dashboards and trend views

## Repo

- `ontogony-frontend`

## Goal

Move from run-level eval visibility to dashboard-level operator visibility.

## Routes

Preferred:

```text
/allagma/evaluations
/allagma/evaluations/:evaluationRunId
/allagma/evaluations/baseline-comparisons/:comparisonId
```

## Views

### Evaluation overview

Show:

```text
pass/fail/inconclusive counts
latest CI suite verdict
route evidence resolvability
baseline recommendations
safety failures
```

### Scenario matrix

Columns:

```text
scenarioId
datasetVersion
latest verdict
quality score
selected topology
baseline mode
promotion recommendation
route evidence state
last run time
```

### Baseline comparison view

Show:

```text
baseline run
subject run
topology modes
quality/cost/latency deltas
policy equivalence
side-effect safety
promotion recommendation
linked evidence
```

## Backend dependencies

Preferred APIs:

```text
GET /allagma/v0/evaluations
GET /allagma/v0/evaluations?scenarioId=&verdict=&sourceKind=
GET /allagma/v0/evaluations/baseline-comparisons
```

If unavailable, show honest limitation state. Do not fake live dashboards.

## Tests

- dashboard adapter tests
- component tests
- fixture banner tests
- empty/degraded backend tests
- e2e route smoke
- no raw content rendering

## Evidence

Add:

```text
docs/evidence/FE_EVAL_002_DASHBOARDS_EVIDENCE.md
```
