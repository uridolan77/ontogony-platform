# ALIGN-EVAL-001 — Backend/frontend eval contract alignment refresh

## Repos

- all relevant repos

## Goal

Refresh cross-repo alignment after eval durability, CI, quality, dataset, and dashboard work.

## Add package in `ontogony-platform`

```text
docs/alignment/eval-full-sanity-alignment/
  00_MANIFEST.json
  01_BACKEND_CONTRACT_SNAPSHOT.md
  02_FRONTEND_CONSUMPTION_MATRIX.md
  03_EVAL_DATASET_MATRIX.md
  04_OPENAPI_PROVENANCE.md
  05_CAPABILITY_LIMITATION_MATRIX.md
  06_FULL_SANITY_TEST_PLAN.md
  07_KNOWN_LIMITATIONS.md
```

## Acceptance

- no undocumented live frontend dependency
- no stale limitation banner
- no OpenAPI drift
- all evidence docs linked
- full sanity test scriptable
