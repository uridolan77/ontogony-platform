# EVAL-FIX-001 — Baseline correctness and immediate route-evidence polish

## Repos

- `allagma-dotnet`
- `ontogony-frontend`
- optional: `conexus-dotnet`

## Goal

Fix the known baseline-comparison scenario mismatch issue and polish route evidence display.

## Allagma work

Replace the no-op scenario mismatch branch in `BaselineComparisonService.CompareAsync` with a real guard:

```csharp
var baselineScenario = ResolveScenarioId(baselineRun);
var subjectScenario = ResolveScenarioId(subjectRun);

if (!string.Equals(scenarioId, baselineScenario, StringComparison.Ordinal)
    || !string.Equals(scenarioId, subjectScenario, StringComparison.Ordinal))
{
    throw new InvalidOperationException(
        $"Baseline comparison scenario mismatch. requested='{scenarioId}', baseline='{baselineScenario}', subject='{subjectScenario}'.");
}
```

Tests:

```text
BaselineComparison_rejects_when_baseline_scenario_differs
BaselineComparison_rejects_when_subject_scenario_differs
BaselineComparison_allows_when_both_match_requested_scenario
```

## Frontend work

Render already available route metrics in the model-call evidence card:

```text
route_evidence_resolvable
route_provider_key
route_provider_model
route_requested_model_alias
route_fallback_used
estimated_cost_usd
model_latency_ms
```

Select latest evaluation deterministically:

```text
completedAtUtc desc
startedAtUtc desc
fallback to server order with label
```

## Acceptance

- mismatch test fails before fix and passes after
- API returns operator-safe validation error
- frontend still distinguishes fixture vs live
- no raw prompts/completions/secrets displayed
