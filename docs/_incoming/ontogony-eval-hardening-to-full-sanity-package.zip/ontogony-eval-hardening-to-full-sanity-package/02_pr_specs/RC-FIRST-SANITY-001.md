# RC-FIRST-SANITY-001 — First full sanity closeout

## Goal

Close the milestone honestly.

## Deliverables

```text
docs/releases/FIRST_FULL_SANITY_CLOSEOUT.md
docs/releases/FIRST_FULL_SANITY_SCORECARD.md
docs/releases/FIRST_FULL_SANITY_KNOWN_LIMITATIONS.md
docs/releases/NEXT_PHASE_RECOMMENDATIONS.md
```

## Required statement

```text
This is first full sanity, not production readiness.
```

## Next-phase options

- expand eval datasets
- deepen route-decision records
- add calibrated judge workflows
- add trend analytics
- polish backend/frontend product readiness
- only later consider new topology modes or controlled real executor work
