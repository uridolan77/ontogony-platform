# EVAL-DATA-001 — Scenario dataset management

## Repo

- `allagma-dotnet`
- optional schema docs in `ontogony-platform`

## Goal

Promote fixture cases into versioned scenario datasets.

## Dataset structure

```text
docs/evals/datasets/scenario-dataset-v0/
  dataset.json
  cases/
  expected/
  baselines/
  labels/
  README.md
```

## Dataset manifest

```json
{
  "schema": "allagma-eval-scenario-dataset-v1",
  "datasetId": "scenario-dataset-v0",
  "version": "0.1.0",
  "owner": "allagma",
  "defaultProfileId": "eval-profile-v0",
  "tags": ["topology", "sandbox", "route-evidence"],
  "compatibility": {
    "requiresConexusRouteEvidence": false,
    "requiresKanonTopologyPolicy": true
  },
  "cases": []
}
```

## Add

```text
EvaluationScenarioDatasetLoader
EvaluationScenarioDatasetValidator
scripts/validate-eval-dataset.ps1
```

## Tests

- dataset manifest validates
- every case has expected output
- required events map to known event vocabulary
- dataset version present
- fixture/live source rules enforced
- baseline references existing case IDs

## Evidence

Add:

```text
docs/evidence/EVAL_DATA_001_SCENARIO_DATASET_EVIDENCE.md
```
