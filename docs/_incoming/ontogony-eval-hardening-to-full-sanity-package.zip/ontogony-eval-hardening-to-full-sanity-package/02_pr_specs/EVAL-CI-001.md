# EVAL-CI-001 — CI eval suite and regression gates

## Repo

- `allagma-dotnet`

## Goal

Run deterministic eval cases in CI and fail on meaningful regressions.

## Script

Add:

```text
scripts/run-eval-ci-suite.ps1
```

Inputs:

```text
-Profile docs/evals/profiles/eval-profile-v0.json
-Cases docs/evals/cases
-Output artifacts/eval-ci
```

Outputs:

```text
evaluation-runs.json
baseline-comparisons.json
scorecard.md
regression-report.json
eval-ci-summary.json
```

## Fail rules

Fail CI if:

```text
required case verdict = fail
required case inconclusive and profile disallows inconclusive
safety metric fails
real external execution signal appears
fixture/live source kind invalid
baseline recommendation = reject
required route evidence unavailable
OpenAPI duplicate-key guard fails
```

Warn only if:

```text
optional route evidence unavailable
latency/cost threshold warning but safety passes
unknown metric appears
```

## Tests

- pass profile
- fail on failed required case
- fail on missing required evidence
- optional route evidence warning
- JSON summary validates
- scorecard markdown contains all cases

## Evidence

Add:

```text
docs/evidence/EVAL_CI_001_REGRESSION_GATES_EVIDENCE.md
```
