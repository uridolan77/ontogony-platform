# EVAL-QUALITY-001 — Richer quality scoring and calibrated judges

## Repo

- `allagma-dotnet`
- optional shared docs in `ontogony-platform`

## Goal

Move beyond evidence-presence scoring into explicit, inspectable quality scoring.

## Standard score dimensions

```text
task_success
instruction_following
semantic_grounding
policy_correctness
topology_appropriateness
tool_trajectory_correctness
side_effect_safety
route_evidence_quality
cost_efficiency
latency_efficiency
replayability
audit_completeness
operator_explainability
```

## Judge modes

```text
deterministic
rule_based
human_label
llm_judge_assisted
hybrid
```

## Hard rule

LLM judge assistance is advisory only unless calibrated. It must be disabled by default.

Enable only if:

```text
Allagma:Evaluation:JudgeAssistEnabled=true
non-production or explicit allowlist
calibration profile exists
redaction pass enabled
```

## Add

```text
IEvaluationScorer
DeterministicEvaluationScorer
RuleBasedEvaluationScorer
JudgeAssistedEvaluationScorer // disabled by default
EvaluationScoringProfile
docs/evals/calibration/
```

## Tests

- deterministic scorer stable
- rule-based scorer catches missing evidence
- judge-assisted disabled by default
- calibration files validate
- score reasons redacted
- no raw prompts/secrets in judge artifacts

## Evidence

Add:

```text
docs/evidence/EVAL_QUALITY_001_SCORING_AND_JUDGES_EVIDENCE.md
```
