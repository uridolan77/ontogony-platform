# FE-EVAL-002 Dashboard Wireframe

## Evaluation dashboard

```text
Eval Dashboard
PASS | FAIL | INCONCLUSIVE | Route evidence resolvability | Latest CI verdict
Scenario Matrix
Baseline Recommendations
Safety Signals
```

## Evaluation detail

Show:

```text
verdict
quality score
scores
metrics
sourceKind
scenario/dataset
linked run
linked route evidence
linked baseline comparison
redaction note
```

## Baseline comparison detail

Show:

```text
baseline run
subject run
topology modes
quality/cost/latency delta
policy equivalence
side-effect safety
promotion recommendation
linked evidence
```
