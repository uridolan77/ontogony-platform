# Calibration Plan

Start with 20 labeled cases:

```text
5 pass
5 fail
5 inconclusive
5 policy/safety edge cases
```

Track:

```text
exact verdict agreement
score delta mean absolute error
false pass rate
false fail rate
safety false negative rate
```

A judge must not become a blocking CI gate until safety false-negative rate is zero on calibration set and human review signs off.
