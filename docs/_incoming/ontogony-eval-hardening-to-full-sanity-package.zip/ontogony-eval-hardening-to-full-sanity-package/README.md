# Ontogony Eval Hardening → First Full Sanity Package

This package starts after the first eval-basing rollout. The system already has evaluation records, deterministic fixtures, baseline comparison, frontend eval/topology visibility, and Conexus route evidence. The next work is to make this durable, CI-gated, richer in quality scoring, dataset-managed, dashboard-visible, polished, aligned, and finally sanity-tested end-to-end.

## Recommended sequence

```text
0. EVAL-FIX-001        — immediate correctness/polish patch
1. EVAL-DUR-001        — durable eval/baseline persistence
2. EVAL-CI-001         — CI eval suite and regression gates
3. EVAL-QUALITY-001    — richer quality scoring and calibrated judges
4. EVAL-DATA-001       — scenario dataset management
5. FE-EVAL-002         — richer eval dashboards and trend views
6. BE-POLISH-001       — backend readiness polish
7. FE-POLISH-001       — frontend readiness polish
8. ALIGN-EVAL-001      — backend/frontend eval alignment refresh
9. SYS-FULL-SANITY-001 — first full sanity test
10. RC-FIRST-SANITY-001 — milestone closeout
```

## Strategic rule

Do not add more agent topologies yet. Make the current eval loop durable, repeatable, measurable, explainable, and operator-readable first.
