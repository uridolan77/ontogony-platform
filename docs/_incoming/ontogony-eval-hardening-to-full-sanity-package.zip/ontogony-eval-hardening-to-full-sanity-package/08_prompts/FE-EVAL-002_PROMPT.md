# Prompt — FE-EVAL-002

Use `02_pr_specs/FE-EVAL-002.md`.

Before coding:
1. Verify current repo state.
2. Read the PR spec.
3. Preserve safety boundaries.
4. Add or update tests.
5. Update OpenAPI/provenance if contracts/routes change.
6. Add evidence markdown.
7. Record commands and results.

Do not mix unrelated phases.
