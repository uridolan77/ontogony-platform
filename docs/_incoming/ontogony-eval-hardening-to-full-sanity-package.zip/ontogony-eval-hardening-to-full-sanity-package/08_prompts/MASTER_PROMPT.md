# Master Prompt — Eval Hardening to First Full Sanity

We are continuing after the first eval-basing rollout.

Current baseline:
- Allagma evaluation writer exists.
- Allagma deterministic eval fixtures exist.
- Allagma baseline comparison exists.
- Frontend eval/topology panel exists.
- Conexus model-call route evidence exists.
- Safety gates passed.

Mission:
Implement the next sequence:

```text
EVAL-FIX-001
EVAL-DUR-001
EVAL-CI-001
EVAL-QUALITY-001
EVAL-DATA-001
FE-EVAL-002
BE-POLISH-001
FE-POLISH-001
ALIGN-EVAL-001
SYS-FULL-SANITY-001
RC-FIRST-SANITY-001
```

Rules:
- no real external execution
- no raw unsafe content
- fixtures never appear as live evidence
- Ontogony.Platform remains neutral
- do not add new topology modes yet
