# Dependency Graph

```mermaid
flowchart TD
  A[EVAL-FIX-001] --> B[EVAL-DUR-001]
  B --> C[EVAL-CI-001]
  C --> D[EVAL-QUALITY-001]
  D --> E[EVAL-DATA-001]
  E --> F[FE-EVAL-002]
  F --> G[BE-POLISH-001]
  F --> H[FE-POLISH-001]
  G --> I[ALIGN-EVAL-001]
  H --> I
  I --> J[SYS-FULL-SANITY-001]
  J --> K[RC-FIRST-SANITY-001]
```

Durability comes before CI. CI comes before richer judges. Dataset management comes before dashboards. Polish comes before alignment. Alignment comes before the full sanity test.
