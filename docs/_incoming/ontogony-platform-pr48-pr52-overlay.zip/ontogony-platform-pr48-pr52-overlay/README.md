# Ontogony Platform PR48–PR52 Overlay

This overlay adds five mechanical platform modules before starting Conexus.NET:

1. `Ontogony.Logging`
2. `Ontogony.Redaction`
3. `Ontogony.Secrets`
4. `Ontogony.Quotas`
5. `Ontogony.Replay.Contracts`

The overlay is intentionally platform-level and provider/product-neutral. It adds shared contracts, helpers, in-memory/reference implementations, tests, and package docs. It does **not** add Conexus routing policy, pricing logic, model preference, UI, durable storage, or vendor-specific log/exporter bindings.

## Apply

From the `ontogony-platform` repo root:

```powershell
# copy overlay files into the repo
Copy-Item -Recurse -Force .\overlay\* .

# add projects to solution
dotnet sln Ontogony.Platform.sln add `
  src/Ontogony.Logging/Ontogony.Logging.csproj `
  src/Ontogony.Redaction/Ontogony.Redaction.csproj `
  src/Ontogony.Secrets/Ontogony.Secrets.csproj `
  src/Ontogony.Quotas/Ontogony.Quotas.csproj `
  src/Ontogony.Replay.Contracts/Ontogony.Replay.Contracts.csproj `
  tests/Ontogony.Logging.Tests/Ontogony.Logging.Tests.csproj `
  tests/Ontogony.Redaction.Tests/Ontogony.Redaction.Tests.csproj `
  tests/Ontogony.Secrets.Tests/Ontogony.Secrets.Tests.csproj `
  tests/Ontogony.Quotas.Tests/Ontogony.Quotas.Tests.csproj `
  tests/Ontogony.Replay.Contracts.Tests/Ontogony.Replay.Contracts.Tests.csproj

dotnet restore Ontogony.Platform.sln
dotnet build Ontogony.Platform.sln -c Release
dotnet test Ontogony.Platform.sln -c Release
```

## Existing-file updates still required

This overlay does not overwrite current repo files. After copying, update:

- `README.md`: package count 18 → 23; add modules to package list and layer map.
- `docs/packages/index.md`: package count 18 → 23; add package sections.
- `docs/architecture/package-levels.md`: add the five packages and dependencies to the matrix.
- `scripts/validate-package-levels.ps1`: add five expected package IDs and allowed references.
- `scripts/validate-shipping-inventory.ps1`: expected shipping count 18 → 23.
- `scripts/pack-all.ps1`: expected package count 18 → 23, if hardcoded.
- `.github/workflows/ci.yml`: no new package versions needed, but validation scripts must reflect 23 packages.
- `CHANGELOG.md`: add the snippet in `docs/overlay/CHANGELOG_SNIPPET.md`.

See `docs/overlay/INTEGRATION_GUIDE.md` for exact suggested layer placement.
