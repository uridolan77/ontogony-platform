# Prompt: start SYSTEM-PROTO-000

We are starting the Ontogony multi-repo protocol hardening sequence.

Repos:

- `uridolan77/allagma-dotnet`
- `uridolan77/kanon-dotnet`
- `uridolan77/conexus-dotnet`
- `uridolan77/ontogony-platform`
- `uridolan77/ontogony-frontend`

Use the unpacked package as canonical input:

```text
C:\dev\allagma-dotnet\docs\_incoming\Ontogony_System_Protocols_Package_2026-05-20
```

Read first:

- `00_README.md`
- `01_EXECUTIVE_SUMMARY.md`
- `02_PROTOCOL_ARCHITECTURE.md`
- `03_PROTOCOL_LAYER_MATRIX.md`
- `04_MULTI_REPO_PR_SEQUENCE.md`
- `pr-specs/SYSTEM-PROTO-000_PROTOCOL_INVENTORY.md`

Task:

Implement `SYSTEM-PROTO-000` as an audit/documentation PR.

Produce:

```text
docs/protocols/SYSTEM_PROTOCOL_INVENTORY.md
docs/protocols/SYSTEM_PROTOCOL_GAP_REPORT.md
docs/protocols/SYSTEM_PROTOCOL_DECISION_LOG.md
```

Rules:

- Do not implement runtime behavior yet.
- Do not enable real external tool execution.
- Do not focus on enterprise security or production readiness.
- Do not move semantics into Ontogony.Platform.
- Do not collapse Allagma/Kanon/Conexus boundaries.
- Do not introduce Agentor naming.
- Every identified gap must map to a future `SYSTEM-PROTO-*` PR.

Validation:

Run the relevant existing tests for touched repos and report exact files changed, commands run, pass/fail output, and unresolved protocol gaps.
