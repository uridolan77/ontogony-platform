# Unpack and start

```powershell
cd C:\dev\allagma-dotnet

Expand-Archive `
  -LiteralPath "C:\dev\allagma-dotnet\docs\_incoming\Ontogony_System_Protocols_Package_2026-05-20.zip" `
  -DestinationPath "C:\dev\allagma-dotnet\docs\_incoming\Ontogony_System_Protocols_Package_2026-05-20" `
  -Force
```

Then use `prompts/START_SYSTEM_PROTO_000.md`.
