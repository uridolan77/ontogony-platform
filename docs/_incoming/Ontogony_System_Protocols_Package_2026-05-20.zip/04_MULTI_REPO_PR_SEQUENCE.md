# Multi-repo PR sequence

| PR | Primary repo | Secondary repos | Goal | Risk |
| --- | --- | --- | --- | --- |
| `SYSTEM-PROTO-000` | allagma-dotnet | all repos | Protocol inventory and gap report | Low |
| `SYSTEM-PROTO-001` | ontogony-platform | all services + frontend | Identifier/header protocol | Medium |
| `SYSTEM-PROTO-002` | allagma-dotnet | kanon, conexus, frontend | Mutation/idempotency protocol | Medium |
| `SYSTEM-PROTO-003` | ontogony-platform | all services + frontend | Error envelope protocol | Medium |
| `SYSTEM-PROTO-004` | allagma-dotnet | kanon, conexus, frontend | Event envelope and vocabularies | Medium |
| `SYSTEM-PROTO-005` | all services | frontend | Runtime posture and capabilities | Medium |
| `SYSTEM-PROTO-006` | all services | frontend | Evidence link protocol | Medium |
| `SYSTEM-PROTO-007` | ontogony-frontend | all services | Frontend route/workflow protocol | Low/Medium |
| `SYSTEM-PROTO-008` | platform or allagma | all repos | Cross-repo conformance harness | Medium |

## Branch names

```text
system-proto-000-inventory
system-proto-001-identifiers-headers
system-proto-002-idempotency-boundaries
system-proto-003-error-envelope
system-proto-004-event-vocabulary
system-proto-005-runtime-posture
system-proto-006-evidence-links
system-proto-007-frontend-workflow-protocol
system-proto-008-conformance-harness
```

## Rule

Every protocol PR should update at least one of:

- protocol document
- schema
- conformance test
- route/workflow catalog
- evidence index
