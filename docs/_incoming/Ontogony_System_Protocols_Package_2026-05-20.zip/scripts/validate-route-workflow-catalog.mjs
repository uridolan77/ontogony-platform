#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";

const repo = process.argv[2] ?? process.cwd();
const catalogPath = path.join(repo, "src", "app", "route-workflow-catalog.json");

if (!fs.existsSync(catalogPath)) {
  console.error(`Missing route workflow catalog: ${catalogPath}`);
  process.exit(1);
}

const catalog = JSON.parse(fs.readFileSync(catalogPath, "utf8"));
const routes = [...(catalog.routes ?? []), ...(catalog.paramRoutes ?? [])];
const errors = [];
const warnings = [];

for (const route of routes) {
  for (const field of ["path", "page", "dataSource", "backendRoutes", "settings"]) {
    if (!(field in route)) errors.push(`${route.path ?? "<unknown>"} missing ${field}`);
  }
  if ((route.backendRoutes ?? []).length === 0 && route.dataSource !== "static") {
    warnings.push(`${route.path} has no backend routes`);
  }
  if (route.dataSource?.includes("fixture") && !route.dataSourceNotes) {
    warnings.push(`${route.path} is fixture-backed without notes`);
  }
}

const report = {
  schema: "ontogony-route-workflow-catalog-validation-v0",
  checkedAt: new Date().toISOString(),
  routeCount: routes.length,
  errors,
  warnings
};

console.log(JSON.stringify(report, null, 2));
if (errors.length) process.exit(1);
