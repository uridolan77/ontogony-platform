param(
  [string]$AllagmaRepo = "C:\dev\allagma-dotnet",
  [string]$KanonRepo = "C:\dev\kanon-dotnet",
  [string]$ConexusRepo = "C:\dev\conexus-dotnet",
  [string]$PlatformRepo = "C:\dev\ontogony-platform",
  [string]$FrontendRepo = "C:\dev\ontogony-frontend",
  [string]$OutputDir = "artifacts\system-protocols",
  [switch]$Live
)

$ErrorActionPreference = "Stop"
$checks = [System.Collections.ArrayList]::new()

function Add-Check($status, $description, $path = "", $message = "") {
  [void]$checks.Add([ordered]@{
    status = $status
    description = $description
    path = $path
    message = $message
  })
}

function Check-Path($path, $description) {
  if (Test-Path $path) { Add-Check "pass" $description $path }
  else { Add-Check "warn" $description $path "Missing path" }
}

Check-Path "$AllagmaRepo\src\Allagma.Api\Program.cs" "Allagma API entry point"
Check-Path "$KanonRepo\src\Kanon.Api\Program.cs" "Kanon API entry point"
Check-Path "$ConexusRepo\src\Conexus.Api\Program.cs" "Conexus API entry point"
Check-Path "$PlatformRepo\src" "Platform src"
Check-Path "$FrontendRepo\src\app\route-workflow-catalog.json" "Frontend route workflow catalog"

$protocolDocs = @(
  "$AllagmaRepo\docs\protocols\SYSTEM_PROTOCOL_INVENTORY.md",
  "$AllagmaRepo\docs\protocols\SYSTEM_PROTOCOL_GAP_REPORT.md",
  "$PlatformRepo\docs\protocols\IDENTIFIERS_V1.md",
  "$PlatformRepo\docs\protocols\HEADERS_V1.md",
  "$PlatformRepo\docs\protocols\ERROR_ENVELOPE_V1.md",
  "$PlatformRepo\docs\protocols\EVENT_ENVELOPE_V1.md"
)

foreach ($doc in $protocolDocs) {
  Check-Path $doc "Protocol doc: $([IO.Path]::GetFileName($doc))"
}

$routeCatalog = "$FrontendRepo\src\app\route-workflow-catalog.json"
if (Test-Path $routeCatalog) {
  $content = Get-Content $routeCatalog -Raw
  foreach ($needle in @("/allagma/v0/runs", "/ontology/v0/decision-records", "/admin/v0/model-calls")) {
    if ($content.Contains($needle)) { Add-Check "pass" "Route catalog references $needle" }
    else { Add-Check "warn" "Route catalog references $needle" "" "Missing reference" }
  }
}

$summary = [ordered]@{
  schema = "ontogony-system-protocol-conformance-v0"
  generatedAt = (Get-Date).ToUniversalTime().ToString("o")
  live = [bool]$Live
  repos = [ordered]@{
    allagma = $AllagmaRepo
    kanon = $KanonRepo
    conexus = $ConexusRepo
    platform = $PlatformRepo
    frontend = $FrontendRepo
  }
  checks = $checks
  totals = [ordered]@{
    pass = @($checks | Where-Object { $_.status -eq "pass" }).Count
    warn = @($checks | Where-Object { $_.status -eq "warn" }).Count
    fail = @($checks | Where-Object { $_.status -eq "fail" }).Count
  }
}

New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null
$jsonPath = Join-Path $OutputDir "protocol-conformance-report.json"
$mdPath = Join-Path $OutputDir "protocol-conformance-report.md"
$summary | ConvertTo-Json -Depth 10 | Set-Content -Path $jsonPath -Encoding UTF8

$lines = @("# Protocol conformance report", "", "Generated: $($summary.generatedAt)", "", "| Status | Description | Detail |", "| --- | --- | --- |")
foreach ($check in $checks) {
  $detail = if ($check.path) { $check.path } elseif ($check.message) { $check.message } else { "" }
  $lines += "| $($check.status) | $($check.description) | $detail |"
}
$lines | Set-Content -Path $mdPath -Encoding UTF8

Write-Host "Wrote $jsonPath"
Write-Host "Wrote $mdPath"
if ($summary.totals.fail -gt 0) { exit 1 }
