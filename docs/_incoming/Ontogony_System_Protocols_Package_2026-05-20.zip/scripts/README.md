# Scripts

## `validate-system-protocols.ps1`

Starter cross-repo conformance script.

```powershell
./scripts/validate-system-protocols.ps1 `
  -AllagmaRepo C:\dev\allagma-dotnet `
  -KanonRepo C:\dev\kanon-dotnet `
  -ConexusRepo C:\dev\conexus-dotnet `
  -PlatformRepo C:\dev\ontogony-platform `
  -FrontendRepo C:\dev\ontogony-frontend
```

## `validate-route-workflow-catalog.mjs`

Starter frontend route catalog validator.

```powershell
node scripts/validate-route-workflow-catalog.mjs C:\dev\ontogony-frontend
```
