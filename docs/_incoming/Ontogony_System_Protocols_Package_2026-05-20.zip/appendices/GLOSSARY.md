# Glossary

## Allagma
Governed execution runtime.

## Kanon
Semantic authority.

## Conexus
Model gateway.

## Ontogony.Platform
Shared mechanics.

## Runtime posture
Read-only service self-description: API prefixes, protocol versions, feature flags, persistence, downstream configuration, evidence routes, and warnings.

## Evidence link
Typed reference from one evidence object to another across systems.

## Route/workflow catalog
Frontend declaration of how a route is backed by API clients, settings, capabilities, evidence, mutations, and live/fixture data.
