# Protocol decision template

## Decision ID
`PROTO-DEC-YYYYMMDD-NNN`

## Status
Proposed | Accepted | Superseded | Deferred

## Context
What protocol gap or ambiguity required a decision?

## Decision
What is the rule?

## Applies to
Identity | Headers | Idempotency | Errors | Events | Runtime posture | Evidence links | Frontend workflow

## Repos affected
Allagma | Kanon | Conexus | Platform | Frontend

## Consequences
What must change?

## Validation
How is drift prevented?
