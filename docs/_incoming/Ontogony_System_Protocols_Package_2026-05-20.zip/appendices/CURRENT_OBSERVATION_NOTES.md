# Current observation notes

These notes are planning context only. `SYSTEM-PROTO-000` must verify the current repo state again.

## Allagma

Allagma exposes a broad `/allagma/v0` API surface for runs, events, audit, capabilities, operations, retry/cancel/replay, evaluations, datasets, evidence, and baseline comparisons. It calls Kanon for semantic/policy authority and Conexus for model calls.

## Kanon

Kanon owns ontology, semantic plans, action policies, human gates, decision records, provenance, and Conexus assistance.

## Conexus

Conexus owns model-call identity, route decisions, provider/fallback chain, usage/cost, and model-call evidence.

## Platform

Platform owns mechanics and is the likely home for generic protocol schemas, headers, envelopes, and validators.

## Frontend

Frontend already has settings, service health, Allagma clients, Allagma pages, evidence spine, and route-workflow catalog.
