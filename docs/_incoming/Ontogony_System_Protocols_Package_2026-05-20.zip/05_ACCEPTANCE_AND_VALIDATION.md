# Acceptance and validation

## Existing validation commands

Allagma:

```powershell
dotnet build Allagma.sln -c Release --no-restore
dotnet test Allagma.sln -c Release --no-build --filter "Category!=CrossRepo&Category!=PersistenceSmoke"
```

Kanon:

```powershell
dotnet build Kanon.sln -c Release --no-restore
dotnet test Kanon.sln -c Release --no-build
```

Conexus:

```powershell
dotnet build Conexus.sln -c Release --no-restore -p:NoWarn=CS1591
dotnet test Conexus.sln -c Release --no-build -p:NoWarn=CS1591 --filter "Category!=ExternalProviderSmoke&Category!=LoadSoak&Category!=PersistenceSmoke"
```

Platform:

```powershell
dotnet build Ontogony.Platform.sln -c Release --no-restore
dotnet test Ontogony.Platform.sln -c Release --no-build
```

Frontend:

```powershell
npm test
npm run typecheck
npm run lint
```

## Protocol validation targets

- Identifier names are canonical.
- Header propagation is tested on representative cross-service paths.
- Required mutation idempotency is documented and tested.
- System errors normalize into one frontend type.
- Events use known vocabulary and identifier slots.
- Runtime posture is read-only and secret-free.
- Evidence links are typed and resolvable.
- Frontend route catalog validates against service routes/snapshots.
