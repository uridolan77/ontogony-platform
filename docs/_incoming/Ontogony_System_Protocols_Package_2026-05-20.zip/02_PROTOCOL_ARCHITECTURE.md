# Protocol architecture

## Strategic ownership rule

```text
Share mechanics. Do not share meaning.
```

| Repo | Owns | Must not own |
| --- | --- | --- |
| `ontogony-platform` | Tracing, headers, idempotency primitives, HTTP, errors, observability, redaction, artifacts, generic contracts | Product semantics |
| `conexus-dotnet` | Model gateway, aliases, provider routing, route decisions, model-call telemetry, usage/cost | Semantic policy or execution orchestration |
| `kanon-dotnet` | Ontology, semantic plans, action policy, human gates, decisions, provenance | Model provider routing or agent runtime |
| `allagma-dotnet` | Governed execution, runs, steps, tool intents, lifecycle operations, evaluations, audit | Semantic authority or provider routing |
| `ontogony-frontend` | Operator workflows, settings, route catalog, evidence spine, live/fallback presentation | Backend authority or policy decisions |

## Protocol layers

```text
L1 Identity
L2 Headers and context propagation
L3 Mutation and idempotency
L4 Error envelope
L5 Event envelope and vocabulary
L6 Runtime posture and capability discovery
L7 Evidence links and evidence graph
L8 Frontend route/workflow contract
```

Every future change should declare which layers it touches.

## Boundaries

### Allagma -> Kanon

Allagma asks for planning, topology/action authorization, and human-gate checks. Kanon owns allow/deny/human-gate. Allagma must not infer permission from LLM output.

### Allagma -> Conexus

Allagma asks for model completion/streaming through model purposes. Conexus owns alias resolution, provider routing, route decisions, and model-call evidence.

### Kanon -> Conexus

Kanon may request model assistance. Conexus output is draft/supporting material only; Kanon remains authority for semantic acceptance.

### Frontend -> services

The frontend reads capabilities, invokes operator-safe mutations, and displays evidence. It must not become authority-bearing.
