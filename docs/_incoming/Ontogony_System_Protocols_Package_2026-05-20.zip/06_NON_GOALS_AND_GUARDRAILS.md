# Non-goals and guardrails

## Non-goals

- Production readiness
- Enterprise security
- Rate limiting
- Secret rotation
- External provider hardening
- Real external tool execution
- Major API v1 graduation
- UI redesign
- Background runner implementation

## Guardrails

1. Do not enable real external tool execution.
2. Do not collapse Allagma/Kanon/Conexus ownership boundaries.
3. Do not put product semantics in Ontogony.Platform.
4. Do not make the frontend authority-bearing.
5. Do not silently use fixtures where live data is expected.
6. Prefer additive contracts.
7. Every protocol change needs docs, schemas, tests, or conformance evidence.
