# Ontogony System Protocols Package — 2026-05-20

This package defines the next multi-repo protocol/interface hardening program for:

- `uridolan77/allagma-dotnet`
- `uridolan77/kanon-dotnet`
- `uridolan77/conexus-dotnet`
- `uridolan77/ontogony-platform`
- `uridolan77/ontogony-frontend`

The purpose is to stabilize the **system grammar** before continuing feature-by-feature development.

## What this package is

A planning and implementation bundle for:

1. Identifier ownership
2. Header propagation
3. Mutation and idempotency boundaries
4. Error envelopes
5. Event envelope and event vocabulary
6. Runtime posture and capability discovery
7. Evidence links and evidence spine
8. Frontend route/workflow coverage
9. Cross-repo conformance validation

## What this package is not

It is not a production-readiness package. It does not focus on enterprise security, rate limits, secret rotation, external provider hardening, or enabling real external tool execution.

## Start here

1. `01_EXECUTIVE_SUMMARY.md`
2. `02_PROTOCOL_ARCHITECTURE.md`
3. `03_PROTOCOL_LAYER_MATRIX.md`
4. `04_MULTI_REPO_PR_SEQUENCE.md`
5. `pr-specs/SYSTEM-PROTO-000_PROTOCOL_INVENTORY.md`
6. `prompts/START_SYSTEM_PROTO_000.md`

## Unpack command

```powershell
cd C:\dev\allagma-dotnet

Expand-Archive `
  -LiteralPath "C:\dev\allagma-dotnet\docs\_incoming\Ontogony_System_Protocols_Package_2026-05-20.zip" `
  -DestinationPath "C:\dev\allagma-dotnet\docs\_incoming\Ontogony_System_Protocols_Package_2026-05-20" `
  -Force
```

## First implementation rule

Do **not** implement runtime behavior before `SYSTEM-PROTO-000` is complete. `SYSTEM-PROTO-000` produces the inventory and gap map that drives the rest.
