# SYSTEM-PROTO-005 — Runtime posture and capability discovery

## Goal
Make every service self-describing enough for the operator console to know what is available, disabled, blocked, local-only, or fixture-backed.

## Deliverables
```text
GET /allagma/v0/runtime/posture
GET /ontology/v0/runtime/posture
GET /admin/v0/runtime/posture or /conexus/v0/runtime/posture
docs/protocols/RUNTIME_POSTURE_V1.md
schemas/protocols/runtime-posture-v1.schema.json
```

## Allagma-specific posture
Persistence mode, model purposes, Conexus aliases, streaming flags, tool execution modes, sandbox status, kill switch, evaluation manual-write status, Kanon/Conexus target configuration.

## Acceptance criteria
- Frontend can display runtime posture without hardcoded guesses.
- No secrets are exposed.
- Endpoint is read-only.
