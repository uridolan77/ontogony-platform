# SYSTEM-PROTO-006 — Evidence link protocol

## Goal
Make evidence navigation explicit and typed across services.

## Deliverables
```text
docs/protocols/EVIDENCE_LINKS_V1.md
schemas/protocols/evidence-links-v1.schema.json
GET /allagma/v0/runs/{runId}/evidence-links
GET /allagma/v0/evaluations/{evaluationRunId}/evidence-links
GET /ontology/v0/decision-records/{decisionId}/evidence-links
GET /admin/v0/model-calls/{modelCallId}/evidence-links
```

## Relation vocabulary
`planned_by`, `authorized_by`, `opened_gate`, `resolved_gate`, `model_invocation`, `routed_by`, `evaluated_by`, `compared_against`, `exported_as`, `streaming_summary`, `sandbox_ledger`.

## Acceptance criteria
- Evidence spine consumes links when present.
- Manual resolver remains fallback.
- Missing evidence is represented explicitly.
