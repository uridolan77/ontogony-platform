# SYSTEM-PROTO-002 — Mutation and idempotency protocol

## Goal
Define mutation classes and idempotency expectations across Allagma, Kanon, and Conexus.

## Deliverables
```text
docs/protocols/MUTATION_CLASSES_V1.md
docs/protocols/IDEMPOTENCY_BOUNDARIES_V1.md
schemas/protocols/mutation-boundary-v1.schema.json
```

## Mutation classes
1. Create aggregate
2. Advance aggregate
3. Semantic decision
4. Model invocation
5. Human resolution
6. Evidence export/read-only

## Required behavior
- Same key + same payload: replay-safe.
- Same key + different payload: conflict.
- Missing key where required: protocol error.
- In-progress reservation: retryable conflict.
- Terminal failure: explicit reclaim/retry semantics if supported.
- Read-only evidence routes do not require idempotency keys.

## Focus surfaces
- Allagma run start/resume/retry/cancel/replay.
- Kanon compile/evaluate/human-gate check/resolve.
- Conexus completion/streaming and durable idempotency ledger.
- Frontend mutation hooks and idempotency-key helpers.
