# SYSTEM-PROTO-007 — Frontend route/workflow protocol

## Goal
Make the frontend route catalog a formal protocol consumer contract.

## Deliverables
```text
docs/protocols/FRONTEND_WORKFLOW_PROTOCOL_V1.md
src/app/route-workflow-catalog.schema.json
scripts/validate-route-workflow-catalog.mjs
docs/generated/ROUTE_WORKFLOW_PROTOCOL_COVERAGE.md
```

## Required route fields
`path`, `page`, `dataSource`, `hooks`, `clients`, `backendRoutes`, `mutations`, `settings`, `capabilities`, `limitationBanners`, `evidenceComponents`, `evidenceBuilders`, `redactionPaths`, `operatorNextAction`, `tests`.

## Acceptance criteria
- Every Allagma route is cataloged.
- Every backend route exists in OpenAPI or is explicitly marked manual/deferred.
- Fixture/fallback routes are labelled.
- CI/npm script validates catalog shape.
