# SYSTEM-PROTO-000 — Protocol inventory and gap report

## Goal
Create the canonical inventory of current interfaces and protocol gaps across Allagma, Kanon, Conexus, Ontogony.Platform, and Ontogony Frontend.

This is audit/documentation-first. Do not implement protocol changes yet.

## Deliverables
In `allagma-dotnet`:

```text
docs/protocols/SYSTEM_PROTOCOL_INVENTORY.md
docs/protocols/SYSTEM_PROTOCOL_GAP_REPORT.md
docs/protocols/SYSTEM_PROTOCOL_DECISION_LOG.md
```

## Inventory sections
1. Services and ownership boundaries
2. API surfaces
3. Cross-service call paths
4. Identifier ownership
5. Header propagation
6. Mutation/idempotency boundaries
7. Error envelope usage
8. Event vocabulary
9. Capability/runtime posture endpoints
10. Evidence/audit/export surfaces
11. Frontend route/workflow coverage
12. OpenAPI/snapshot status
13. Test/conformance coverage
14. Gaps and next PR mapping

## Acceptance criteria
- Every Allagma `/allagma/v0/*` endpoint appears in the inventory.
- Every Allagma -> Kanon call path appears.
- Every Allagma -> Conexus call path appears.
- Every frontend Allagma route appears with live/fixture/deferred status.
- Every known protocol gap maps to exactly one future `SYSTEM-PROTO-*` PR.
- No stale Agentor naming is introduced.

## Validation
Run relevant existing tests for touched repos. This PR should not change runtime behavior.
