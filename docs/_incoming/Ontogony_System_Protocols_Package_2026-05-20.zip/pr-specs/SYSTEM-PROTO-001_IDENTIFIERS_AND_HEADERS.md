# SYSTEM-PROTO-001 — Identifier and header protocol

## Goal
Promote current identifier/header conventions into a stable cross-repo protocol.

## Primary repo
`ontogony-platform`

## Secondary repos
`allagma-dotnet`, `kanon-dotnet`, `conexus-dotnet`, `ontogony-frontend`

## Deliverables
Platform:
```text
docs/protocols/IDENTIFIERS_V1.md
docs/protocols/HEADERS_V1.md
schemas/protocols/identifiers-v1.schema.json
schemas/protocols/headers-v1.schema.json
```

Service repos:
```text
docs/protocols/IDENTIFIER_HEADER_ADOPTION.md
tests/*IdentifierHeader*Tests.*
```

Frontend:
```text
src/shared/protocol/identifiers.ts
src/shared/protocol/headers.ts
src/shared/protocol/*.test.ts
```

## Acceptance criteria
- Canonical names exist for `runId`, `stepId`, `toolIntentId`, `decisionId`, `humanGateId`, `modelCallId`, `routeDecisionId`, `traceId`, `correlationId`, `idempotencyKey`, `artifactId`.
- Cross-service clients use canonical header constants.
- Representative propagation paths are tested.
- Frontend mutation clients use the canonical idempotency header.
