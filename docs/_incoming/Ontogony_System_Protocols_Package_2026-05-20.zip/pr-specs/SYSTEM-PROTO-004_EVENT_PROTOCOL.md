# SYSTEM-PROTO-004 — Event envelope and vocabulary protocol

## Goal
Make events interpretable across service and frontend boundaries.

## Deliverables
```text
docs/protocols/EVENT_ENVELOPE_V1.md
docs/protocols/EVENT_VOCABULARY_ALLAGMA_V1.md
docs/protocols/EVENT_VOCABULARY_KANON_V1.md
docs/protocols/EVENT_VOCABULARY_CONEXUS_V1.md
schemas/protocols/event-envelope-v1.schema.json
```

## Allagma vocabulary candidates
`Allagma.RunStarted`, `Allagma.PlanCompiled`, `Allagma.ModelCallRequested`, `Allagma.ModelCallCompleted`, `Allagma.ModelStreamStarted`, `Allagma.ModelStreamChunkReceived`, `Allagma.ModelStreamCompleted`, `Allagma.ToolIntentRecorded`, `Allagma.KanonActionEvaluated`, `Allagma.HumanGateOpened`, `Allagma.HumanGateApproved`, `Allagma.HumanGateDenied`, `Allagma.SandboxDryRunCompleted`, `Allagma.SandboxExecuteBlocked`, `Allagma.RunCompleted`, `Allagma.RunFailed`.

## Acceptance criteria
- Existing events are mapped to canonical vocabulary or marked legacy.
- Frontend timeline renders from vocabulary metadata.
- Evidence spine classifies known events.
