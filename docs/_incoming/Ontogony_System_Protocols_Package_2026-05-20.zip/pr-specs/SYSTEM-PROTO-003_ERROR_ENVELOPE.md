# SYSTEM-PROTO-003 — Cross-service error envelope protocol

## Goal
Normalize cross-service error shape across Allagma, Kanon, Conexus, Platform middleware, and frontend adapters.

## Deliverables
```text
docs/protocols/ERROR_ENVELOPE_V1.md
schemas/protocols/error-envelope-v1.schema.json
src/shared/errors/ontogonySystemError.ts
```

## Envelope fields
`code`, `message`, `system`, `stage`, `downstreamSystem`, `traceId`, `correlationId`, `retryable`, `detail`, `evidence`.

## Acceptance criteria
- Representative Allagma, Kanon, and Conexus errors match or map to protocol.
- Frontend has one parser/normalizer.
- Endpoint-specific DTO-shaped validation responses are documented exceptions, not accidental drift.
