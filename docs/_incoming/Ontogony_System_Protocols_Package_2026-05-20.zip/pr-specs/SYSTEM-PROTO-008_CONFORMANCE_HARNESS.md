# SYSTEM-PROTO-008 — Cross-repo protocol conformance harness

## Goal
Create a repeatable validation harness that checks protocol drift across all repos.

## Deliverables
```text
scripts/validate-system-protocols.ps1
artifacts/system-protocols/protocol-conformance-report.json
artifacts/system-protocols/protocol-conformance-report.md
```

## Checks
- API prefixes match docs.
- Health/readiness paths match frontend probes.
- Frontend backend routes exist in service OpenAPI snapshots.
- Required protocol docs/schemas exist.
- Route workflow catalog validates.
- Known headers are defined in canonical place.
- Runtime posture endpoints exist or are marked deferred.
- Evidence link endpoints exist or are marked deferred.
- Runtime lock/package versions are reported.

## Acceptance criteria
- Report clearly marks pass/warn/fail.
- Safe to run locally without live services.
- Live checks are opt-in.
