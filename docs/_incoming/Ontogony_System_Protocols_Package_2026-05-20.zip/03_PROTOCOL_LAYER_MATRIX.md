# Protocol layer matrix

## L1 — Identity protocol

| Identifier | Owner | Purpose |
| --- | --- | --- |
| `runId` | Allagma | Execution aggregate |
| `stepId` | Allagma | Ordered execution unit |
| `toolIntentId` | Allagma | Proposed action before policy decision |
| `decisionId` | Kanon | Semantic/policy decision |
| `humanGateId` | Kanon | Human review gate |
| `modelCallId` | Conexus | Routed model invocation |
| `routeDecisionId` | Conexus | Gateway route decision |
| `traceId` | Platform mechanics | End-to-end work trace |
| `correlationId` | Platform mechanics | Business/process correlation |
| `idempotencyKey` | Mutation boundary | Safe replay key |
| `artifactId` | Platform/artifact store | Evidence artifact reference |

## L2 — Header protocol

Canonical headers:

```text
X-Ontogony-Trace-Id
X-Ontogony-Correlation-Id
X-Ontogony-Actor-Id
X-Ontogony-Roles
Idempotency-Key
X-Ontogony-Idempotency-Key
X-Allagma-Run-Id
Authorization
X-Conexus-Admin-Key
```

## L3 — Mutation/idempotency protocol

| Mutation class | Examples | Expected rule |
| --- | --- | --- |
| Create aggregate | Start Allagma run | replay-safe for same payload; conflict for different payload |
| Advance aggregate | resume/retry/cancel/replay | explicit idempotency key |
| Semantic decision | compile/evaluate/check | deterministic key derived from run/tool/gate |
| Model invocation | completion/streaming | deterministic key from run + purpose/step |
| Human resolution | resolve gate | gate-specific key + actor context |
| Evidence export | audit/evidence bundle | read-only; no idempotency needed |

## L4 — Error envelope protocol

Required conceptual fields:

```json
{
  "code": "string",
  "message": "string",
  "system": "allagma|kanon|conexus|platform",
  "stage": "request|validation|idempotency|policy|model|persistence|downstream|timeout|unknown",
  "downstreamSystem": "kanon|conexus|null",
  "traceId": "string|null",
  "correlationId": "string|null",
  "retryable": false,
  "detail": {},
  "evidence": {}
}
```

## L5 — Event protocol

Required conceptual fields:

```json
{
  "schema": "ontogony-event-v1",
  "eventId": "string",
  "eventType": "Allagma.RunStarted",
  "sourceService": "allagma",
  "occurredAt": "date-time",
  "traceId": "string",
  "correlationId": "string|null",
  "identifiers": {},
  "payload": {},
  "redaction": { "level": "metadata_only|hash_only|safe_summary" }
}
```

## L6 — Runtime posture

Read-only service posture should expose API prefix, protocol version, persistence mode, downstream configuration status, feature flags, evidence routes, event vocabularies, and warnings.

## L7 — Evidence links

Evidence links should connect Allagma runs/evals/baselines, Kanon decisions/provenance, Conexus model calls/route decisions, and platform artifacts.

## L8 — Frontend workflow protocol

Every route should declare backend routes, settings, capabilities, mutations, evidence components, live/fixture/deferred state, and tests.
