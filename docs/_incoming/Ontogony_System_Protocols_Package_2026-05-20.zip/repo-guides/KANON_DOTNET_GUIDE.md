# kanon-dotnet protocol guide

## Role
Kanon owns meaning, semantic plans, policies, human gates, decision records, and provenance.

## Key surfaces
- `/ontology/v0/semantic-query-plans/compile`
- `/ontology/v0/actions/evaluate`
- `/ontology/v0/actions/human-gates/check`
- `/ontology/v0/actions/human-gates/{humanGateId}/resolve`
- `/ontology/v0/decision-records/{decisionId}`
- `/ontology/v0/decision-records/{decisionId}/provenance`
- `/ontology/v0/decision-records/by-trace/{traceId}`
- `/ontology/v0/conexus/assistance/*`

## Protocol gaps to inspect first
- Human-gate state vocabulary should be shared with Allagma and frontend.
- Decision/evidence link protocol should include downstream Allagma/Conexus references when known.
- Error envelope should distinguish validation DTO-shaped responses from system errors.
- Runtime posture should expose supported semantic/policy protocol version.
