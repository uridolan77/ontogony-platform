# ontogony-frontend protocol guide

## Role
Frontend is the operator console and protocol consumer.

## Responsibilities
- Display service health and runtime posture.
- Send canonical headers.
- Require idempotency keys for required mutations.
- Normalize system errors.
- Render event timelines from vocabulary metadata.
- Resolve evidence links and evidence spine graphs.
- Maintain route/workflow catalog as coverage contract.

## Existing strengths
- Operator settings for Conexus/Kanon/Allagma.
- Health/readiness probes.
- Allagma clients and pages.
- Evidence spine resolver across Allagma/Kanon/Conexus.
- Route workflow catalog.

## Protocol gaps to inspect first
- Catalog schema and validation.
- Runtime posture panels.
- Error parser normalization.
- Event vocabulary presentation.
- Evidence link consumption.
- Clear live/fixture/deferred status on every page.
