# allagma-dotnet protocol guide

## Role
Allagma owns governed execution.

## Key surfaces
- `/allagma/v0/runs`
- `/allagma/v0/runs/{runId}`
- `/allagma/v0/runs/{runId}/events`
- `/allagma/v0/runs/{runId}/audit`
- `/allagma/v0/runs/{runId}/operations`
- `/allagma/v0/runs/{runId}/resume`
- `/allagma/v0/runs/{runId}/retry`
- `/allagma/v0/runs/{runId}/cancel`
- `/allagma/v0/runs/{runId}/replay`
- `/allagma/v0/capabilities`
- `/allagma/v0/evaluations`
- `/allagma/v0/evaluation-datasets`
- `/allagma/v0/evaluations/{evaluationRunId}/evidence`
- `/allagma/v0/evaluations/baseline-comparisons`

## Protocol gaps to inspect first
- Runtime posture is not yet full-system descriptive.
- Model-purpose -> Conexus alias -> route decision is not fully operator-visible.
- Sandbox execute capability is largely internal/read-only.
- Streaming evidence is script-visible but not fully operator-visible.
- Event vocabulary should be canonicalized.
- Evidence links should be explicit, not only inferred by frontend resolver.

## Do not do
- Do not enable real external tool execution.
- Do not move semantic policy into Allagma.
- Do not move provider routing into Allagma.
