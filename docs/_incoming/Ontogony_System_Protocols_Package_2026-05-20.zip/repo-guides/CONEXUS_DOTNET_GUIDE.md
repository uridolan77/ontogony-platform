# conexus-dotnet protocol guide

## Role
Conexus owns model gateway behavior: aliases, route decisions, provider attempts, model-call telemetry, usage/cost, evidence bundles.

## Key surfaces
- `/v1/chat/completions`
- `/v1/models`
- `/v1/governance/usage`
- `/admin/v0/model-calls`
- `/admin/v0/model-calls/{modelCallId}`
- `/admin/v0/model-calls/{modelCallId}/evidence-links`
- `/admin/v0/model-calls/{modelCallId}/evidence-bundle`
- `/admin/v0/route-decisions/{routeDecisionId}`
- `/admin/v0/diagnostics/execution-runs/by-request-id/{requestId}`

## Protocol gaps to inspect first
- Align model-call evidence links with shared Evidence Links V1.
- Expose runtime posture with provider/alias/config status without secrets.
- Confirm Allagma run context is persisted consistently.
- Confirm streaming model-call telemetry has stable missing-usage reason codes.
