# ontogony-platform protocol guide

## Role
Platform owns mechanics only.

## Good platform protocol code
- header constants
- generic identifier references
- error envelope base contracts
- event envelope base contracts
- runtime posture base contracts
- evidence link base contracts
- schema validation helpers
- conformance harness mechanics

## Do not add
- Allagma execution semantics
- Kanon policy semantics
- Conexus routing semantics
- frontend workflow semantics

## First rule
Start with docs/schemas and consumer adoption tests. Do not prematurely add broad shared runtime abstractions.
