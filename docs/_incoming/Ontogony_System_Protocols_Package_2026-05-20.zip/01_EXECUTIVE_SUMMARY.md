# Executive summary

The Ontogony system is now integrated enough that the next risk is not missing connectivity, but unstable protocol boundaries.

Allagma, Kanon, Conexus, Ontogony.Platform, and the frontend already have real edges:

```text
Frontend -> Allagma -> Kanon
Frontend -> Allagma -> Conexus
Frontend -> Kanon
Frontend -> Conexus
Allagma -> Platform mechanics
Kanon -> Platform mechanics
Conexus -> Platform mechanics
```

The next work should define the **inter-system protocols** that allow each repo to evolve independently.

## Core thesis

Before deepening Allagma, Kanon, Conexus, Platform, or the frontend separately, harden the protocol layer:

- what identifiers mean
- who owns each identifier
- which headers cross which boundaries
- how idempotency behaves per mutation class
- how failures are shaped
- how events are named and interpreted
- how services expose runtime posture
- how evidence links are represented
- how the frontend declares live/fixture/deferred workflows

## Output of this package

A sequenced program:

| PR | Purpose |
| --- | --- |
| `SYSTEM-PROTO-000` | Inventory current interfaces and gaps |
| `SYSTEM-PROTO-001` | Identifier and header protocol |
| `SYSTEM-PROTO-002` | Mutation/idempotency protocol |
| `SYSTEM-PROTO-003` | Error envelope protocol |
| `SYSTEM-PROTO-004` | Event envelope and vocabulary |
| `SYSTEM-PROTO-005` | Runtime posture and capabilities |
| `SYSTEM-PROTO-006` | Evidence links |
| `SYSTEM-PROTO-007` | Frontend route/workflow protocol |
| `SYSTEM-PROTO-008` | Cross-repo conformance harness |

## Expected result

After the sequence, every future feature should declare which protocol layer it touches. This turns the repo constellation from a set of connected services into a coherent distributed architecture.
