# Unpacking Prompt

Copy `ontogony-platform/*` into the root of the `ontogony-platform` repo.
Copy `conexus-dotnet/*` into the root of the `conexus-dotnet` repo.

Recommended PRs:
- `PLAT-NP-013 — Consumer-State Docs Reconciliation`
- `CX-0050 — Production Alpha Stabilization`

Rules:
1. Do not overwrite existing implementation files without review.
2. Keep Ontogony mechanical only.
3. Keep Conexus gateway/product semantics in Conexus.
4. Treat these as planning docs, not source implementation.
5. Validate markdown links after unpacking.
