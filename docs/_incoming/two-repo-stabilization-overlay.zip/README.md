# Two-Repo Stabilization Overlay

This overlay prepares the next phase after the cleanup wave.

Target repos:
- `ontogony-platform`
- `conexus-dotnet`

Strategic decision:
- Ontogony.Platform gets a small docs/governance reconciliation PR only.
- Conexus.NET gets the main stabilization sprint: `CX-0050 — Production Alpha Stabilization`.

This package intentionally contains planning artifacts, not implementation code:
- PR specs
- ADRs
- checklists
- documentation skeletons
- review templates
- unpacking prompts

Do not add:
- new Ontogony packages
- new Conexus providers
- admin UI
- cloud secret manager packages
- product semantics inside Ontogony
- agent orchestration
