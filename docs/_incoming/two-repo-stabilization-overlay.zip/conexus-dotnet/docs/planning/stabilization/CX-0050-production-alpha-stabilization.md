# CX-0050 — Production Alpha Stabilization

## Executive goal

Conexus.NET is now a governed LLM gateway alpha. It has enough surface to stop expanding temporarily and prove the current system can run reliably, observably, and safely.

## Scope

1. Canonical architecture map.
2. Deployment baseline.
3. Migration discipline.
4. Observability baseline.
5. External-provider smoke tests.
6. Load/soak test harness.
7. Idempotency clarification.
8. Admin security hardening plan.
9. Privacy/retention policy.
10. Known limitations document.

## Non-goals

- No new providers.
- No admin UI.
- No new Ontogony packages.
- No agent/orchestration features.
- No cloud secret manager implementation yet.
- No new product endpoint unless required for diagnostics.

## Success definition

A developer/operator can answer:
- How does a request move through Conexus?
- What is durable and what is in-memory?
- How do I run Conexus locally with Postgres?
- How do I deploy the alpha safely?
- What metrics/logs should I watch?
- What provider smoke tests are available?
- What load tests exist?
- What is not production-ready yet?
