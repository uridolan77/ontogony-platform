# PR-CX-0050C — EF Migration Discipline

Add:
- `docs/deployment/MIGRATION_RUNBOOK.md`
- `docs/development/EF_MIGRATION_CHECKLIST.md`
- `docs/deployment/BACKUP_AND_RESTORE_NOTES.md`

Cover:
- migration naming convention,
- schema vs data migrations,
- expand/contract guidance,
- index review,
- retention impact,
- rollback feasibility,
- backup warning,
- local reset warning,
- required tests.
