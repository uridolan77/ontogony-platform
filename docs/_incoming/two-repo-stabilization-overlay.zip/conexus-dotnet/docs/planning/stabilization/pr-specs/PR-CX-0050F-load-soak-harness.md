# PR-CX-0050F — Load and Soak Test Harness

Create opt-in load harness for:
1. 100 concurrent non-streaming requests.
2. 100 concurrent streaming requests.
3. idempotency conflict concurrency.
4. provider timeout/fallback.
5. Postgres pool pressure.
6. rate limiter behavior.
7. retention cleanup under data volume.

Add `docs/testing/LOAD_AND_SOAK_TESTS.md`.

Do not run in normal CI unless explicitly enabled.
