# PR-CX-0050H — Admin Security Hardening Plan

Create `docs/security/ADMIN_AUTHORIZATION_MODEL.md`.

Cover:
- current admin auth behavior,
- actor attribution,
- audit coverage,
- key rotation,
- key revocation,
- future roles/scopes,
- request size limits,
- payload validation,
- known limitations.

No role implementation required in this PR.
