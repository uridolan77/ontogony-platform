# PR-CX-0050G — Idempotency Clarification

Conexus has:
1. durable client `Idempotency-Key` replay store,
2. protocol-neutral `IIdempotencyLedger`, currently in-memory.

Create `docs/architecture/IDEMPOTENCY_MODEL.md`.

Decision options:
- keep both and document roles,
- make neutral ledger durable,
- remove neutral ledger from critical path.

Acceptance:
- multi-node behavior explicit,
- streaming idempotency rejection explicit,
- non-streaming replay behavior explicit.
