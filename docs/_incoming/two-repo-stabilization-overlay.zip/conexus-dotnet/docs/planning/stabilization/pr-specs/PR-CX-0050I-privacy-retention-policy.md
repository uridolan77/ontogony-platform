# PR-CX-0050I — Privacy and Retention Policy

Create `docs/operations/PRIVACY_AND_RETENTION_POLICY.md`.

Cover:
- data categories,
- stored by default,
- hashed,
- redacted,
- opt-in,
- retention windows,
- deletion semantics,
- project isolation,
- raw provider payload policy,
- replay document policy,
- audit log policy,
- limitations.
