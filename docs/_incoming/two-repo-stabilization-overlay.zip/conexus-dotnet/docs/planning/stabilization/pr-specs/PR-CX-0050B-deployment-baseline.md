# PR-CX-0050B — Deployment Baseline

Add:
- `Dockerfile`
- `docker-compose.yml`
- `.env.example`
- `docs/deployment/LOCAL_DOCKER.md`
- `docs/deployment/ENVIRONMENT_VARIABLES.md`
- `docs/deployment/STARTUP_AND_READINESS.md`

Requirements:
- .NET 9 runtime image.
- API + Postgres compose.
- no secrets baked into image.
- provider key placeholders only.
- health/readiness documented.
- production caveats documented.
