# PR-CX-0050A — Canonical Architecture Map

Create `docs/architecture/CURRENT_ARCHITECTURE.md`.

Required sections:
1. System summary.
2. Non-streaming chat completion path.
3. Streaming SSE completion path.
4. Provider fallback path.
5. Idempotency/replay path.
6. Durable Postgres mode.
7. In-memory local mode.
8. Admin API path.
9. Audit path.
10. Retention cleanup path.
11. Provider inventory/readiness path.
12. Ontogony source-mode vs package-mode consumption.
13. Known alpha limitations.

Use Mermaid diagrams for request, streaming, persistence, and admin/audit paths.

Acceptance:
- no code changes,
- docs match current implementation,
- streaming/non-streaming distinction is explicit,
- streaming `Idempotency-Key` rejection is explicit.
