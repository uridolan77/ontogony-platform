# PR-CX-0050J — Known Limitations Document

Create `docs/operations/KNOWN_LIMITATIONS.md`.

Must include:
- admin auth is alpha,
- no formal security review,
- no cloud secret manager integration,
- shallow external provider parity,
- streaming replay unsupported,
- neutral idempotency ledger limitation unless resolved,
- no load/soak evidence yet,
- no production deployment proof yet,
- no dashboards/alerts yet,
- no admin UI.
