# PR-CX-0050D — Observability Baseline

Add:
- `docs/operations/OBSERVABILITY_BASELINE.md`
- `docs/operations/LOG_FIELDS.md`
- `docs/operations/METRICS_AND_ALERTS.md`

Document metrics:
- request count,
- provider latency,
- provider errors,
- fallback count,
- streaming started/completed/interrupted,
- quota exceeded,
- replay/conflict/in-progress,
- token and cost totals,
- admin mutations,
- audit append failures,
- retention cleanup counts,
- readiness failures.
