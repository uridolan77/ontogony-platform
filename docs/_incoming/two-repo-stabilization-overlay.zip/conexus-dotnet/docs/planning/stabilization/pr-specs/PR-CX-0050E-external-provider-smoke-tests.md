# PR-CX-0050E — External Provider Smoke Tests

Add opt-in tests for:
- OpenAI
- OpenAI-compatible HTTP / OpenRouter
- Anthropic
- Gemini

Rules:
- skip unless env vars exist,
- minimal prompts,
- disabled in normal CI,
- non-streaming smoke for all,
- streaming smoke where supported,
- no raw secrets in failures/logs.

Add `docs/testing/EXTERNAL_PROVIDER_SMOKE_TESTS.md`.
