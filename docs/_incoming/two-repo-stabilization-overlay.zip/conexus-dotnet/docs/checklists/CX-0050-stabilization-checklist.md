# CX-0050 Stabilization Checklist

## Architecture
- [ ] CURRENT_ARCHITECTURE.md
- [ ] request path diagram
- [ ] streaming path diagram
- [ ] fallback path diagram
- [ ] admin/audit/retention path
- [ ] source/package Ontogony modes

## Deployment
- [ ] Dockerfile
- [ ] docker-compose
- [ ] .env.example
- [ ] local Docker runbook
- [ ] production env matrix

## Persistence
- [ ] EF migration checklist
- [ ] migration runbook
- [ ] backup/restore notes
- [ ] expand/contract guidance

## Observability
- [ ] log fields
- [ ] metrics inventory
- [ ] alert candidates
- [ ] OpenTelemetry export docs

## Testing
- [ ] external provider smokes
- [ ] load/soak harness
- [ ] package-mode validation retained
- [ ] Postgres validation retained

## Security/privacy
- [ ] admin auth model
- [ ] privacy/retention policy
- [ ] known limitations
- [ ] idempotency model clarified

## Non-expansion guard
- [ ] no new providers
- [ ] no admin UI
- [ ] no new Ontogony packages
