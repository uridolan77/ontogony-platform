# ADR-CX-0050 — Production Alpha Stabilization Before Feature Expansion

## Status

Proposed

## Context

Conexus.NET now has a wide implemented surface: streaming, multiple providers, Postgres persistence, replay/idempotency, admin v0, usage/cost governance, audit, retention, readiness/inventory, and package-mode Ontogony consumption.

The main risk has shifted from missing architecture to operational complexity.

## Decision

Before adding more providers, UI, agent features, or cloud integrations, Conexus will run a stabilization sprint focused on proof, deployment, observability, migration discipline, load testing, security posture, and documentation.

## Consequences

Positive:
- reduces hidden instability,
- enables safer internal dogfooding,
- clarifies production boundaries.

Negative:
- slows feature expansion temporarily.
