# Roadmap Decision Report

## Decision

Proceed with:

1. `PLAT-NP-013 — Consumer-State Docs Reconciliation`
2. `CX-0050 — Production Alpha Stabilization`

## Rationale

Ontogony.Platform is now a packaged mechanical substrate with public API governance, package hygiene, release proof, dependency/security evidence, and Conexus package-mode consumer proof. It does not need new packages now.

Conexus.NET is now a serious governed LLM gateway alpha. It has multiple providers, streaming, Postgres persistence, replay, audit, retention, usage/cost governance, readiness/inventory, and package-mode Ontogony consumption. It should not expand feature scope until the current surface is proven operationally.

## Scores

| Repo | Alpha readiness | Production readiness |
| --- | ---: | ---: |
| Ontogony.Platform | 9.2 / 10 | 8.0 / 10 |
| Conexus.NET | 8.5 / 10 | 5.8 / 10 |
| Combined system | 8.8 / 10 | 6.6 / 10 |

## Immediate next phase

Ontogony:
- one docs-only PR
- correct active-consumer language
- clarify pre-1.0 versioning with Conexus as active consumer

Conexus:
- architecture map
- deployment baseline
- migration discipline
- observability baseline
- external provider smoke tests
- load/soak harness
- idempotency clarification
- admin security plan
- privacy/retention policy
- known limitations document
