# Ontogony + Conexus Robustness Overlay

This package turns the two CTO reviews plus current repo inspection into an implementation-ready hardening plan.

Expected workspace:

```text
workspace/
  ontogony-platform/
  conexus-dotnet/
```

Core rule:

- `ontogony-platform` owns reusable mechanics.
- `conexus-dotnet` owns gateway/product semantics.

The overlay is intentionally planning/spec/prompt material. It does not implement production code.
