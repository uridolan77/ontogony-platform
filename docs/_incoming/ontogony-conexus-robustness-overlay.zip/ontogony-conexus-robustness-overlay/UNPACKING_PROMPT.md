# Unpacking prompt

Use from the workspace root:

```text
Apply the robustness overlay.

Workspace:
workspace/
  ontogony-platform/
  conexus-dotnet/

Copy:
- overlay/conexus-dotnet/docs/planning/robustness/** -> ./conexus-dotnet/docs/planning/robustness/
- overlay/ontogony-platform/docs/planning/robustness/** -> ./ontogony-platform/docs/planning/robustness/
- overlay/_agent_prompts/** and overlay/_issue_bodies/** into your incoming-package/planning area.

Do not overwrite unrelated source files.
Do not implement code yet.
Summarize added files and recommend the first PR.
```
