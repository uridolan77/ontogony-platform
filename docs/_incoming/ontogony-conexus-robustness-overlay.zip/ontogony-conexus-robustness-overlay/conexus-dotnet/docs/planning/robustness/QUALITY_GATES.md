# Conexus quality gates

Every robustness PR must:

- update BUILD_VALIDATION
- add success/failure/security tests
- avoid raw secrets/prompts/completions in logs/telemetry/exceptions
- preserve Application independence from provider SDKs
- keep platform mechanics out of Conexus unless product-specific
- block/noise in-memory stores in Production
- preserve OpenAI-compatible error shapes where relevant
