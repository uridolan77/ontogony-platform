# Admin Api V0

Minimal admin endpoints: projects, keys, provider configs, model aliases, quota usage. Admin auth must be separate from project API keys.
