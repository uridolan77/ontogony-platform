# Persistence Architecture

Durable stores needed: projects, API keys, provider configs, model aliases, price catalog, idempotency, quota windows, telemetry, execution, artifact refs.
