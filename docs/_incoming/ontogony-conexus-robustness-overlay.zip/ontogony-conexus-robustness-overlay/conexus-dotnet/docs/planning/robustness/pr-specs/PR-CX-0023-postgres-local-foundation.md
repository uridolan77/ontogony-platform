# Postgres local foundation

## Goal

Add local durable substrate.

## Acceptance criteria

docker-compose Postgres; connection config; migration path; reset script; CI/integration test skeleton.

## Required tests

- success path
- failure path
- security/boundary path
- integration test when host/middleware behavior changes

## Boundary checklist

- [ ] Product semantics stay in Conexus.
- [ ] Reusable mechanics are not added locally if they belong in Ontogony.
- [ ] No raw secrets/prompts/completions are logged or stored by default.
- [ ] BUILD_VALIDATION is updated.
