# Durable idempotency with replay

## Goal

Implement production idempotency semantics.

## Acceptance criteria

Same key+same payload replays; same key+different payload conflicts; concurrent duplicate tested.

## Required tests

- success path
- failure path
- security/boundary path
- integration test when host/middleware behavior changes

## Boundary checklist

- [ ] Product semantics stay in Conexus.
- [ ] Reusable mechanics are not added locally if they belong in Ontogony.
- [ ] No raw secrets/prompts/completions are logged or stored by default.
- [ ] BUILD_VALIDATION is updated.
