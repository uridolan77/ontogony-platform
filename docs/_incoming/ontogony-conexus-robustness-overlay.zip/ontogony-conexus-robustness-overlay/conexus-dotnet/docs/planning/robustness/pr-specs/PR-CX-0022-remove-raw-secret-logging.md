# Remove raw secret logging

## Goal

Ensure raw API keys/provider keys never enter log state.

## Acceptance criteria

Invalid-key logs only fingerprint; tests prove raw key absent from scopes/logs/exceptions/telemetry.

## Required tests

- success path
- failure path
- security/boundary path
- integration test when host/middleware behavior changes

## Boundary checklist

- [ ] Product semantics stay in Conexus.
- [ ] Reusable mechanics are not added locally if they belong in Ontogony.
- [ ] No raw secrets/prompts/completions are logged or stored by default.
- [ ] BUILD_VALIDATION is updated.
