# Idempotency Response Replay

Same key + same payload replays previous response; same key + different payload returns conflict; in-progress duplicate returns conflict/retry response.
