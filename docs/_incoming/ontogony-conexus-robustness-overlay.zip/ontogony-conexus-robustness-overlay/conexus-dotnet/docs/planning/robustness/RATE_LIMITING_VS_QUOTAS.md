# Rate Limiting Vs Quotas

Ingress rate limiting protects transport/bursts. Quotas enforce business governance. They are separate.
