# Durable project/key repository

## Goal

Replace dev-only project key store for production.

## Acceptance criteria

Persist projects/keys; rotate/revoke; last-used; fingerprint lookup; production DI uses durable store.

## Required tests

- success path
- failure path
- security/boundary path
- integration test when host/middleware behavior changes

## Boundary checklist

- [ ] Product semantics stay in Conexus.
- [ ] Reusable mechanics are not added locally if they belong in Ontogony.
- [ ] No raw secrets/prompts/completions are logged or stored by default.
- [ ] BUILD_VALIDATION is updated.
