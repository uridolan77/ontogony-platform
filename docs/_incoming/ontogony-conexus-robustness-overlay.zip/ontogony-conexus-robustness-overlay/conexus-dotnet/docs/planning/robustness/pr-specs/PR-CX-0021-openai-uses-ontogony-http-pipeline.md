# OpenAI provider uses Ontogony HTTP pipeline

## Goal

Align OpenAI outbound calls with Ontogony HTTP resilience/correlation.

## Acceptance criteria

OpenAI calls use correlation headers; retry/timeout behavior covered; duplicate client registration removed or documented.

## Required tests

- success path
- failure path
- security/boundary path
- integration test when host/middleware behavior changes

## Boundary checklist

- [ ] Product semantics stay in Conexus.
- [ ] Reusable mechanics are not added locally if they belong in Ontogony.
- [ ] No raw secrets/prompts/completions are logged or stored by default.
- [ ] BUILD_VALIDATION is updated.
