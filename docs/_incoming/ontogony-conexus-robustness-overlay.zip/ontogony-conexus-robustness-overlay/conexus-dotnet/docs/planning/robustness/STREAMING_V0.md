# Streaming V0

Add OpenAI-compatible SSE streaming via provider chunk abstraction. Cancellation must propagate; raw chunks must not be logged.
