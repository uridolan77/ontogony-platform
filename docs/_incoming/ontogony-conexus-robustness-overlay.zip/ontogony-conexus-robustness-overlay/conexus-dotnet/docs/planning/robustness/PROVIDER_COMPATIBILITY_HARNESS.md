# Provider Compatibility Harness

Fake HTTP provider matrix: 200, 400, 401, 403, 408, 429 Retry-After, 500/502/503, malformed JSON, timeout, cancellation, empty choices, streaming.
