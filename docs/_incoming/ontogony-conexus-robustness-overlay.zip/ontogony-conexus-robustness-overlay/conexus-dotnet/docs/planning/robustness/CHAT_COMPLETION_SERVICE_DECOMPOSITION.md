# Chat Completion Service Decomposition

After tests lock behavior, split ChatCompletionService into fingerprint, idempotency, quota, provider attempt, telemetry, artifact, response mapping, and journal collaborators.
