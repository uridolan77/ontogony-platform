# Route Policy And Price Catalog

Move aliases/routes/prices into durable product configuration with versioned price catalogs and effective dates.
