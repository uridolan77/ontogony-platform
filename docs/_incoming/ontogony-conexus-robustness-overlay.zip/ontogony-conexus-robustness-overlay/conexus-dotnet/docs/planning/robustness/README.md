# Conexus robustness planning

Purpose: move Conexus from a clean starter gateway to a durable, auditable, operable LLM access authority.

Conexus owns:
- projects/API keys
- provider configs
- model aliases/routes
- fallback policy
- price catalog
- admin APIs
- OpenAI-compatible behavior
- provider compatibility
- streaming

Ontogony owns:
- HTTP resilience/correlation
- tracing/logging/redaction
- secret value resolution
- idempotency/quota ledger mechanics
- execution/artifact/AI telemetry primitives
