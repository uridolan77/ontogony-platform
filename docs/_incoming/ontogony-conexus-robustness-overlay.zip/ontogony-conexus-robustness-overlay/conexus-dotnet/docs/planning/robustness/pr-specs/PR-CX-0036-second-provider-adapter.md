# Second provider adapter

## Goal

Prove abstraction beyond OpenAI.

## Acceptance criteria

Second provider tests; fallback between providers; no app-layer SDK dependency.

## Required tests

- success path
- failure path
- security/boundary path
- integration test when host/middleware behavior changes

## Boundary checklist

- [ ] Product semantics stay in Conexus.
- [ ] Reusable mechanics are not added locally if they belong in Ontogony.
- [ ] No raw secrets/prompts/completions are logged or stored by default.
- [ ] BUILD_VALIDATION is updated.
