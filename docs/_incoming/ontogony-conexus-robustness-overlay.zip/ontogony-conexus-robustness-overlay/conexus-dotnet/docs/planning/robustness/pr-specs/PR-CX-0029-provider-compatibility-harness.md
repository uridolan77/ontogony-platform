# Provider compatibility harness

## Goal

Build fake provider failure matrix.

## Acceptance criteria

200/400/401/403/408/429/500/502/503/malformed/timeout/cancel tests.

## Required tests

- success path
- failure path
- security/boundary path
- integration test when host/middleware behavior changes

## Boundary checklist

- [ ] Product semantics stay in Conexus.
- [ ] Reusable mechanics are not added locally if they belong in Ontogony.
- [ ] No raw secrets/prompts/completions are logged or stored by default.
- [ ] BUILD_VALIDATION is updated.
