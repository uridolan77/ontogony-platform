# Conexus robustness PR sequence

## Phase A — close correctness/security gaps

1. PR-CX-0021 — OpenAI provider uses Ontogony HTTP pipeline.
2. PR-CX-0022 — Remove raw secret logging.
3. PR-CX-0023 — Postgres local foundation.
4. PR-CX-0024 — Durable project/key repository.

## Phase B — make it operable

5. PR-CX-0025 — Admin API v0 for projects and keys.
6. PR-CX-0026 — Durable model alias and provider config repository.
7. PR-CX-0027 — Durable idempotency with payload binding and replay.
8. PR-CX-0028 — Durable telemetry, usage, cost, and execution records.

## Phase C — compatibility/usefulness

9. PR-CX-0029 — Provider compatibility harness.
10. PR-CX-0030 — Streaming chat completions.
11. PR-CX-0031 — Health/readiness deep checks.
12. PR-CX-0032 — Ingress rate limiting.

## Phase D — maintainability/polish

13. PR-CX-0033 — ChatCompletionService decomposition.
14. PR-CX-0034 — Swagger/OpenAPI hardening.
15. PR-CX-0035 — Route policy and price catalog v0.
16. PR-CX-0036 — Second provider adapter.
