# Security No Secret Logging Policy

Raw secrets must never be placed in logger scopes, messages, exception text/data, telemetry metadata, execution metadata, or artifact metadata. Log fingerprints only.
