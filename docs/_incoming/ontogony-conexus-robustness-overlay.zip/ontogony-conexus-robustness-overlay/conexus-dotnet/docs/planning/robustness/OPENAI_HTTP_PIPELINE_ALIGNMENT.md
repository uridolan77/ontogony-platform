# Openai Http Pipeline Alignment

OpenAI outbound calls must use Ontogony correlation/resilience through named client or typed-client equivalent. Tests must prove correlation headers, retry classification, Retry-After behavior, and timeout behavior.
