# Admin API v0 for projects and keys

## Goal

Create operability surface.

## Acceptance criteria

Admin auth separate from project key; create/disable project; issue/revoke key; audit events.

## Required tests

- success path
- failure path
- security/boundary path
- integration test when host/middleware behavior changes

## Boundary checklist

- [ ] Product semantics stay in Conexus.
- [ ] Reusable mechanics are not added locally if they belong in Ontogony.
- [ ] No raw secrets/prompts/completions are logged or stored by default.
- [ ] BUILD_VALIDATION is updated.
