# Durable Telemetry Usage Cost

Persist governance records for request/response telemetry, usage, cost, attempts, fallback, provider errors, trace ids, and price catalog versions.
