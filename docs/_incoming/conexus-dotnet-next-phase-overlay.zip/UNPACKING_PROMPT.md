# Cursor / agent unpacking prompt

You are applying a documentation/planning overlay to `conexus-dotnet`.

Overlay shape:

```text
conexus-dotnet/
  docs/planning/next-phase/
  _agent_prompts/conexus/
  _issue_bodies/conexus/
```

Task:

1. Copy the overlay files into the real `conexus-dotnet` repository.
2. Do not overwrite implementation files.
3. Do not implement any PR yet.
4. Preserve existing docs when stronger/current; merge only if there is a clear conflict.
5. After applying, run:

```powershell
git -C conexus-dotnet status --short
```

6. Confirm these paths exist:

```text
conexus-dotnet/docs/planning/next-phase/NEXT_PHASE_SEQUENCE.md
conexus-dotnet/docs/planning/next-phase/CURRENT_REVIEW_AFTER_CX0036.md
conexus-dotnet/docs/planning/next-phase/pr-specs/
conexus-dotnet/_agent_prompts/conexus/
conexus-dotnet/_issue_bodies/conexus/
```

Then summarize:
- files added
- conflicts/skipped files
- recommended first PR: PR-CX-0036.1
