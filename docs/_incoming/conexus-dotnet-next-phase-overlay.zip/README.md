# Conexus.NET next-phase overlay

This package is a planning/spec overlay for the next Conexus.NET phase after PR-CX-0036.

It does **not** implement code. It adds review notes, next PR specs, agent prompts, issue bodies, and quality gates.

Core rule preserved:

> Reusable mechanics go to `ontogony-platform`; gateway/product semantics stay in `conexus-dotnet`.

Apply from a parent folder that contains the repository:

```text
parent/
  conexus-dotnet/
```

Copy the `conexus-dotnet/` folder from this overlay into the real repository.
