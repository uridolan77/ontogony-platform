# Agent prompt — PR-CX-0040-provider-runtime-config-readiness-unification

You are working in `conexus-dotnet`.

Implement `PR-CX-0040-provider-runtime-config-readiness-unification` according to:

```text
docs/planning/next-phase/pr-specs/PR-CX-0040-provider-runtime-config-readiness-unification.md
```

Hard rules:

- Do not add reusable mechanics to Conexus if they belong in `ontogony-platform`.
- Do not move route policy, price catalog, provider config semantics, admin API semantics, or gateway behavior into Ontogony.
- Keep providers disabled by default unless the spec says otherwise.
- Never log raw secrets.
- Preserve existing behavior unless the spec explicitly changes it.
- Update tests and docs.

Validation:

```powershell
dotnet restore Conexus.sln
dotnet build Conexus.sln --no-restore -c Release -p:NoWarn=CS1591
dotnet test Conexus.sln --no-build -c Release -p:NoWarn=CS1591
```

For persistence changes, run persistence tests as well.
