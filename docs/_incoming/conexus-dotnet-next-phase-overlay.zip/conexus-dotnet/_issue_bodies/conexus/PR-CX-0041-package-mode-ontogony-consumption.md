# PR-CX-0041-package-mode-ontogony-consumption

See spec:

```text
docs/planning/next-phase/pr-specs/PR-CX-0041-package-mode-ontogony-consumption.md
```

## Acceptance summary

- Implementation follows repo boundary rules.
- Tests added/updated.
- Build validation updated.
- Docs/config updated where relevant.
- No raw secrets in logs, exceptions, telemetry, artifacts, or docs.
