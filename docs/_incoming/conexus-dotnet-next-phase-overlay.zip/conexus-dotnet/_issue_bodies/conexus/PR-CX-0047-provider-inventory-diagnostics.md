# PR-CX-0047-provider-inventory-diagnostics

See spec:

```text
docs/planning/next-phase/pr-specs/PR-CX-0047-provider-inventory-diagnostics.md
```

## Acceptance summary

- Implementation follows repo boundary rules.
- Tests added/updated.
- Build validation updated.
- Docs/config updated where relevant.
- No raw secrets in logs, exceptions, telemetry, artifacts, or docs.
