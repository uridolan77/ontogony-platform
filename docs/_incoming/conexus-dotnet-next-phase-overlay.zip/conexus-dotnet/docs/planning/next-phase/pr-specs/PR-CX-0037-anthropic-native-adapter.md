# PR-CX-0037 — Anthropic native adapter

## Goal

Add a native Anthropic chat adapter to prove Conexus is provider-agnostic beyond OpenAI-shaped APIs.

## Scope

- New project: `Conexus.Providers.Anthropic`.
- Options section: `Conexus:Providers:Anthropic`.
- Disabled by default.
- Native Anthropic messages request mapping.
- Native response mapping into `ProviderChatResponse`.
- Error normalization into Conexus provider error codes.
- Secret resolution through `ISecretValueResolver`.
- Ontogony integration HttpClient for outbound calls.
- Host composition test.
- Fallback test from Anthropic to fake.

## Out of scope

- Tool use.
- Vision/multimodal.
- Streaming.
- Batch APIs.

## Acceptance

- Success mapping.
- 400/401/403/429/5xx mapping.
- malformed success mapping.
- missing secret boundary.
- no secret leakage.
- correlation header observed.
- provider disabled by default.
- route alias can target `anthropic`.
