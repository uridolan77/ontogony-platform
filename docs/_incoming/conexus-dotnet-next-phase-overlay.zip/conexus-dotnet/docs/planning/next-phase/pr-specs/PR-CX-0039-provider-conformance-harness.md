# PR-CX-0039 — Provider conformance harness

## Goal

Create a common test harness for provider adapters so new providers cannot drift.

## Scope

- Shared provider test utilities.
- Standard expected mappings for success/error/timeout/malformed/secret/correlation cases.
- Apply harness to OpenAI, OpenAI-compatible HTTP, Anthropic if present, Gemini if present.
- Document provider conformance requirements.

## Out of scope

- New provider implementation.

## Acceptance

- Existing provider tests are reduced or wrapped by common matrix.
- At least OpenAI and OpenAI-compatible providers use the matrix.
- Adding a new provider has a clear checklist.
