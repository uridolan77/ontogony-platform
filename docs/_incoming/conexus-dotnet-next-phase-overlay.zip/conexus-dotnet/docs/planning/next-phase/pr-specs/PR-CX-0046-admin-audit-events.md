# PR-CX-0046 — Admin audit events

## Goal

Durably record admin mutations.

## Scope

Audit these actions:

- project create/update
- key issue/revoke
- provider config create/update/delete
- alias create/update/delete
- project override create/update/delete
- price catalog upsert

## Acceptance

- Actor/project/admin identity captured where available.
- Before/after hashes or safe summaries captured.
- No secret values captured.
- Query path for recent audit events.
