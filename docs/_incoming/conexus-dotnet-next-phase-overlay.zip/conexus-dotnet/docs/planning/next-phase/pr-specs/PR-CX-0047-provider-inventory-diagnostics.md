# PR-CX-0047 — Provider inventory diagnostics endpoint

## Goal

Expose a safe operator view of registered providers, configured providers, readiness state, route references, and secret-reference status.

## Scope

- Admin endpoint under `/admin/v0/providers/inventory`.
- Shows provider key, runtime registered, config exists, enabled, ready, secret reference presence, route references count.
- Does not show raw secret values.

## Acceptance

- Admin auth required.
- Useful JSON shape.
- Tests for missing runtime/config mismatch.
