# PR-CX-0041 — Package-mode Ontogony consumption

## Goal

Add a CI path proving Conexus can consume packaged Ontogony artifacts rather than sibling project references.

## Scope

- Add package-mode build/test workflow or script.
- Use Ontogony internal feed or locally packed packages.
- Keep source-mode workflow during alpha if needed.
- Document how to switch between sibling source and package mode.

## Acceptance

- Package-mode restore/build/test succeeds.
- Source-mode still works for active platform development.
- README/BUILD_VALIDATION updated.
