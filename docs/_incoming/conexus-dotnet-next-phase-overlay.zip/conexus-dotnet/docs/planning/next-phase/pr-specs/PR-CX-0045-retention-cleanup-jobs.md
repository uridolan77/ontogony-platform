# PR-CX-0045 — Retention cleanup jobs/operator commands

## Goal

Turn replay/governance/artifact retention docs into executable cleanup mechanisms.

## Scope

- Configurable retention windows.
- Operator command or hosted maintenance job disabled by default.
- Cleanup for replay rows, artifacts, telemetry rows, execution records where safe.
- Dry-run mode.
- Audit log of cleanup decisions.

## Acceptance

- No raw content exposed in cleanup logs.
- Dry run reports counts only.
- Tests cover retention boundaries.
