# PR-CX-0038 — Gemini native adapter

## Goal

Add a native Gemini adapter after Anthropic to test a second non-OpenAI provider shape.

## Scope

- New project: `Conexus.Providers.Gemini`.
- Options section: `Conexus:Providers:Gemini`.
- Disabled by default.
- Native Gemini request/response mapping.
- Safety/error response normalization.
- Secret resolution through `ISecretValueResolver`.
- Ontogony integration HttpClient.
- Host composition and fallback tests.

## Out of scope

- Vertex-specific enterprise auth.
- Multimodal.
- Function calling.
- Streaming.

## Acceptance

- Same provider conformance baseline as Anthropic.
- Gemini-specific safety/error semantics documented.
