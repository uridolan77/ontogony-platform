# PR-CX-0040 — Provider runtime/config/readiness unification

## Goal

Ensure provider runtime clients, provider config store rows, route aliases, and readiness checks agree.

## Scope

- Introduce provider runtime inventory/query service.
- Readiness fails when enabled provider config has no runtime client.
- Readiness fails when a configured enabled provider secret cannot be resolved.
- Readiness warns/fails when routes reference unavailable provider keys.
- Admin provider config can represent OpenAI-compatible provider keys such as `openrouter`.
- Add tests for enabled OpenAI-compatible provider without matching provider config row and vice versa.

## Out of scope

- Provider marketplace.
- UI.

## Acceptance

- `/ready` reflects actual invocation viability.
- OpenRouter/OpenAI-compatible config can be represented in admin provider config.
- Error messages disclose provider key but not secret value.
