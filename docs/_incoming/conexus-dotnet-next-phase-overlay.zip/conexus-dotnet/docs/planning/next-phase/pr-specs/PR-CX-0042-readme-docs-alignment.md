# PR-CX-0042 — README/docs alignment after durability work

## Goal

Update stale user-facing docs that still describe Conexus as a starter with mostly in-memory stores.

## Scope

- README.
- `docs/development/CONFIGURATION.md`.
- roadmap/robustness docs if present.
- migration/operator doc links.
- provider enablement examples for OpenAI and OpenAI-compatible HTTP.

## Acceptance

- README no longer says durable application tables are absent.
- README explicitly states what remains in-memory only in no-Postgres/local mode.
- Commands include `-p:NoWarn=CS1591` while sibling platform source mode remains.
- Current test count and major implemented components are accurately summarized.
