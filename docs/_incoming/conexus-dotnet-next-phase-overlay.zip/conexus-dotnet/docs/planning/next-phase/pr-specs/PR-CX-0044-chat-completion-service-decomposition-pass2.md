# PR-CX-0044 — ChatCompletionService decomposition pass 2

## Goal

Reduce `ChatCompletionService` orchestration load after provider/streaming boundaries settle.

## Scope

Extract:

- `ProviderAttemptExecutor`
- `ChatTelemetryWriter`
- `RawProviderArtifactCapture`
- `ChatCompletionResponseMapper`
- `UsageCostRecorder`

## Acceptance

- Behavior unchanged.
- Existing tests pass.
- New collaborators have focused tests.
- `ChatCompletionService` reads as orchestration only.
