# PR-CX-0043 — Streaming chat completions over SSE

## Goal

Implement OpenAI-compatible streaming for `/v1/chat/completions` when `stream: true`.

## Scope

- Streaming response DTO/event model.
- Provider streaming abstraction.
- Fake streaming provider for tests.
- OpenAI-compatible SSE writer.
- Auth/quota/route/fallback/telemetry integration.
- Cancellation handling.

## Out of scope

- Tool calls.
- Multimodal.
- Streaming replay documents.

## Acceptance

- `stream: false` path unchanged.
- `stream: true` returns SSE with `[DONE]`.
- No raw prompt/completion logging.
- Cancellation test.
- Error-before-first-token and error-after-start behavior documented.
