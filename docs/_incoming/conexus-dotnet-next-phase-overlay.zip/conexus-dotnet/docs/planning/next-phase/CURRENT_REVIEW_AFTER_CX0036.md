# Current review after PR-CX-0036

## Executive verdict

Conexus.NET has completed the originally planned robustness sequence through PR-CX-0036 at v0 scope.

Current accepted state:

- OpenAI provider uses the Ontogony HTTP integration pipeline.
- Raw secret logging has been removed from API-key failure paths.
- Postgres foundation and durable stores exist.
- Project/key store, routing/provider config, idempotency replay, telemetry, execution journal, quota usage, artifacts, usage/cost governance, readiness, ingress rate limiting, OpenAPI hardening, price catalog, and second provider adapter are all present.
- The current validation record states **229 tests passed, 0 failed, 0 skipped**.

## Accepted current PRs

| PR | Verdict | Notes |
|---|---:|---|
| CX-0021 / 0021.1 | Accepted | OpenAI uses Ontogony HTTP pipeline with correlation + retry proof. |
| CX-0022 | Accepted | Raw project API keys no longer enter log scopes. |
| CX-0023 | Accepted | Postgres foundation and migration path present. |
| CX-0024 | Accepted | Durable project/key store present. |
| CX-0025 / 0025.1 | Accepted | Admin projects/keys and null-safe validation landed. |
| CX-0026 / 0026.1 | Accepted | Durable aliases/provider config/overrides plus normalized keys. |
| CX-0027 / 0027.1 | Accepted | Durable replay, payload binding, terminal replay/conflict/in-progress journaling. |
| CX-0028 / 0028.1 | Accepted | Durable telemetry, execution journal, usage/cost governance, project-indexed response rows. |
| CX-0028A / A.1 | Accepted | Durable quota ledger plus scoped Conexus quota service lifetime. |
| CX-0028B | Accepted | Durable artifact store. |
| CX-0031 | Accepted | Postgres, durable-store, and provider-credential readiness checks. |
| CX-0032 / 0032.1 | Accepted | Pre-auth IP limiting for `/v1` and `/admin`, project limiter after auth, trusted proxy option. |
| CX-0033 | Accepted as pass 1 | Fingerprinting, run journaling, and idempotency coordinator extracted. |
| CX-0034 / 0034.1 | Accepted | OpenAPI header + bearer schemes and OR security requirements. |
| CX-0035 / 0035.1 | Accepted | Effective-dated price catalog, migration hardening, negative-path validation. |
| CX-0036 | Accepted | OpenAI-compatible HTTP provider adapter and configured-provider error normalization. |

## Remaining not-done items

These are not failures of the current PRs. They are the next production hardening phase.

1. Provider client lifetimes still need alignment: typed HttpClient providers are exposed as singleton `IProviderChatClient`.
2. Provider API key options are still env-var-specific rather than general secret references.
3. Provider runtime registration, provider config store, and readiness are not yet unified into one inventory model.
4. Native Anthropic and Gemini adapters are not implemented.
5. Provider conformance harness is not implemented as a general matrix.
6. Streaming `/v1/chat/completions` remains intentionally out of scope.
7. README and some roadmap docs are stale relative to the current durable implementation.
8. Conexus still compiles a sibling `ontogony-platform` checkout in CI instead of consuming packaged Ontogony artifacts.
9. Retention docs exist, but cleanup jobs/operator commands are not implemented.
10. Admin audit events are not yet durable.

## Recommended next PR

Start with **PR-CX-0036.1 — Provider lifetime + generic secret reference cleanup**.

Do not start Anthropic/Gemini before this cleanup. It prevents copying the current provider-lifetime and env-var-specific secret patterns into more adapters.
