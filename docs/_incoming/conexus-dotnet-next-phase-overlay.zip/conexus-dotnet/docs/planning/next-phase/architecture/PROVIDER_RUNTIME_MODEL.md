# Provider runtime model

## Current problem

Conexus currently has multiple related provider concepts:

1. `IProviderChatClient` runtime instances.
2. `IProviderConfigStore` rows used by admin/readiness.
3. `ModelAlias` route definitions.
4. Provider-specific options sections.

These are valid individually, but the system must prove they agree.

## Target model

A provider is operational when:

- A provider config row exists and is enabled.
- A provider runtime client is registered for the same `ProviderKey`.
- Any required secret reference can be resolved.
- Any route/alias/fallback referencing that `ProviderKey` can resolve a provider client.
- Readiness reports the same state operators will see during actual invocation.

## Boundaries

Conexus owns:

- provider keys
- provider config rows
- routing/fallback policy
- price catalog
- readiness semantics for providers
- admin APIs

Ontogony owns only reusable mechanics:

- secret resolver contracts
- HTTP resilience/correlation
- logging/redaction
- execution/telemetry contracts
