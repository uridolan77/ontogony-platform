# Provider secret reference policy

## Current v0 pattern

Provider options use an `ApiKeyEnvironmentVariable` field. The provider converts it into:

```csharp
new SecretValueReference("env", variableName)
```

## Target pattern

Provider options should eventually use:

```json
{
  "ApiKeySecret": "env:CONEXUS_PROVIDER_OPENAI_API_KEY"
}
```

Future examples:

```json
{
  "ApiKeySecret": "vault:providers/openai/api-key"
}
```

## Rules

- Raw secret values never appear in `appsettings*.json`.
- Raw secret values never appear in logs, exceptions, health check output, telemetry, or replay documents.
- A secret reference may be logged only in redacted/display-safe form.
- Fingerprints are metadata; they do not prove runtime resolvability.
- Readiness should check runtime resolvability for enabled providers when safe.
