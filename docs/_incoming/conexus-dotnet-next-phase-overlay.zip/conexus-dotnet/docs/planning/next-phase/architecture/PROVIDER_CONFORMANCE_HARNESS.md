# Provider conformance harness

## Goal

Stop duplicating provider tests.

Every provider adapter should be tested against the same behavioral matrix.

## Required matrix

| Case | Expected Conexus behavior |
|---|---|
| success | maps content, model, provider response id, tokens |
| 400 | `provider_bad_request`, non-retryable |
| 401/403 | `provider_authentication_error`, non-retryable |
| 408 | retryable timeout/request-timeout |
| 429 | `provider_rate_limited`, retryable |
| 5xx | `provider_unavailable`, retryable |
| malformed success | `provider_protocol_error`, non-retryable |
| missing secret | `provider_not_configured`, non-retryable |
| transport failure | `provider_transport_error`, retryable |
| cancellation by caller | cancellation propagates |
| Ontogony HTTP | trace/correlation header observed for HTTP providers |
| no secret leakage | exception/log/test output does not contain key-like values |

## Harness design

Create test fixture utilities in provider test projects, not production code, unless duplication becomes significant.
