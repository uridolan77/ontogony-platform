# Streaming chat completions design

Streaming must preserve Conexus governance.

## Required behavior

- Endpoint supports OpenAI-compatible SSE response shape.
- Non-streaming path remains unchanged.
- Project API-key auth, ingress rate limiting, quotas, idempotency policy, route resolution, telemetry, and provider fallback all remain active.
- Streaming should not store raw token text unless an explicit opt-in artifact policy exists.

## Major decision

There are two implementation options:

1. Provider-specific streaming interface:
   - `IStreamingProviderChatClient`
   - provider adapters yield deltas
2. Gateway-synthesized streaming:
   - provider returns full response
   - gateway streams chunks artificially

Use option 1 for real provider streaming. Option 2 is only useful for fake-provider tests.

## Acceptance

- SSE content type
- `data: ...` events
- final `[DONE]`
- cancellation handling
- provider timeout mapping
- no raw prompt/completion logging
- streaming-specific telemetry without raw content
