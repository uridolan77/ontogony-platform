# Conexus.NET next-phase PR sequence

## Phase E — provider runtime hardening

1. **PR-CX-0036.1** — Provider client lifetime alignment + generic secret reference cleanup.
2. **PR-CX-0040** — Provider runtime/config/readiness unification.
3. **PR-CX-0039** — Provider conformance harness.

## Phase F — native provider expansion

4. **PR-CX-0037** — Anthropic native adapter.
5. **PR-CX-0038** — Gemini native adapter.

## Phase G — transport/product usefulness

6. **PR-CX-0043** — Streaming chat completions over SSE.
7. **PR-CX-0044** — ChatCompletionService decomposition pass 2.

## Phase H — production operations

8. **PR-CX-0041** — Package-mode Ontogony consumption.
9. **PR-CX-0042** — README/docs alignment after durability work.
10. **PR-CX-0045** — Retention cleanup jobs/operator commands.
11. **PR-CX-0046** — Admin audit events.
12. **PR-CX-0047** — Provider inventory diagnostics endpoint.

## Do not do yet

- Do not add Bedrock, Vertex, Azure OpenAI, Mistral, Cohere, or more long-tail providers before the conformance harness.
- Do not move Conexus route policy, price catalog, provider keys, or admin API semantics into `ontogony-platform`.
- Do not build an admin UI before the provider/runtime model is clean.
