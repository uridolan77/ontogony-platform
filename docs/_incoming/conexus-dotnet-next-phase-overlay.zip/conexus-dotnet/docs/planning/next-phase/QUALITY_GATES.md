# Quality gates for the next phase

Every PR must satisfy:

```powershell
dotnet restore Conexus.sln
dotnet build Conexus.sln --no-restore -c Release -p:NoWarn=CS1591
dotnet test Conexus.sln --no-build -c Release -p:NoWarn=CS1591
```

For persistence-affecting PRs:

```powershell
dotnet test tests/Conexus.Persistence.Tests/Conexus.Persistence.Tests.csproj -c Release
```

Provider PRs must prove:

- disabled by default
- host composition when enabled
- no raw secret in config, logs, exceptions, or test failure output
- missing secret fails with `provider_not_configured`
- bad credentials fail with `provider_authentication_error`
- retryable/unretryable mapping is explicit
- Ontogony integration HTTP path is used when HTTP is involved
- fallback behavior is covered by application-level test
- OpenAPI/docs/config docs updated where relevant

Production-hardening PRs must update:

- `docs/development/BUILD_VALIDATION.md`
- `docs/development/CONFIGURATION.md` if configuration changes
- README if public behavior changes
- migration docs if EF schema changes
