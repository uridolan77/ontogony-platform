# Open issues for the next Conexus.NET phase

## P0

### Provider lifetime alignment

Current provider DI registers typed HTTP clients and exposes them as singleton `IProviderChatClient`. This can capture typed-client state longer than intended and should be corrected before adding more providers.

Expected fix:
- provider clients: transient or scoped
- registry: scoped, or a factory-based registry that resolves providers per call
- DI validation tests with `ValidateScopes` and `ValidateOnBuild`

### Secret reference generalization

Provider options currently use `ApiKeyEnvironmentVariable`. This is acceptable for env-only v0, but platform now has `ISecretValueResolver`.

Expected fix:
- introduce provider `ApiKeySecret` string such as `env:CONEXUS_PROVIDER_OPENROUTER_API_KEY`
- parse into `SecretValueReference`
- retain env-var compatibility as a transition field only if needed
- never log resolved values

## P1

### Provider runtime/config/readiness unification

There are now three related notions:
- registered provider clients
- provider configuration rows
- route aliases

They should agree, especially when OpenAI-compatible provider is enabled with `ProviderKey = openrouter`.

Expected fix:
- readiness should fail if an enabled route points to an unregistered provider
- readiness should fail if a registered enabled provider lacks a resolvable secret when it needs one
- provider config store should support OpenAI-compatible runtime keys beyond OpenAI

### Provider conformance harness

Provider-specific tests should share a common harness:
- success response mapping
- 400/401/403/408/429/500/502/503
- malformed success
- timeout/transport error
- cancellation
- secret absence
- no secret leakage
- Ontogony correlation header

## P2

### README stale

README still describes the repo as a starter with many stores remaining in-memory. This is no longer true after CX-0024 through CX-0036.

### Streaming

Still explicitly unsupported. Implement only after provider lifecycle/conformance is clean.

### Retention

Retention policies exist in docs. Cleanup jobs do not yet exist.
